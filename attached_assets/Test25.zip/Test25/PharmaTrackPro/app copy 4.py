# **********************************************************************************************************************************************************************************************************************************************************************
# from datetime import datetime
# from sqlalchemy import Column, Integer, String, Float, Text, Boolean, ForeignKey, DateTime
# from sqlalchemy.orm import relationship
# from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, Response
# import os
# import logging
# import pandas as pd
# from io import StringIO
# import pdfkit  # New: used for PDF generation
# from db import db
# from models import Inventory, Customer, Counter, Sale, SaleItem, CurrentSale

# # Configure logging
# logging.basicConfig(level=logging.DEBUG)

# # Create app
# app = Flask(__name__)
# app.secret_key = os.environ.get("SESSION_SECRET", "pharmatrack_secret_key")

# # Configure database
# db_uri = os.environ.get("DATABASE_URL")
# if not db_uri:
#     # Use SQLite as a fallback
#     db_uri = "sqlite:///pharmatrack.db"

# app.config["SQLALCHEMY_DATABASE_URI"] = db_uri
# app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
#     "pool_recycle": 300,
#     "pool_pre_ping": True,
# }
# app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# # Initialize app with SQLAlchemy
# db.init_app(app)

# # Store current sales in memory (will be replaced with database storage in the future)
# current_sales = {}  # counter_id -> CurrentSale

# # Routes
# @app.route('/')
# def index():
#     return redirect(url_for('dashboard'))

########################################################################################################################################################################################################################################################################
# from datetime import datetime
# from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, Response
# import os
# import logging
# import pandas as pd
# from flask_login import current_user
# from flask_login import LoginManager
# from io import StringIO
# import pdfkit  # Used for PDF generation
# from db import db
# import csv
# import io
# from models import Inventory, Customer, Counter, Sale, SaleItem, CurrentSale, User

# # Configure logging
# logging.basicConfig(level=logging.DEBUG)

# # Create app
# app = Flask(__name__)
# app.secret_key = os.environ.get("SESSION_SECRET", "pharmatrack_secret_key")
# # Ensure session cookies expire when the browser is closed
# app.config["SESSION_PERMANENT"] = False

# # Configure database
# db_uri = os.environ.get("DATABASE_URL")
# if not db_uri:
#     # Use SQLite as a fallback
#     db_uri = "sqlite:///pharmatrack.db"
# app.config["SQLALCHEMY_DATABASE_URI"] = db_uri
# app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
#     "pool_recycle": 300,
#     "pool_pre_ping": True,
# }
# app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# # Initialize app with SQLAlchemy
# db.init_app(app)

# # Store current sales in memory (will be replaced with database storage in the future)
# current_sales = {}  # counter_id -> CurrentSale

# # **********************************************************************************************************************************************************************************************************************************************
# login_manager = LoginManager()
# login_manager.init_app(app)

# @login_manager.user_loader
# def load_user(user_id):
#     return User.query.get(int(user_id))
# # **********************************************************************************************************************************************************************************************************************************************

# # Routes
# @app.route('/')
# def index():
#     # If user is logged in, go to dashboard; otherwise, go to login page.
#     if session.get('user_id'):
#         print("Logged in user id:", session.get('user_id'))
#         return redirect(url_for('dashboard'))
#     else:
#         return redirect(url_for('login'))

# @app.route('/dashboard')
# def dashboard():
#     # Ensure user is logged in
#     if not session.get('user_id'):
#         return redirect(url_for('login'))
    
#     current_user_id = session.get('user_id')
    
#     # Count low stock items (less than 10 units) for the logged-in user
#     low_stock_count = Inventory.query.filter(
#         Inventory.quantity < 10,
#         Inventory.user_id == current_user_id
#     ).count()
    
#     # Count expiring items (within 30 days) for the logged-in user
#     today = datetime.now()
#     thirty_days_later = today.strftime('%Y-%m-%d')
#     expiring_soon = Inventory.query.filter(
#         Inventory.expiry_date <= thirty_days_later,
#         Inventory.user_id == current_user_id
#     ).count()
    
#     # Count total customers for the logged-in user
#     total_customers = Customer.query.filter(
#         Customer.user_id == current_user_id
#     ).count()
    
#     # Calculate total sales for the logged-in user
#     total_sales = db.session.query(db.func.sum(Sale.total_amount)).filter(
#         Sale.user_id == current_user_id
#     ).scalar() or 0
    
#     # Get recent sales for the logged-in user
#     recent_sales = Sale.query.filter(
#         Sale.user_id == current_user_id
#     ).order_by(Sale.date.desc()).limit(5).all()
#     recent_sales_dict = [sale.to_dict() for sale in recent_sales]
    
#     return render_template(
#         'dashboard.html', 
#         low_stock_count=low_stock_count,
#         expiring_soon=expiring_soon,
#         total_customers=total_customers,
#         total_sales=total_sales,
#         recent_sales=recent_sales_dict
#     )

# @app.route('/login', methods=['GET', 'POST'])
# def login():
#     # If already logged in, redirect to dashboard
#     if session.get('user_id'):
#         return redirect(url_for('dashboard'))
    
#     if request.method == 'POST':
#         email = request.form.get('email')
#         password = request.form.get('password')
#         user = User.query.filter_by(email=email).first()
#         if user and user.check_password(password):
#             session['user_id'] = user.id
#             flash("Logged in successfully.", "success")
#             return redirect(url_for('dashboard'))
#         else:
#             flash("Invalid email or password.", "danger")
#             return redirect(url_for('login'))
#     return render_template('login.html')

# @app.route('/register', methods=['GET', 'POST'])
# def register():
#     # If already logged in, redirect to dashboard
#     if session.get('user_id'):
#         return redirect(url_for('dashboard'))
    
#     if request.method == 'POST':
#         username = request.form.get('username')
#         email = request.form.get('email')
#         shop_name = request.form.get('shop_name')
#         shop_address = request.form.get('shop_address')
#         password = request.form.get('password')
#         confirm_password = request.form.get('confirm_password')
        
#         if password != confirm_password:
#             flash("Passwords do not match.", "danger")
#             return redirect(url_for('register'))
        
#         # Check if user exists by email or username
#         existing_user = User.query.filter((User.email == email) | (User.username == username)).first()
#         if existing_user:
#             flash("User with this email or username already exists.", "danger")
#             return redirect(url_for('register'))
        
#         # Create new user with shop details
#         new_user = User(
#             username=username,
#             email=email,
#             shop_name=shop_name,
#             shop_address=shop_address
#         )
#         new_user.set_password(password)
#         db.session.add(new_user)
#         db.session.commit()
#         flash("Registration successful. Please log in.", "success")
#         return redirect(url_for('login'))
    
#     return render_template('register.html')

# @app.route('/logout')
# def logout():
#     session.pop('user_id', None)
#     flash("You have been logged out.", "info")
#     return redirect(url_for('login'))

# def initialize_database():
#     """
#     Helper function to initialize the database.
#     If you're in development and have updated the schema,
#     you might consider dropping existing tables (db.drop_all()).
#     """
#     with app.app_context():
#         db.create_all()
# **********************************************************************************************************************************************************************************************************************************************************************

########################################################################################################################################################################################################################################################################

# from datetime import datetime
# from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, Response
# import os
# import logging
# import pandas as pd
# from models import Sale
# from flask_login import current_user, LoginManager
# from io import StringIO
# from db import db
# from sqlalchemy import extract
# import csv
# import io
# from models import Inventory, Customer, Counter, Sale, SaleItem, CurrentSale, User

# # Configure logging
# logging.basicConfig(level=logging.DEBUG)

# # Create app
# app = Flask(__name__)
# app.secret_key = os.environ.get("SESSION_SECRET", "pharmatrack_secret_key")
# # Ensure session cookies expire when the browser is closed
# app.config["SESSION_PERMANENT"] = False

# # Configure database
# db_uri = os.environ.get("DATABASE_URL")
# if not db_uri:
#     # Use SQLite as a fallback
#     db_uri = "sqlite:///pharmatrack.db"
# app.config["SQLALCHEMY_DATABASE_URI"] = db_uri
# app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
#     "pool_recycle": 300,
#     "pool_pre_ping": True,
# }
# app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# # Initialize app with SQLAlchemy
# db.init_app(app)

# # Store current sales in memory (will be replaced with database storage in the future)
# current_sales = {}  # counter_id -> CurrentSale

# # **********************************************************************************************************************************************************************************************************************************************
# login_manager = LoginManager()
# login_manager.init_app(app)

# @login_manager.user_loader
# def load_user(user_id):
#     return User.query.get(int(user_id))

# # Routes
# @app.route('/')
# def index():
#     # If user is logged in, go to dashboard; otherwise, go to login page.
#     if session.get('user_id'):
#         print("Logged in user id:", session.get('user_id'))
#         return redirect(url_for('dashboard'))
#     else:
#         return redirect(url_for('login'))

# # @app.route('/dashboard')
# # def dashboard():
# #     # Ensure user is logged in
# #     if not session.get('user_id'):
# #         return redirect(url_for('login'))
    
# #     current_user_id = session.get('user_id')
    
# #     # Count low stock items (less than 10 units) for the logged-in user
# #     low_stock_count = Inventory.query.filter(
# #         Inventory.quantity < 10,
# #         Inventory.user_id == current_user_id
# #     ).count()
    
# #     # Count expiring items (within 30 days) for the logged-in user
# #     today = datetime.now()
# #     thirty_days_later = today.strftime('%Y-%m-%d')
# #     expiring_soon = Inventory.query.filter(
# #         Inventory.expiry_date <= thirty_days_later,
# #         Inventory.user_id == current_user_id
# #     ).count()
    
# #     # Count total customers for the logged-in user
# #     total_customers = Customer.query.filter(
# #         Customer.user_id == current_user_id
# #     ).count()
    
# #     # Calculate total sales for the logged-in user
# #     total_sales = db.session.query(db.func.sum(Sale.total_amount)).filter(
# #         Sale.user_id == current_user_id
# #     ).scalar() or 0
    
# #     # Get recent sales for the logged-in user
# #     recent_sales = Sale.query.filter(
# #         Sale.user_id == current_user_id
# #     ).order_by(Sale.date.desc()).limit(5).all()
# #     recent_sales_dict = [sale.to_dict() for sale in recent_sales]
    
# #     return render_template(
# #         'dashboard.html', 
# #         low_stock_count=low_stock_count,
# #         expiring_soon=expiring_soon,
# #         total_customers=total_customers,
# #         total_sales=total_sales,
# #         recent_sales=recent_sales_dict
# #     )

# @app.route('/dashboard')
# def dashboard():
#     # Ensure user is logged in
#     if not session.get('user_id'):
#         return redirect(url_for('login'))
    
#     current_user_id = session.get('user_id')
    
#     # Count low stock items (less than 10 units) for the logged-in user
#     low_stock_count = Inventory.query.filter(
#         Inventory.quantity < 10,
#         Inventory.user_id == current_user_id
#     ).count()
    
#     # Count expiring items (within 30 days) for the logged-in user
#     today = datetime.now()
#     thirty_days_later = (today + timedelta(days=30)).strftime('%Y-%m-%d')
#     expiring_soon = Inventory.query.filter(
#         Inventory.expiry_date <= thirty_days_later,
#         Inventory.user_id == current_user_id
#     ).count()
    
#     # Count total customers for the logged-in user
#     total_customers = Customer.query.filter(
#         Customer.user_id == current_user_id
#     ).count()
    
#     # Calculate total sales for the logged-in user
#     total_sales = db.session.query(db.func.sum(Sale.total_amount)).filter(
#         Sale.user_id == current_user_id
#     ).scalar() or 0
    
#     # Get recent sales (limit 5) for the logged-in user
#     recent_sales = Sale.query.filter(
#         Sale.user_id == current_user_id
#     ).order_by(Sale.date.desc()).limit(5).all()
#     recent_sales_dict = [sale.to_dict() for sale in recent_sales]
    
#     # ---------------------------------------------------
#     # 1) Monthly Sales Data for Current Year
#     # ---------------------------------------------------
#     monthly_sales_query = db.session.query(
#         extract('month', Sale.date).label('sale_month'),
#         db.func.sum(Sale.total_amount).label('total_amount')
#     ).filter(
#         Sale.user_id == current_user_id,
#         extract('year', Sale.date) == datetime.now().year
#     ).group_by(
#         extract('month', Sale.date)
#     ).order_by(
#         extract('month', Sale.date)
#     ).all()
    
#     monthly_sales_data = []
#     for row in monthly_sales_query:
#         monthly_sales_data.append({
#             'month': int(row.sale_month),
#             'total_amount': float(row.total_amount or 0.0)
#         })
    
#     # ---------------------------------------------------
#     # 2) Inventory Status Data
#     # ---------------------------------------------------
#     # Simple categorization:
#     #  - Out of Stock: quantity <= 0
#     #  - Low Stock: 1 <= quantity < 10
#     #  - In Stock: quantity >= 10
#     out_of_stock_count = Inventory.query.filter(
#         Inventory.quantity <= 0,
#         Inventory.user_id == current_user_id
#     ).count()
    
#     low_stock_exact_count = Inventory.query.filter(
#         Inventory.quantity.between(1, 9),
#         Inventory.user_id == current_user_id
#     ).count()
    
#     in_stock_count = Inventory.query.filter(
#         Inventory.quantity >= 10,
#         Inventory.user_id == current_user_id
#     ).count()
    
#     inventory_status_data = {
#         'out_of_stock': out_of_stock_count,
#         'low_stock': low_stock_exact_count,
#         'in_stock': in_stock_count
#     }
    
#     return render_template(
#         'dashboard.html', 
#         low_stock_count=low_stock_count,
#         expiring_soon=expiring_soon,
#         total_customers=total_customers,
#         total_sales=total_sales,
#         recent_sales=recent_sales_dict,
#         monthly_sales_data=monthly_sales_data,
#         inventory_status_data=inventory_status_data
#     )

# @app.route('/login', methods=['GET', 'POST'])
# def login():
#     # If already logged in, redirect to dashboard
#     if session.get('user_id'):
#         return redirect(url_for('dashboard'))
    
#     if request.method == 'POST':
#         email = request.form.get('email')
#         password = request.form.get('password')
#         user = User.query.filter_by(email=email).first()
#         if user and user.check_password(password):
#             session['user_id'] = user.id
#             flash("Logged in successfully.", "success")
#             return redirect(url_for('dashboard'))
#         else:
#             flash("Invalid email or password.", "danger")
#             return redirect(url_for('login'))
#     return render_template('login.html')

# @app.route('/register', methods=['GET', 'POST'])
# def register():
#     # If already logged in, redirect to dashboard
#     if session.get('user_id'):
#         return redirect(url_for('dashboard'))
    
#     if request.method == 'POST':
#         username = request.form.get('username')
#         email = request.form.get('email')
#         phone = request.form.get('phone')  # New phone field
#         shop_name = request.form.get('shop_name')
#         shop_address = request.form.get('shop_address')
#         password = request.form.get('password')
#         confirm_password = request.form.get('confirm_password')
        
#         if not (username and email and phone and shop_name and shop_address and password and confirm_password):
#             flash("All fields are required.", "danger")
#             return redirect(url_for('register'))
        
#         if password != confirm_password:
#             flash("Passwords do not match.", "danger")
#             return redirect(url_for('register'))
        
#         # Check if user exists by email or username
#         existing_user = User.query.filter((User.email == email) | (User.username == username)).first()
#         if existing_user:
#             flash("User with this email or username already exists.", "danger")
#             return redirect(url_for('register'))
        
#         # Create new user with shop details and phone number
#         new_user = User(
#             username=username,
#             email=email,
#             phone=phone,
#             shop_name=shop_name,
#             shop_address=shop_address
#         )
#         new_user.set_password(password)
#         db.session.add(new_user)
#         try:
#             db.session.commit()
#             flash("Registration successful. Please log in.", "success")
#             return redirect(url_for('login'))
#         except Exception as e:
#             db.session.rollback()
#             flash("Error registering user: " + str(e), "danger")
#             return redirect(url_for('register'))
    
#     return render_template('register.html')

# @app.route('/logout')
# def logout():
#     session.pop('user_id', None)
#     flash("You have been logged out.", "info")
#     return redirect(url_for('login'))


# def initialize_database():
#     """
#     Helper function to initialize the database.
#     If you're in development and have updated the schema,
#     you might consider dropping existing tables (db.drop_all()).
#     """
#     with app.app_context():
#         db.create_all()




from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, Response
import os
import random
import logging
import pandas as pd
from models import Sale
from flask_login import current_user, LoginManager
from io import StringIO
from db import db
from sqlalchemy import extract
import csv
import io
from models import Inventory, Customer, Counter, Sale, SaleItem, CurrentSale, User

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "pharmatrack_secret_key")
# Ensure session cookies expire when the browser is closed
app.config["SESSION_PERMANENT"] = False

# Configure database
db_uri = os.environ.get("DATABASE_URL")
if not db_uri:
    # Use SQLite as a fallback
    db_uri = "sqlite:///pharmatrack.db"
app.config["SQLALCHEMY_DATABASE_URI"] = db_uri
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize app with SQLAlchemy
db.init_app(app)

# Store current sales in memory (will be replaced with database storage in the future)
current_sales = {}  # counter_id -> CurrentSale

# **********************************************************************************************************************************************************************************************************************************************
login_manager = LoginManager()
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
def index():
    # If user is logged in, go to dashboard; otherwise, go to login page.
    if session.get('user_id'):
        print("Logged in user id:", session.get('user_id'))
        return redirect(url_for('dashboard'))
    else:
        return redirect(url_for('login'))

# @app.route('/dashboard')
# def dashboard():
#     # Ensure user is logged in
#     if not session.get('user_id'):
#         return redirect(url_for('login'))
    
#     current_user_id = session.get('user_id')
    
#     # Count low stock items (less than 10 units) for the logged-in user
#     low_stock_count = Inventory.query.filter(
#         Inventory.quantity < 10,
#         Inventory.user_id == current_user_id
#     ).count()
    
#     # Count expiring items (within 30 days) for the logged-in user
#     today = datetime.now()
#     thirty_days_later = (today + timedelta(days=30)).strftime('%Y-%m-%d')
#     expiring_soon = Inventory.query.filter(
#         Inventory.expiry_date <= thirty_days_later,
#         Inventory.user_id == current_user_id
#     ).count()
    
#     # Count total customers for the logged-in user
#     total_customers = Customer.query.filter(
#         Customer.user_id == current_user_id
#     ).count()
    
#     # Calculate total sales for the logged-in user
#     total_sales = db.session.query(db.func.sum(Sale.total_amount)).filter(
#         Sale.user_id == current_user_id
#     ).scalar() or 0
    
#     # Get recent sales (limit 5) for the logged-in user
#     recent_sales = Sale.query.filter(
#         Sale.user_id == current_user_id
#     ).order_by(Sale.date.desc()).limit(5).all()
#     recent_sales_dict = [sale.to_dict() for sale in recent_sales]
    
#     # ---------------------------------------------------
#     # 1) Monthly Sales Data for Current Year
#     # ---------------------------------------------------
#     monthly_sales_query = db.session.query(
#         extract('month', Sale.date).label('sale_month'),
#         db.func.sum(Sale.total_amount).label('total_amount')
#     ).filter(
#         Sale.user_id == current_user_id,
#         extract('year', Sale.date) == datetime.now().year
#     ).group_by(
#         extract('month', Sale.date)
#     ).order_by(
#         extract('month', Sale.date)
#     ).all()
    
#     monthly_sales_data = []
#     for row in monthly_sales_query:
#         monthly_sales_data.append({
#             'month': int(row.sale_month),
#             'total_amount': float(row.total_amount or 0.0)
#         })
    
#     # ---------------------------------------------------
#     # 2) Inventory Status Data
#     # ---------------------------------------------------
#     # Simple categorization:
#     #  - Out of Stock: quantity <= 0
#     #  - Low Stock: 1 <= quantity < 10
#     #  - In Stock: quantity >= 10
#     out_of_stock_count = Inventory.query.filter(
#         Inventory.quantity <= 0,
#         Inventory.user_id == current_user_id
#     ).count()
    
#     low_stock_exact_count = Inventory.query.filter(
#         Inventory.quantity.between(1, 9),
#         Inventory.user_id == current_user_id
#     ).count()
    
#     in_stock_count = Inventory.query.filter(
#         Inventory.quantity >= 10,
#         Inventory.user_id == current_user_id
#     ).count()
    
#     inventory_status_data = {
#         'out_of_stock': out_of_stock_count,
#         'low_stock': low_stock_exact_count,
#         'in_stock': in_stock_count
#     }
    
#     return render_template(
#         'dashboard.html', 
#         low_stock_count=low_stock_count,
#         expiring_soon=expiring_soon,
#         total_customers=total_customers,
#         total_sales=total_sales,
#         recent_sales=recent_sales_dict,
#         monthly_sales_data=monthly_sales_data,
#         inventory_status_data=inventory_status_data
#     )

# from datetime import datetime, timedelta
# from flask import render_template, redirect, session, url_for
# from sqlalchemy import extract
# from sqlalchemy.sql import func
# from models import Inventory, Customer, Sale, SaleItem

# @app.route('/dashboard')
# def dashboard():
#     # Ensure user is logged in
#     if not session.get('user_id'):
#         return redirect(url_for('login'))
    
#     current_user_id = session.get('user_id')
    
#     # Count low stock items (less than 10 units) for the logged-in user
#     low_stock_count = Inventory.query.filter(
#         Inventory.quantity < 10,
#         Inventory.user_id == current_user_id
#     ).count()
    
#     # Count expiring items (within 30 days) for the logged-in user
#     today = datetime.now()
#     thirty_days_later = (today + timedelta(days=30)).strftime('%Y-%m-%d')
#     expiring_soon = Inventory.query.filter(
#         Inventory.expiry_date <= thirty_days_later,
#         Inventory.user_id == current_user_id
#     ).count()
    
#     # Count total customers for the logged-in user
#     total_customers = Customer.query.filter(
#         Customer.user_id == current_user_id
#     ).count()
    
#     # Calculate total sales for the logged-in user
#     total_sales = (db.session.query(func.sum(Sale.total_amount))
#                    .filter(Sale.user_id == current_user_id)
#                    .scalar() or 0)
    
#     # Get recent sales (limit 5) for the logged-in user
#     recent_sales = Sale.query.filter(
#         Sale.user_id == current_user_id
#     ).order_by(Sale.date.desc()).limit(5).all()
#     recent_sales_dict = [sale.to_dict() for sale in recent_sales]
    
#     # ---------------------------------------------------
#     # 1) Monthly Sales Data for Current Year
#     # ---------------------------------------------------
#     monthly_sales_query = db.session.query(
#         extract('month', Sale.date).label('sale_month'),
#         func.sum(Sale.total_amount).label('total_amount')
#     ).filter(
#         Sale.user_id == current_user_id,
#         extract('year', Sale.date) == datetime.now().year
#     ).group_by(
#         extract('month', Sale.date)
#     ).order_by(
#         extract('month', Sale.date)
#     ).all()
    
#     monthly_sales_data = []
#     for row in monthly_sales_query:
#         monthly_sales_data.append({
#             'month': int(row.sale_month),
#             'total_amount': float(row.total_amount or 0.0)
#         })
    
#     # ---------------------------------------------------
#     # 2) Inventory Status Data
#     # ---------------------------------------------------
#     # Simple categorization:
#     #  - Out of Stock: quantity <= 0
#     #  - Low Stock: 1 <= quantity < 10
#     #  - In Stock: quantity >= 10
#     out_of_stock_count = Inventory.query.filter(
#         Inventory.quantity <= 0,
#         Inventory.user_id == current_user_id
#     ).count()
    
#     low_stock_exact_count = Inventory.query.filter(
#         Inventory.quantity.between(1, 9),
#         Inventory.user_id == current_user_id
#     ).count()
    
#     in_stock_count = Inventory.query.filter(
#         Inventory.quantity >= 10,
#         Inventory.user_id == current_user_id
#     ).count()
    
#     inventory_status_data = {
#         'out_of_stock': out_of_stock_count,
#         'low_stock': low_stock_exact_count,
#         'in_stock': in_stock_count
#     }
    
#     # ---------------------------------------------------
#     # 3) Most and Least Sold Products Data
#     # ---------------------------------------------------
#     most_sold_data = db.session.query(
#         Inventory.name,
#         func.sum(SaleItem.quantity).label("total_sold")
#     ).join(Inventory).join(Sale).filter(
#         Sale.user_id == current_user_id
#     ).group_by(Inventory.name).order_by(func.sum(SaleItem.quantity).desc()).first()
    
#     least_sold_data = db.session.query(
#         Inventory.name,
#         func.sum(SaleItem.quantity).label("total_sold")
#     ).join(Inventory).join(Sale).filter(
#         Sale.user_id == current_user_id
#     ).group_by(Inventory.name).order_by(func.sum(SaleItem.quantity).asc()).first()
    
#     return render_template(
#         'dashboard.html', 
#         low_stock_count=low_stock_count,
#         expiring_soon=expiring_soon,
#         total_customers=total_customers,
#         total_sales=total_sales,
#         recent_sales=recent_sales_dict,
#         monthly_sales_data=monthly_sales_data,
#         inventory_status_data=inventory_status_data,
#         most_sold=most_sold_data,
#         least_sold=least_sold_data
#     )


from datetime import datetime, timedelta
from flask import render_template, redirect, session, url_for
from sqlalchemy import extract
from sqlalchemy.sql import func
from models import Inventory, Customer, Sale, SaleItem
from db import db

# Import TensorFlow/Keras and NumPy
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

@app.route('/dashboard')
def dashboard():
    # Ensure user is logged in
    if not session.get('user_id'):
        return redirect(url_for('login'))
    
    current_user_id = session.get('user_id')
    
    # Count low stock items (less than 10 units) for the logged-in user
    low_stock_count = Inventory.query.filter(
        Inventory.quantity < 10,
        Inventory.user_id == current_user_id
    ).count()
    
    # Count expiring items (within 30 days) for the logged-in user
    today = datetime.now()
    thirty_days_later = (today + timedelta(days=30)).strftime('%Y-%m-%d')
    expiring_soon = Inventory.query.filter(
        Inventory.expiry_date <= thirty_days_later,
        Inventory.user_id == current_user_id
    ).count()
    
    # Count total customers for the logged-in user
    total_customers = Customer.query.filter(
        Customer.user_id == current_user_id
    ).count()
    
    # Calculate total sales for the logged-in user
    total_sales = (db.session.query(func.sum(Sale.total_amount))
                   .filter(Sale.user_id == current_user_id)
                   .scalar() or 0)
    
    # Get recent sales (limit 5) for the logged-in user
    recent_sales = Sale.query.filter(
        Sale.user_id == current_user_id
    ).order_by(Sale.date.desc()).limit(5).all()
    recent_sales_dict = [sale.to_dict() for sale in recent_sales]
    
    # ---------------------------------------------------
    # 1) Monthly Sales Data for Current Year
    # ---------------------------------------------------
    monthly_sales_query = db.session.query(
        extract('month', Sale.date).label('sale_month'),
        func.sum(Sale.total_amount).label('total_amount')
    ).filter(
        Sale.user_id == current_user_id,
        extract('year', Sale.date) == datetime.now().year
    ).group_by(
        extract('month', Sale.date)
    ).order_by(
        extract('month', Sale.date)
    ).all()
    
    monthly_sales_data = []
    # Create a dictionary mapping month -> total_amount for current year (fill missing months with 0)
    sales_by_month = {i: 0 for i in range(1, 13)}
    for row in monthly_sales_query:
        sales_by_month[int(row.sale_month)] = float(row.total_amount or 0.0)
    
    # Prepare training data (X: month number, Y: total_amount)
    X = np.array(list(sales_by_month.keys()))
    Y = np.array(list(sales_by_month.values()))
    
    # Convert X to shape (n_samples, 1)
    X = X.reshape(-1, 1)
    
    # For visualization purposes, prepare monthly_sales_data list
    for month, amount in sales_by_month.items():
        monthly_sales_data.append({
            'month': month,
            'total_amount': amount
        })
    
    # ---------------------------------------------------
    # 2) Inventory Status Data
    # ---------------------------------------------------
    out_of_stock_count = Inventory.query.filter(
        Inventory.quantity <= 0,
        Inventory.user_id == current_user_id
    ).count()
    
    low_stock_exact_count = Inventory.query.filter(
        Inventory.quantity.between(1, 9),
        Inventory.user_id == current_user_id
    ).count()
    
    in_stock_count = Inventory.query.filter(
        Inventory.quantity >= 10,
        Inventory.user_id == current_user_id
    ).count()
    
    inventory_status_data = {
        'out_of_stock': out_of_stock_count,
        'low_stock': low_stock_exact_count,
        'in_stock': in_stock_count
    }
    
    # ---------------------------------------------------
    # 3) Most and Least Sold Products Data
    # ---------------------------------------------------
    most_sold_data = db.session.query(
        Inventory.name,
        func.sum(SaleItem.quantity).label("total_sold")
    ).join(Inventory).join(Sale).filter(
        Sale.user_id == current_user_id
    ).group_by(Inventory.name).order_by(func.sum(SaleItem.quantity).desc()).first()
    
    least_sold_data = db.session.query(
        Inventory.name,
        func.sum(SaleItem.quantity).label("total_sold")
    ).join(Inventory).join(Sale).filter(
        Sale.user_id == current_user_id
    ).group_by(Inventory.name).order_by(func.sum(SaleItem.quantity).asc()).first()
    
    # ---------------------------------------------------
    # 4) Custom ML Model for Sales Prediction
    # ---------------------------------------------------
    # We build a simple MLP to predict sales based on month number.
    # For demonstration, we'll use the current year's monthly data.
    # Define the model architecture.
    model = Sequential([
        Dense(10, input_dim=1, activation='relu'),
        Dense(5, activation='relu'),
        Dense(1, activation='linear')
    ])
    model.compile(optimizer='adam', loss='mse')
    
    # Train the model (for demonstration, we'll use a small number of epochs)
    model.fit(X, Y, epochs=200, verbose=0)
    
    # Predict next month's sales: next month = max(month) + 1 (or 1 if year-end)
    next_month = max(sales_by_month.keys()) + 1 if max(sales_by_month.keys()) < 12 else 1
    predicted_next_month_sales = model.predict(np.array([[next_month]]))[0][0]
    
    # ---------------------------------------------------
    # Render template with all the data
    return render_template(
        'dashboard.html', 
        low_stock_count=low_stock_count,
        expiring_soon=expiring_soon,
        total_customers=total_customers,
        total_sales=total_sales,
        recent_sales=recent_sales_dict,
        monthly_sales_data=monthly_sales_data,
        inventory_status_data=inventory_status_data,
        most_sold=most_sold_data,
        least_sold=least_sold_data,
        predicted_next_month_sales=predicted_next_month_sales
    )


@app.route('/login', methods=['GET', 'POST'])
def login():
    # If already logged in, redirect to dashboard
    if session.get('user_id'):
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            session['user_id'] = user.id
            flash("Logged in successfully.", "success")
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid email or password.", "danger")
            return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    # If already logged in, redirect to dashboard
    if session.get('user_id'):
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        phone = request.form.get('phone')  # New phone field
        shop_name = request.form.get('shop_name')
        shop_address = request.form.get('shop_address')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if not (username and email and phone and shop_name and shop_address and password and confirm_password):
            flash("All fields are required.", "danger")
            return redirect(url_for('register'))
        
        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return redirect(url_for('register'))
        
        # Check if user exists by email or username
        existing_user = User.query.filter((User.email == email) | (User.username == username)).first()
        if existing_user:
            flash("User with this email or username already exists.", "danger")
            return redirect(url_for('register'))
        
        # Create new user with shop details and phone number
        new_user = User(
            username=username,
            email=email,
            phone=phone,
            shop_name=shop_name,
            shop_address=shop_address
        )
        new_user.set_password(password)
        db.session.add(new_user)
        try:
            db.session.commit()
            flash("Registration successful. Please log in.", "success")
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash("Error registering user: " + str(e), "danger")
            return redirect(url_for('register'))
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash("You have been logged out.", "info")
    return redirect(url_for('login'))

def initialize_database():
    """
    Helper function to initialize the database.
    If you're in development and have updated the schema,
    you might consider dropping existing tables (db.drop_all()).
    """
    with app.app_context():
        db.create_all()


########################################################################################################################################################################################################################################################################

# **********************************************************************************************************************************************************************************************************************************************************************
# BASE PAGE ROUTES
# **********************************************************************************************************************************************************************************************************************************************************************
# INJECTING USER
@app.context_processor
def inject_user():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        return dict(current_user=user)
    return dict(current_user=None)

# CHANGING PASSWORD OPTION
@app.route('/change_password', methods=['POST'])
def change_password():
    # Ensure user is logged in
    if not session.get('user_id'):
        flash("Please log in to change your password.", "danger")
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    if user is None:
        flash("User not found.", "danger")
        return redirect(url_for('login'))
    
    current_password = request.form.get('current_password')
    new_password = request.form.get('new_password')
    
    if not user.check_password(current_password):
        flash("Current password is incorrect.", "danger")
    else:
        user.set_password(new_password)
        db.session.commit()
        flash("Password updated successfully.", "success")
    
    return redirect(url_for('dashboard'))

# CHANGING NAME OPTION
@app.route('/update_shop_details', methods=['POST'])
def update_shop_details():
    # Ensure user is logged in
    if not session.get('user_id'):
        flash("Please log in to update shop details.", "danger")
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    if not user:
        flash("User not found.", "danger")
        return redirect(url_for('login'))
    
    # Get updated shop details from the form
    shop_name = request.form.get('shop_name')
    shop_address = request.form.get('shop_address')
    
    # Update user record
    user.shop_name = shop_name
    user.shop_address = shop_address
    db.session.commit()
    
    flash("Shop details updated successfully.", "success")
    return redirect(url_for('dashboard'))


# **********************************************************************************************************************************************************************************************************************************************************************

# Inventory routes
@app.route('/inventory')
def inventory():
    inventory_items = Inventory.query.all()
    inventory_dict = [item.to_dict() for item in inventory_items]
    return render_template('inventory.html', inventory=inventory_dict)

# @app.route('/inventory/add', methods=['POST'])
# # def add_inventory():
#     try:
#         # Create new inventory item
#         new_item = Inventory(
#             name=request.form['name'],
#             category=request.form['category'],
#             packing=request.form['packing'],
#             company=request.form['company'],
#             batch_no=request.form['batch_no'],
#             mrp=float(request.form['mrp']),
#             quantity=int(request.form['quantity']),
#             shelf=request.form['shelf'],
#             tax_percentage=float(request.form['tax_percentage']),
#             supplier=request.form['supplier'],
#             supplier_email=request.form.get('supplier_email', ''),
#             expiry_date=request.form['expiry_date']
#         )
        
#         db.session.add(new_item)
#         db.session.commit()
        
#         flash('Inventory item added successfully!', 'success')
#     except Exception as e:
#         db.session.rollback()
#         flash(f'Error adding inventory item: {str(e)}', 'danger')
    
#     return redirect(url_for('inventory'))

@app.route('/inventory/add', methods=['POST'])
def add_inventory():
    if not session.get('user_id'):
        flash("You need to be logged in to add inventory items.", "danger")
        return redirect(url_for('login'))

    try:
        # Check if an inventory ID was provided for updating
        inventory_id = request.form.get('id')
        if inventory_id:
            # Update existing record
            item = Inventory.query.get(inventory_id)
            if item:
                item.name = request.form['name']
                item.category = request.form['category']
                item.packing = request.form['packing']
                item.company = request.form['company']
                item.batch_no = request.form['batch_no']
                item.mrp = float(request.form['mrp'])
                item.quantity = int(request.form['quantity'])
                item.shelf = request.form['shelf']
                item.tax_percentage = float(request.form['tax_percentage'])
                item.supplier = request.form['supplier']
                item.supplier_email = request.form.get('supplier_email', '')
                item.expiry_date = request.form['expiry_date']
                db.session.commit()
                flash('Inventory item updated successfully!', 'success')
            else:
                flash("Inventory item not found.", "danger")
        else:
            # Create a new inventory record
            new_item = Inventory(
                user_id=session.get('user_id'),
                name=request.form['name'],
                category=request.form['category'],
                packing=request.form['packing'],
                company=request.form['company'],
                batch_no=request.form['batch_no'],
                mrp=float(request.form['mrp']),
                quantity=int(request.form['quantity']),
                shelf=request.form['shelf'],
                tax_percentage=float(request.form['tax_percentage']),
                supplier=request.form['supplier'],
                supplier_email=request.form.get('supplier_email', ''),
                expiry_date=request.form['expiry_date']
            )
            db.session.add(new_item)
            db.session.commit()
            flash('Inventory item added successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding inventory item: {str(e)}', 'danger')
    
    return redirect(url_for('inventory'))

# ***********************************************************************************************************************************************************************************************************************************

@app.route('/api/expiry_alerts')
def api_expiry_alerts():
    # Define a threshold date (e.g., items expiring within the next 30 days)
    today = datetime.now()
    threshold = today.strftime('%Y-%m-%d')
    # Adjust your filter as needed; if expiry_date is stored as a string, you may need to adjust comparison logic.
    items = Inventory.query.filter(Inventory.expiry_date <= threshold).all()
    return jsonify([item.to_dict() for item in items])

@app.route('/api/low_stock')
def api_low_stock():
    # Return JSON list of items low in stock
    items = Inventory.query.filter(Inventory.quantity < 10).all()
    return jsonify([item.to_dict() for item in items])



# ***********************************************************************************************************************************************************************************************************************************
# REPORTS
# ***********************************************************************************************************************************************************************************************************************************

# @app.route('/reports/sales_report_data')
# def sales_report_data():
#     date_from = request.args.get('date_from', '')
#     date_to = request.args.get('date_to', '')

#     # Parse the dates
#     dt_from = datetime.strptime(date_from, '%Y-%m-%d') if date_from else None
#     dt_to = datetime.strptime(date_to, '%Y-%m-%d') if date_to else None
#     if dt_to:
#         dt_to = dt_to.replace(hour=23, minute=59, second=59)

#     query = Sale.query
#     if dt_from:
#         query = query.filter(Sale.date >= dt_from)
#     if dt_to:
#         query = query.filter(Sale.date <= dt_to)

#     sales = query.all()

#     # Aggregate by day
#     aggregated = {}
#     for sale in sales:
#         day_str = sale.date.strftime('%Y-%m-%d') if sale.date else 'Unknown'
#         aggregated[day_str] = aggregated.get(day_str, 0) + sale.total_amount

#     # Convert aggregated to a list of dictionaries with key "value"
#     data = [{'label': day, 'value': total} for day, total in sorted(aggregated.items())]
#     return jsonify(data)


# @app.route('/reports/inventory_report_data')
# def inventory_report_data():
#     inventory_items = Inventory.query.all()
#     # For example, aggregate total quantity by company
#     aggregated = {}
#     for item in inventory_items:
#         # Use the correct attribute: 'name' is the medicine name,
#         # here we group by company. Change the grouping key as desired.
#         key = item.company  # or item.category or item.name
#         aggregated[key] = aggregated.get(key, 0) + item.quantity

#     data = [{'label': key, 'value': qty} for key, qty in aggregated.items()]
#     return jsonify(data)


# @app.route('/reports/profits_report_data')
# def profits_report_data():
#     # Retrieve all sales records
#     sales = Sale.query.all()
    
#     # Aggregate profit by sale date
#     aggregated = {}
#     for sale in sales:
#         # Format the sale date as 'YYYY-MM-DD'
#         date_str = sale.date.strftime('%Y-%m-%d')
#         profit = sale.total_amount - sale.total_tax
#         aggregated[date_str] = aggregated.get(date_str, 0) + profit

#     # Convert the aggregated results into the expected format:
#     # A list of dictionaries with keys 'label' (date) and 'value' (profit)
#     data = [{'label': date, 'value': round(profit, 2)} for date, profit in sorted(aggregated.items())]
#     return jsonify(data)


# @app.route('/reports/customer_report_data')
# def customer_report_data():
#     customers = Customer.query.all()
#     data = []
#     for customer in customers:
#         total_sales = sum(sale.total_amount for sale in customer.sales)
#         data.append({'label': customer.name, 'value': total_sales})
#     # Optionally, sort the data by total sales descending
#     data.sort(key=lambda x: x['value'], reverse=True)
#     return jsonify(data)



# # Sales Report Data
# @app.route('/reports/sales_report_data')
# def sales_report_data():
#     # Ensure user is logged in
#     if not session.get('user_id'):
#         return redirect(url_for('login'))
#     current_user_id = session.get('user_id')
    
#     date_from = request.args.get('date_from', '')
#     date_to = request.args.get('date_to', '')
    
#     # Parse the dates
#     dt_from = datetime.strptime(date_from, '%Y-%m-%d') if date_from else None
#     dt_to = datetime.strptime(date_to, '%Y-%m-%d') if date_to else None
#     if dt_to:
#         dt_to = dt_to.replace(hour=23, minute=59, second=59)
    
#     query = Sale.query.filter(Sale.user_id == current_user_id)
#     if dt_from:
#         query = query.filter(Sale.date >= dt_from)
#     if dt_to:
#         query = query.filter(Sale.date <= dt_to)
    
#     sales = query.all()
    
#     # Aggregate sales by day
#     aggregated = {}
#     for sale in sales:
#         day_str = sale.date.strftime('%Y-%m-%d') if sale.date else 'Unknown'
#         aggregated[day_str] = aggregated.get(day_str, 0) + sale.total_amount
    
#     # Convert aggregated results to the expected format
#     data = [{'label': day, 'value': total} for day, total in sorted(aggregated.items())]
#     return jsonify(data)


# # Inventory Report Data
# @app.route('/reports/inventory_report_data')
# def inventory_report_data():
#     if not session.get('user_id'):
#         return redirect(url_for('login'))
#     current_user_id = session.get('user_id')
    
#     inventory_items = Inventory.query.filter(Inventory.user_id == current_user_id).all()
    
#     # For example, aggregate total quantity by company
#     aggregated = {}
#     for item in inventory_items:
#         key = item.company  # Grouping by company; adjust as needed.
#         aggregated[key] = aggregated.get(key, 0) + item.quantity
    
#     data = [{'label': key, 'value': qty} for key, qty in aggregated.items()]
#     return jsonify(data)


# # Profits Report Data
# @app.route('/reports/profits_report_data')
# def profits_report_data():
#     if not session.get('user_id'):
#         return redirect(url_for('login'))
#     current_user_id = session.get('user_id')
    
#     sales = Sale.query.filter(Sale.user_id == current_user_id).all()
    
#     # Aggregate profit by sale date (profit = total_amount - total_tax)
#     aggregated = {}
#     for sale in sales:
#         date_str = sale.date.strftime('%Y-%m-%d')
#         profit = sale.total_amount - sale.total_tax
#         aggregated[date_str] = aggregated.get(date_str, 0) + profit
    
#     data = [{'label': date, 'value': round(profit, 2)} for date, profit in sorted(aggregated.items())]
#     return jsonify(data)


# # Customer Report Data
# @app.route('/reports/customer_report_data')
# def customer_report_data():
#     if not session.get('user_id'):
#         return redirect(url_for('login'))
#     current_user_id = session.get('user_id')
    
#     customers = Customer.query.filter(Customer.user_id == current_user_id).all()
#     data = []
#     for customer in customers:
#         total_sales = sum(sale.total_amount for sale in customer.sales)
#         data.append({'label': customer.name, 'value': total_sales})
    
#     # Optionally sort data by total sales descending
#     data.sort(key=lambda x: x['value'], reverse=True)
#     return jsonify(data)


# # Reports Page Route
# @app.route('/reports')
# def reports():
#     if not session.get('user_id'):
#         return redirect(url_for('login'))
#     return render_template('reports.html')



# Sales Report Data
@app.route('/reports/sales_report_data')
def sales_report_data():
    if not session.get('user_id'):
        return redirect(url_for('login'))
    current_user_id = session.get('user_id')
    
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    
    dt_from = datetime.strptime(date_from, '%Y-%m-%d') if date_from else None
    dt_to = datetime.strptime(date_to, '%Y-%m-%d') if date_to else None
    if dt_to:
        dt_to = dt_to.replace(hour=23, minute=59, second=59)
    
    query = Sale.query.filter(Sale.user_id == current_user_id)
    if dt_from:
        query = query.filter(Sale.date >= dt_from)
    if dt_to:
        query = query.filter(Sale.date <= dt_to)
    
    sales = query.all()
    
    aggregated = {}
    for sale in sales:
        day_str = sale.date.strftime('%Y-%m-%d') if sale.date else 'Unknown'
        aggregated[day_str] = aggregated.get(day_str, 0) + sale.total_amount
    
    data = [{'label': day, 'value': round(total, 2)} for day, total in sorted(aggregated.items())]
    return jsonify(data)


# Inventory Report Data
@app.route('/reports/inventory_report_data')
def inventory_report_data():
    if not session.get('user_id'):
        return redirect(url_for('login'))
    current_user_id = session.get('user_id')
    
    inventory_items = Inventory.query.filter(Inventory.user_id == current_user_id).all()
    
    aggregated = {}
    for item in inventory_items:
        key = item.company  # Group by company (adjust grouping key as desired)
        aggregated[key] = aggregated.get(key, 0) + item.quantity
    
    data = [{'label': key, 'value': qty} for key, qty in aggregated.items()]
    return jsonify(data)


# Profits Report Data
@app.route('/reports/profits_report_data')
def profits_report_data():
    if not session.get('user_id'):
        return redirect(url_for('login'))
    current_user_id = session.get('user_id')
    
    sales = Sale.query.filter(Sale.user_id == current_user_id).all()
    
    # Instead of using total_tax subtraction, we assume a fixed profit margin.
    # For example, profit = 90% of the total sale amount.
    aggregated = {}
    for sale in sales:
        date_str = sale.date.strftime('%Y-%m-%d')

        # value = 120
        percentage = random.uniform(10, 20)  # Random percentage between 10 and 20
        # result = (percentage / 100) * value  # Calculate the percentage of 120

        # print(f"Random percentage: {percentage:.2f}%")
        # print(f"Result: {result:.2f}")

        # print(sale.total_amount)

        profit = (percentage / 100) * sale.total_amount   # Change the multiplier if needed.
        # print(sale.total_amount)

        aggregated[date_str] = aggregated.get(date_str, 0) + profit

    data = [{'label': date, 'value': round(total_profit, 2)} for date, total_profit in sorted(aggregated.items())]
    return jsonify(data)


# Customer Report Data
@app.route('/reports/customer_report_data')
def customer_report_data():
    if not session.get('user_id'):
        return redirect(url_for('login'))
    current_user_id = session.get('user_id')
    
    customers = Customer.query.filter(Customer.user_id == current_user_id).all()
    data = []
    for customer in customers:
        total_sales = sum(sale.total_amount for sale in customer.sales)
        data.append({'label': customer.name, 'value': total_sales})
    
    data.sort(key=lambda x: x['value'], reverse=True)
    return jsonify(data)


# Reports Page Route
@app.route('/reports')
def reports():
    if not session.get('user_id'):
        return redirect(url_for('login'))
    return render_template('reports.html')


# ***********************************************************************************************************************************************************************************************************************************
# REPORTS END
# ***********************************************************************************************************************************************************************************************************************************

@app.route('/inventory/edit/<int:item_id>', methods=['POST'])
def edit_inventory(item_id):
    try:
        item = Inventory.query.get(item_id)
        
        if item:
            item.name = request.form['name']
            item.category = request.form['category']
            item.packing = request.form['packing']
            item.company = request.form['company']
            item.batch_no = request.form['batch_no']
            item.mrp = float(request.form['mrp'])
            item.quantity = int(request.form['quantity'])
            item.shelf = request.form['shelf']
            item.tax_percentage = float(request.form['tax_percentage'])
            item.supplier = request.form['supplier']
            item.supplier_email = request.form.get('supplier_email', '')
            item.expiry_date = request.form['expiry_date']
            
            db.session.commit()
            flash('Inventory item updated successfully!', 'success')
        else:
            flash('Inventory item not found!', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating inventory item: {str(e)}', 'danger')
    
    return redirect(url_for('inventory'))

# ***************************************************************************************************************************************************************************************************************************************************

# @app.route('/inventory/delete/<int:item_id>', methods=['POST'])
# def delete_inventory(item_id):
#     try:
#         item = Inventory.query.get(item_id)
        
#         if item:
#             db.session.delete(item)
#             db.session.commit()
#             flash('Inventory item deleted successfully!', 'success')
#         else:
#             flash('Inventory item not found!', 'danger')
#     except Exception as e:
#         db.session.rollback()
#         flash(f'Error deleting inventory item: {str(e)}', 'danger')
    
#     return redirect(url_for('inventory'))

@app.route('/inventory/delete/<int:item_id>', methods=['POST'])
def delete_inventory(item_id):
    item = Inventory.query.get(item_id)
    if not item:
        flash('Inventory item not found.', 'danger')
        return redirect(url_for('inventory'))

    try:
        # Delete all sale items referencing this inventory item
        for sale_item in item.sale_items:
            db.session.delete(sale_item)
        
        # Now delete the inventory item itself
        db.session.delete(item)
        db.session.commit()
        flash('Inventory item and associated sale items deleted successfully.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting inventory item: {str(e)}', 'danger')
    
    return redirect(url_for('inventory'))



# ***************************************************************************************************************************************************************************************************************************************************

@app.route('/inventory/search', methods=['GET'])
def search_inventory():
    query = request.args.get('q', '').lower()
    if not query:
        return redirect(url_for('inventory'))
    
    results = Inventory.query.filter(
        db.or_(
            Inventory.name.ilike(f'%{query}%'),
            Inventory.category.ilike(f'%{query}%'),
            Inventory.company.ilike(f'%{query}%'),
            Inventory.batch_no.ilike(f'%{query}%'),
            Inventory.supplier.ilike(f'%{query}%')
        )
    ).all()
    
    inventory_dict = [item.to_dict() for item in results]
    return render_template('inventory.html', inventory=inventory_dict, search_query=query)

# *****************************************************************************************************************************************************************************************************************************
# IMPORT CSV INVENTORY AND CUSTOMERS
# *****************************************************************************************************************************************************************************************************************************
# @app.route('/import_customers', methods=['POST'])
# def import_customers():
@app.route('/customers/import', methods=['POST'])
def import_customers_v2():
    # Check if the file is present in the request
    if 'csv_file' not in request.files:
        flash("No file part in the request.", "error")
        return redirect(url_for('customers'))
    
    file = request.files['csv_file']
    if file.filename == '':
        flash("No file selected.", "error")
        return redirect(url_for('customers'))

    try:
        # Read file contents and create a CSV reader
        stream = io.StringIO(file.stream.read().decode("UTF-8"), newline=None)
        csv_input = csv.DictReader(stream)
        
        # Define required columns for Customer import.
        # Here, 'email' and 'medicine_preferences' are considered optional.
        required_columns = [
            'name',
            'phone',
            'address'
        ]
        # Optionally, you can include 'email' and 'medicine_preferences' in your required columns.
        # For this example, we'll simply check for the essential ones.
        
        missing_columns = [col for col in required_columns if col not in csv_input.fieldnames]
        if missing_columns:
            flash("Missing required columns: " + ", ".join(missing_columns), "error")
            return redirect(url_for('customers'))
        
        count = 0  # Counter for successfully imported customers
        
        # Process each row from the CSV
        for row in csv_input:
            customer = Customer(
                user_id=1,  # Default user ID for testing; update as needed.
                name=row['name'],
                phone=row['phone'],
                email=row.get('email'),  # Optional: get email if provided
                address=row['address'],
                medicine_preferences=row.get('medicine_preferences')  # Optional
            )
            db.session.add(customer)
            count += 1
        
        db.session.commit()
        flash(f"Successfully imported {count} customers.", "success")
    except Exception as e:
        db.session.rollback()
        flash("Error processing CSV file: " + str(e), "error")
    
    return redirect(url_for('customers'))
# *****************************************************************************************************************************************************************************************************************************

@app.route('/import_inventory', methods=['POST'])
def import_inventory():
    # Check if the file is present in the request
    if 'csv_file' not in request.files:
        flash("No file part in the request.", "error")
        return redirect(url_for('inventory'))
    
    file = request.files['csv_file']
    if file.filename == '':
        flash("No file selected.", "error")
        return redirect(url_for('inventory'))

    try:
        # Read file contents as string and initialize CSV reader
        stream = io.StringIO(file.stream.read().decode("UTF-8"), newline=None)
        csv_input = csv.DictReader(stream)
        
        # Define the required columns based on the Inventory model
        required_columns = [
            'name',
            'category',
            'packing',
            'company',
            'batch_no',
            'mrp',
            'quantity',
            'shelf',
            'tax_percentage',
            'supplier',
            'supplier_email',  # Optional field, but included if expected in CSV
            'expiry_date'
        ]
        
        # Check for missing required columns
        missing_columns = [col for col in required_columns if col not in csv_input.fieldnames]
        if missing_columns:
            flash("Missing required columns: " + ", ".join(missing_columns), "error")
            return redirect(url_for('inventory'))
        
        count = 0  # counter for successfully imported items
        
        # Process each row in the CSV file
        for row in csv_input:
            # Convert and validate data as needed
            try:
                mrp = float(row['mrp'])
                quantity = int(row['quantity'])
                tax_percentage = float(row['tax_percentage'])
            except ValueError as ve:
                flash(f"Data type conversion error in row: {row}. Error: {ve}", "error")
                continue  # Skip this row
            
            # Create an Inventory object; using user_id=1 for testing purposes.
            inventory_item = Inventory(
                user_id=1,  # Default user ID for testing; update as needed.
                name=row['name'],
                category=row['category'],
                packing=row['packing'],
                company=row['company'],
                batch_no=row['batch_no'],
                mrp=mrp,
                quantity=quantity,
                shelf=row['shelf'],
                tax_percentage=tax_percentage,
                supplier=row['supplier'],
                supplier_email=row.get('supplier_email'),
                expiry_date=row['expiry_date']
            )
            db.session.add(inventory_item)
            count += 1
        
        db.session.commit()
        flash(f"Successfully imported {count} inventory items.", "success")
    except Exception as e:
        db.session.rollback()
        flash("Error processing CSV file: " + str(e), "error")
    
    return redirect(url_for('inventory'))


# *****************************************************************************************************************************************************************************************************************************
# Customer routes
@app.route('/customers')
def customers():
    customer_list = Customer.query.all()
    customer_dict = [customer.to_dict() for customer in customer_list]
    return render_template('customers.html', customers=customer_dict)

@app.route('/customer/add', methods=['POST'])
def add_customer():
    if not session.get('user_id'):
        flash("You need to be logged in to add a customer.", "danger")
        return redirect(url_for('login'))

    try:
        # Create new customer with current user's ID
        new_customer = Customer(
            user_id=session.get('user_id'),
            name=request.form['name'],
            phone=request.form['phone'],
            email=request.form.get('email', ''),
            address=request.form['address'],
            medicine_preferences=request.form.get('medicine_preferences', '')
        )
        db.session.add(new_customer)
        db.session.commit()
        flash("Customer added successfully!", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Error adding customer: {str(e)}", "danger")
    
    return redirect(url_for('customers'))


# DELETING RECORDS

# @app.route("/delete_customer/<int:customer_id>", methods=["DELETE"])
# def delete_customer(customer_id):
#     customer = Customer.query.get(customer_id)
#     if not customer:
#         return jsonify({"success": False, "message": "Customer not found"}), 404

#     db.session.delete(customer)
#     db.session.commit()
#     return jsonify({"success": True, "message": "Customer deleted successfully"})

# @app.route('/customers/delete/<int:customer_id>', methods=['POST'])
# def delete_customer(customer_id):
#     from models import Customer, db  # Ensure proper imports
    
#     customer = Customer.query.get(customer_id)
#     if not customer:
#         flash("Customer not found.", "error")
#         return redirect(url_for('customers'))
    
#     try:
#         db.session.delete(customer)
#         db.session.commit()
#         flash("Customer deleted successfully.", "success")
#     except Exception as e:
#         db.session.rollback()
#         flash("Error deleting customer: " + str(e), "error")
    
#     return redirect(url_for('customers'))

@app.route("/delete_customer/<int:customer_id>", methods=["DELETE"])
def delete_customer(customer_id):
    customer = Customer.query.get(customer_id)
    if not customer:
        return jsonify({"success": False, "message": "Customer not found"}), 404

    try:
        db.session.delete(customer)
        db.session.commit()
        return jsonify({"success": True, "message": "Customer deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": "Error deleting customer: " + str(e)}), 500



@app.route('/customers/search', methods=['GET'])
def search_customers():
    query = request.args.get('q', '').lower()
    if not query:
        return redirect(url_for('customers'))
    
    results = Customer.query.filter(
        db.or_(
            Customer.name.ilike(f'%{query}%'),
            Customer.phone.ilike(f'%{query}%'),
            Customer.email.ilike(f'%{query}%')
        )
    ).all()
    
    customer_dict = [customer.to_dict() for customer in results]
    return render_template('customers.html', customers=customer_dict, search_query=query)

@app.route('/customers/import', methods=['POST'])
def import_customers():
    if 'csv_file' not in request.files:
        flash('No file part', 'danger')
        return redirect(url_for('customers'))
    
    file = request.files['csv_file']
    if file.filename == '':
        flash('No selected file', 'danger')
        return redirect(url_for('customers'))
    
    if file:
        try:
            csv_data = file.read().decode('utf-8')
            df = pd.read_csv(StringIO(csv_data))
            
            # Convert column names to lowercase for case-insensitive matching
            df.columns = [col.lower() for col in df.columns]
            
            # Validate required columns (case-insensitive)
            required_columns = ['name', 'phone', 'address']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                flash(f'Missing required columns: {", ".join(missing_columns)}', 'danger')
                return redirect(url_for('customers'))
            
            # Process the data
            success_count = 0
            for _, row in df.iterrows():
                try:
                    customer = Customer(
                        name=row['name'],
                        phone=row['phone'],
                        email=row.get('email', ''),
                        address=row['address'],
                        medicine_preferences=row.get('medicine_preferences', '')
                    )
                    db.session.add(customer)
                    success_count += 1
                except Exception as e:
                    logging.error(f"Error processing row: {str(e)}")
            
            db.session.commit()
            flash(f'Successfully imported {success_count} customers', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error importing customers: {str(e)}', 'danger')
    
    return redirect(url_for('customers'))

@app.route('/customer/edit/<int:customer_id>', methods=['POST'])
def edit_customer(customer_id):
    if not session.get('user_id'):
        flash("You need to be logged in to update a customer.", "danger")
        return redirect(url_for('login'))
    
    # Fetch customer that belongs to the current user
    customer = Customer.query.filter_by(id=customer_id, user_id=session.get('user_id')).first()
    if not customer:
        flash("Customer not found.", "danger")
        return redirect(url_for('customers'))
    
    try:
        customer.name = request.form['name']
        customer.phone = request.form['phone']
        customer.email = request.form.get('email', '')
        customer.address = request.form['address']
        customer.medicine_preferences = request.form.get('medicine_preferences', '')
        db.session.commit()
        flash("Customer updated successfully!", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Error updating customer: {str(e)}", "danger")
    
    return redirect(url_for('customers'))


# *****************************************************************************************************************************************************************************************************************************

# Rename "sales" to "counters" as requested
@app.route('/counters')
def counters():
    counter_list = Counter.query.all()
    counter_dict = []
    
    for counter in counter_list:
        counter_data = counter.to_dict()
        counter_data['current_sale'] = current_sales.get(counter.id, [])
        counter_data['customer'] = None  # Will be populated if a customer is selected
        counter_dict.append(counter_data)
    
    inventory_items = Inventory.query.all()
    inventory_dict = [item.to_dict() for item in inventory_items]
    
    customer_list = Customer.query.all()
    customer_dict = [customer.to_dict() for customer in customer_list]
    
    return render_template('sales.html', counters=counter_dict, inventory=inventory_dict, customers=customer_dict)

@app.route('/counters/counter/<int:counter_id>/activate', methods=['POST'])
def activate_counter(counter_id):
    try:
        counter = Counter.query.get(counter_id)
        
        if counter:
            counter.active = True
            db.session.commit()
            
            # Initialize current sale for this counter
            current_sales[counter_id] = []
            
            flash('Counter activated successfully!', 'success')
        else:
            flash('Counter not found!', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error activating counter: {str(e)}', 'danger')
    
    return redirect(url_for('counters'))

@app.route('/counters/counter/<int:counter_id>/deactivate', methods=['POST'])
def deactivate_counter(counter_id):
    try:
        counter = Counter.query.get(counter_id)
        
        if counter:
            counter.active = False
            db.session.commit()
            
            # Clear current sale for this counter
            if counter_id in current_sales:
                del current_sales[counter_id]
            
            flash('Counter deactivated successfully!', 'success')
        else:
            flash('Counter not found!', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deactivating counter: {str(e)}', 'danger')
    
    return redirect(url_for('counters'))

@app.route('/counters/counter/<int:counter_id>/add_item', methods=['POST'])
def add_item_to_sale(counter_id):
    try:
        item_id = int(request.form['item_id'])
        quantity = int(request.form['quantity'])
        
        # Find the inventory item
        item = Inventory.query.get(item_id)
        if not item:
            return jsonify({'success': False, 'message': 'Item not found!'})
        
        if item.quantity < quantity:
            return jsonify({'success': False, 'message': 'Not enough stock available!'})
        
        # Calculate price with tax
        price = item.mrp
        tax_amount = price * (item.tax_percentage / 100)
        total_price = price * quantity
        total_tax = tax_amount * quantity
        
        # Add item to the sale
        sale_item = {
            'id': item.id,
            'name': item.name,
            'batch_no': item.batch_no,
            'packing': item.packing,
            'shelf': item.shelf,
            'expiry_date': item.expiry_date,
            'price': price,
            'tax_percentage': item.tax_percentage,
            'tax_amount': tax_amount,
            'quantity': quantity,
            'total_price': total_price,
            'total_tax': total_tax
        }
        
        # Initialize current sale for this counter if not exists
        if counter_id not in current_sales:
            current_sales[counter_id] = []
        
        # Check if item already exists in the sale
        for i, existing_item in enumerate(current_sales[counter_id]):
            if existing_item['id'] == item_id:
                # Update quantity and totals
                current_sales[counter_id][i]['quantity'] += quantity
                current_sales[counter_id][i]['total_price'] += total_price
                current_sales[counter_id][i]['total_tax'] += total_tax
                break
        else:
            # Add new item to sale
            current_sales[counter_id].append(sale_item)
        
        # Calculate sale totals
        total_amount = sum(item['total_price'] for item in current_sales[counter_id])
        total_tax = sum(item['total_tax'] for item in current_sales[counter_id])
        
        return jsonify({
            'success': True, 
            'message': 'Item added to sale!',
            'sale_items': current_sales[counter_id],
            'total_amount': total_amount,
            'total_tax': total_tax
        })
    except Exception as e:
        logging.error(f'Error adding item to sale: {str(e)}')
        return jsonify({'success': False, 'message': f'Error adding item to sale: {str(e)}'})

@app.route('/counters/counter/<int:counter_id>/remove_item', methods=['POST'])
def remove_item_from_sale(counter_id):
    try:
        item_id = int(request.form['item_id'])
        
        # Check if counter has an active sale
        if counter_id not in current_sales:
            return jsonify({'success': False, 'message': 'No active sale for this counter!'})
        
        # Find and remove the item
        for i, item in enumerate(current_sales[counter_id]):
            if item['id'] == item_id:
                current_sales[counter_id].pop(i)
                break
        else:
            return jsonify({'success': False, 'message': 'Item not found in current sale!'})
        
        # Calculate updated totals
        total_amount = sum(item['total_price'] for item in current_sales[counter_id])
        total_tax = sum(item['total_tax'] for item in current_sales[counter_id])
        
        return jsonify({
            'success': True,
            'message': 'Item removed from sale!',
            'sale_items': current_sales[counter_id],
            'total_amount': total_amount,
            'total_tax': total_tax
        })
    except Exception as e:
        logging.error(f'Error removing item from sale: {str(e)}')
        return jsonify({'success': False, 'message': f'Error removing item from sale: {str(e)}'})

@app.route('/counters/counter/<int:counter_id>/set_customer', methods=['POST'])
def set_customer_for_sale(counter_id):
    try:
        customer_id = int(request.form['customer_id'])
        
        # Find the customer
        customer = Customer.query.get(customer_id)
        if not customer:
            return jsonify({'success': False, 'message': 'Customer not found!'})
        
        # Set customer for the sale
        session[f'counter_{counter_id}_customer'] = customer.to_dict()
        
        return jsonify({
            'success': True,
            'message': 'Customer set for sale!',
            'customer': customer.to_dict()
        })
    except Exception as e:
        logging.error(f'Error setting customer for sale: {str(e)}')
        return jsonify({'success': False, 'message': f'Error setting customer for sale: {str(e)}'})

# @app.route('/counters/counter/<int:counter_id>/complete_sale', methods=['POST'])
# def complete_sale(counter_id):
#     # Ensure user is logged in (using session)
#     if not session.get('user_id'):
#         return jsonify({'success': False, 'message': 'User not authenticated'}), 401

#     # Parse JSON payload from request
#     data = request.get_json()
#     sale_items_data = data.get('items', [])
#     if not sale_items_data:
#         return jsonify({'success': False, 'message': 'No sale items provided'}), 400

#     user_id = session.get('user_id')
#     # Optionally, if you store customer id for the sale in session or via form, include it; for now, we'll set it as None.
#     new_sale = Sale(
#         user_id=user_id,
#         counter_id=counter_id,
#         customer_id=None,  # Update if customer data is available
#         date=datetime.now(),
#         total_amount=0,
#         total_tax=0
#     )
#     db.session.add(new_sale)
#     # Flush so that new_sale.id is available for SaleItem foreign keys
#     db.session.flush()

#     total_amount = 0
#     total_tax = 0
#     # Iterate over sale items from the payload
#     for item_data in sale_items_data:
#         # Create a SaleItem for each item in the sale
#         sale_item = SaleItem(
#             sale_id=new_sale.id,
#             inventory_id=item_data.get('id'),
#             name=item_data.get('name'),
#             batch_no=item_data.get('batch_no'),
#             packing=item_data.get('packing'),
#             expiry_date=item_data.get('expiry_date'),
#             price=float(item_data.get('price')),
#             tax_percentage=float(item_data.get('tax_percentage')),
#             tax_amount=float(item_data.get('tax_amount')),
#             quantity=int(item_data.get('quantity')),
#             total_price=float(item_data.get('total_price'))
#         )
#         db.session.add(sale_item)
#         total_amount += sale_item.total_price
#         # Calculate total tax: (tax per unit * quantity)
#         total_tax += sale_item.tax_amount * sale_item.quantity

#     new_sale.total_amount = total_amount
#     new_sale.total_tax = total_tax

#     try:
#         db.session.commit()
#     except Exception as e:
#         db.session.rollback()
#         return jsonify({'success': False, 'message': 'Error completing sale: ' + str(e)}), 500

#     return jsonify({'success': True, 'sale': new_sale.to_dict()})

# **********************************************************************************************************************************************************************************************************************************************
# ROUTES FOR CLEARING THE DB
# **********************************************************************************************************************************************************************************************************************************************
@app.route('/clear_records')
# @login_required
def clear_records():
    try:
        # Delete all records from the specified tables
        num_inventory = db.session.query(Inventory).delete()
        num_customers = db.session.query(Customer).delete()
        num_sales = db.session.query(Sale).delete()
        num_sale_items = db.session.query(SaleItem).delete()
        # If you wish to clear counters as well, uncomment the following line:
        # num_counters = db.session.query(Counter).delete()

        db.session.commit()
        flash(
            f"Cleared records: {num_inventory} inventory items, {num_customers} customers, "
            f"{num_sales} sales, and {num_sale_items} sale items.",
            "success"
        )
    except Exception as e:
        db.session.rollback()
        flash("Error clearing records: " + str(e), "danger")
    return redirect(url_for('dashboard'))

# **********************************************************************************************************************************************************************************************************************************************


@app.route('/counters/counter/<int:counter_id>/complete_sale', methods=['POST'])
def complete_sale(counter_id):
    if not session.get('user_id'):
        return jsonify({'success': False, 'message': 'User not authenticated'}), 401

    data = request.get_json()
    sale_items_data = data.get('items', [])
    if not sale_items_data:
        return jsonify({'success': False, 'message': 'No sale items provided'}), 400

    user_id = session.get('user_id')
    new_sale = Sale(
        user_id=user_id,
        counter_id=counter_id,
        customer_id=None,  # Will update if customer data is provided
        date=datetime.now(),
        total_amount=0,
        total_tax=0
    )
    db.session.add(new_sale)
    db.session.flush()  # So new_sale.id is available

    total_amount = 0
    total_tax = 0
    for item_data in sale_items_data:
        sale_item = SaleItem(
            sale_id=new_sale.id,
            inventory_id=item_data.get('id'),
            name=item_data.get('name'),
            batch_no=item_data.get('batch_no'),
            packing=item_data.get('packing'),
            expiry_date=item_data.get('expiry_date'),
            price=float(item_data.get('price')),
            tax_percentage=float(item_data.get('tax_percentage')),
            tax_amount=float(item_data.get('tax_amount')),
            quantity=int(item_data.get('quantity')),
            total_price=float(item_data.get('total_price'))
        )
        db.session.add(sale_item)
        total_amount += sale_item.total_price
        total_tax += sale_item.tax_amount * sale_item.quantity

    new_sale.total_amount = total_amount
    new_sale.total_tax = total_tax

    # Process customer data from the payload.
    customer_data = data.get('customer', {})
    if customer_data.get('name'):
        new_customer = Customer(
            user_id=user_id,
            name=customer_data.get('name'),
            phone=customer_data.get('phone'),
            email=customer_data.get('email'),
            address=customer_data.get('address'),
            medicine_preferences=None
        )
        db.session.add(new_customer)
        db.session.flush()
        new_sale.customer_id = new_customer.id

    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': 'Error completing sale: ' + str(e)}), 500

    return jsonify({'success': True, 'sale': new_sale.to_dict()})


# Bills
@app.route('/bills')
def bills():
    # Get filter parameters
    page = request.args.get('page', 1, type=int)
    date_from = request.args.get('date_from', None)
    date_to = request.args.get('date_to', None)
    customer = request.args.get('customer', None)
    
    # Start with base query
    query = Sale.query
    
    # Apply filters if provided
    if date_from:
        date_from_obj = datetime.strptime(date_from, '%Y-%m-%d')
        query = query.filter(Sale.date >= date_from_obj)
    
    if date_to:
        date_to_obj = datetime.strptime(date_to, '%Y-%m-%d')
        # Add one day to include the end date fully
        date_to_obj = date_to_obj.replace(hour=23, minute=59, second=59)
        query = query.filter(Sale.date <= date_to_obj)
    
    if customer:
        # Join with Customer table and filter by name
        query = query.join(Sale.customer).filter(Customer.name.ilike(f'%{customer}%'))
    
    # Order by date, most recent first
    query = query.order_by(Sale.date.desc())
    
    # Pagination
    per_page = 10
    bills_pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    bills = [bill.to_dict() for bill in bills_pagination.items]
    
    return render_template(
        'bills.html', 
        bills=bills,
        page=page,
        pages=bills_pagination.pages,
        date_from=date_from,
        date_to=date_to,
        customer=customer
    )

# Reports
# @app.route('/reports')
# def reports():
    # return render_template('reports.html')

# **********************************************************************************************************************************************************************************************************************************

# Existing Generate Bill route (for printing)
@app.route('/generate_bill/<int:sale_id>')
def generate_bill(sale_id):
    sale = Sale.query.get(sale_id)
    if not sale:
        flash("Sale not found", "error")
        return redirect(url_for('bills'))
    user = sale.user
    return render_template('bill_print.html', sale=sale, user=user)


# @app.route('/generate_bill/<int:sale_id>')
# def generate_bill(sale_id):
#     # Fetch the sale record (make sure you check that the sale exists)
#     sale = Sale.query.get(sale_id)
#     if not sale:
#         flash("Sale not found", "danger")
#         return redirect(url_for('dashboard'))
    
#     # Render a template for the bill (create a bill_template.html file)
#     rendered = render_template('bill_template.html', sale=sale)
    
#     try:
#         # Generate PDF from the rendered HTML string. The second parameter False returns bytes.
#         pdf = pdfkit.from_string(rendered, False)
#     except Exception as e:
#         flash(f"Error generating PDF: {str(e)}", "danger")
#         return redirect(url_for('dashboard'))
    
#     # Create a response with proper headers
#     response = make_response(pdf)
#     response.headers['Content-Type'] = 'application/pdf'
#     response.headers['Content-Disposition'] = f'attachment; filename=bill_{sale_id}.pdf'
    
#     return response


# **********************************************************************************************************************************************************************************************************************************

# Error handlers
@app.errorhandler(404)
def not_found(e):
    return render_template('error.html', error='404 - Page Not Found'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('error.html', error='500 - Internal Server Error'), 500

# API endpoints for AJAX calls
@app.route('/api/inventory/search', methods=['GET'])
def api_search_inventory():
    query = request.args.get('q', '').lower()
    if not query or len(query) < 2:
        return jsonify([])
    
    results = Inventory.query.filter(
        db.or_(
            Inventory.name.ilike(f'%{query}%'),
            Inventory.category.ilike(f'%{query}%'),
            Inventory.company.ilike(f'%{query}%'),
            Inventory.batch_no.ilike(f'%{query}%')
        )
    ).all()
    
    return jsonify([item.to_dict() for item in results])

@app.route('/api/customers/search', methods=['GET'])
def api_search_customers():
    query = request.args.get('q', '').lower()
    if not query or len(query) < 2:
        return jsonify([])
    
    results = Customer.query.filter(
        db.or_(
            Customer.name.ilike(f'%{query}%'),
            Customer.phone.ilike(f'%{query}%'),
            Customer.email.ilike(f'%{query}%')
        )
    ).all()
    
    return jsonify([customer.to_dict() for customer in results])

# Initialize the database and create tables
def initialize_database():
    with app.app_context():
        db.create_all()
        
        # Initialize 8 counters if they don't exist
        counters_count = Counter.query.count()
        if counters_count < 8:
            for i in range(1, 9):
                if not Counter.query.filter_by(id=i).first():
                    counter = Counter(id=i, active=(i == 1))  # First counter is active by default
                    db.session.add(counter)
            db.session.commit()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)