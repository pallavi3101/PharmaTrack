from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Text, Boolean, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, Response
import os
import logging
import pandas as pd
from io import StringIO
import pdfkit  # New: used for PDF generation
from db import db
from models import Inventory, Customer, Counter, Sale, SaleItem, CurrentSale

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "pharmatrack_secret_key")

# Configure database
db_uri = os.environ.get("DATABASE_URL")
if not db_uri:
    # Use SQLite as a fallback
    db_uri = "sqlite:///pharmatrack.db"

app.config["SQLALCHEMY_DATABASE_URI"] = db_uri
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize app with SQLAlchemy
db.init_app(app)

# Store current sales in memory (will be replaced with database storage in the future)
current_sales = {}  # counter_id -> CurrentSale

# Routes
@app.route('/')
def index():
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    # Count low stock items (less than 10 units)
    low_stock_count = Inventory.query.filter(Inventory.quantity < 10).count()
    
    # Count expiring items (within 30 days)
    today = datetime.now()
    thirty_days_later = today.strftime('%Y-%m-%d')
    expiring_soon = Inventory.query.filter(Inventory.expiry_date <= thirty_days_later).count()
    
    # Count total customers
    total_customers = Customer.query.count()
    
    # Calculate total sales
    total_sales = db.session.query(db.func.sum(Sale.total_amount)).scalar() or 0
    
    # Get recent sales
    recent_sales = Sale.query.order_by(Sale.date.desc()).limit(5).all()
    recent_sales_dict = [sale.to_dict() for sale in recent_sales]
    
    return render_template(
        'dashboard.html', 
        low_stock_count=low_stock_count,
        expiring_soon=expiring_soon,
        total_customers=total_customers,
        total_sales=total_sales,
        recent_sales=recent_sales_dict
    )

# Inventory routes
@app.route('/inventory')
def inventory():
    inventory_items = Inventory.query.all()
    inventory_dict = [item.to_dict() for item in inventory_items]
    return render_template('inventory.html', inventory=inventory_dict)

@app.route('/inventory/add', methods=['POST'])
def add_inventory():
    try:
        # Create new inventory item
        new_item = Inventory(
            name=request.form['name'],
            category=request.form['category'],
            packing=request.form['packing'],
            company=request.form['company'],
            batch_no=request.form['batch_no'],
            mrp=float(request.form['mrp']),
            quantity=int(request.form['quantity']),
            shelf=request.form['shelf'],
            tax_percentage=float(request.form['tax_percentage']),
            supplier=request.form['supplier'],
            supplier_email=request.form.get('supplier_email', ''),
            expiry_date=request.form['expiry_date']
        )
        
        db.session.add(new_item)
        db.session.commit()
        
        flash('Inventory item added successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding inventory item: {str(e)}', 'danger')
    
    return redirect(url_for('inventory'))

# ***********************************************************************************************************************************************************************************************************************************

@app.route('/api/expiry_alerts')
def api_expiry_alerts():
    # Define a threshold date (e.g., items expiring within the next 30 days)
    today = datetime.now()
    threshold = today.strftime('%Y-%m-%d')
    # Adjust your filter as needed; if expiry_date is stored as a string, you may need to adjust comparison logic.
    items = Inventory.query.filter(Inventory.expiry_date <= threshold).all()
    return jsonify([item.to_dict() for item in items])

@app.route('/api/low_stock')
def api_low_stock():
    # Return JSON list of items low in stock
    items = Inventory.query.filter(Inventory.quantity < 10).all()
    return jsonify([item.to_dict() for item in items])



# ***********************************************************************************************************************************************************************************************************************************
# REPORTS
# ***********************************************************************************************************************************************************************************************************************************

@app.route('/reports/sales_report_data')
def sales_report_data():
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')

    # Parse the dates
    dt_from = datetime.strptime(date_from, '%Y-%m-%d') if date_from else None
    dt_to = datetime.strptime(date_to, '%Y-%m-%d') if date_to else None
    if dt_to:
        dt_to = dt_to.replace(hour=23, minute=59, second=59)

    query = Sale.query
    if dt_from:
        query = query.filter(Sale.date >= dt_from)
    if dt_to:
        query = query.filter(Sale.date <= dt_to)

    sales = query.all()

    # Aggregate by day
    aggregated = {}
    for sale in sales:
        day_str = sale.date.strftime('%Y-%m-%d') if sale.date else 'Unknown'
        aggregated[day_str] = aggregated.get(day_str, 0) + sale.total_amount

    # Convert aggregated to a list of dictionaries with key "value"
    data = [{'label': day, 'value': total} for day, total in sorted(aggregated.items())]
    return jsonify(data)


@app.route('/reports/inventory_report_data')
def inventory_report_data():
    inventory_items = Inventory.query.all()
    # For example, aggregate total quantity by company
    aggregated = {}
    for item in inventory_items:
        # Use the correct attribute: 'name' is the medicine name,
        # here we group by company. Change the grouping key as desired.
        key = item.company  # or item.category or item.name
        aggregated[key] = aggregated.get(key, 0) + item.quantity

    data = [{'label': key, 'value': qty} for key, qty in aggregated.items()]
    return jsonify(data)


# @app.route('/reports/expiry_report_data')
# def expiry_report_data():
#     today = datetime.today()
#     threshold_date = today + timedelta(days=30)  # Medicines expiring within 30 days

#     inventory_items = Inventory.query.all()
#     expiring_items = []
#     for item in inventory_items:
#         try:
#             # Assuming expiry_date is stored as a string in 'YYYY-MM-DD' format
#             exp_date = datetime.strptime(item.expiry_date, '%Y-%m-%d')
#             if exp_date <= threshold_date:
#                 expiring_items.append(item)
#         except Exception as e:
#             # If conversion fails, skip the item
#             continue

#     # Aggregate by expiry_date (as a label) summing quantity
#     aggregated = {}
#     for item in expiring_items:
#         key = item.expiry_date  # Already a string in 'YYYY-MM-DD' format
#         aggregated[key] = aggregated.get(key, 0) + item.quantity

#     data = [{'label': key, 'value': qty} for key, qty in sorted(aggregated.items())]
#     return jsonify(data)
@app.route('/reports/profits_report_data')
def profits_report_data():
    sales = Sale.query.all()
    aggregated = {}
    for sale in sales:
        # Group profits by sale date (formatted as 'YYYY-MM-DD')
        date_str = sale.date.strftime('%Y-%m-%d')
        profit = sale.total_amount - sale.total_tax
        aggregated[date_str] = aggregated.get(date_str, 0) + profit

    # Prepare the data in the format expected by the frontend:
    # List of dictionaries with 'label' and 'value' keys
    data = [{'label': key, 'value': round(value, 2)} for key, value in sorted(aggregated.items())]
    return jsonify(data)

@app.route('/reports/customer_report_data')
def customer_report_data():
    customers = Customer.query.all()
    data = []
    for customer in customers:
        total_sales = sum(sale.total_amount for sale in customer.sales)
        data.append({'label': customer.name, 'value': total_sales})
    # Optionally, sort the data by total sales descending
    data.sort(key=lambda x: x['value'], reverse=True)
    return jsonify(data)




# ***********************************************************************************************************************************************************************************************************************************
# REPORTS END
# ***********************************************************************************************************************************************************************************************************************************

# ***********************************************************************************************************************************************************************************************************************************
# COUNTERS 
# ***********************************************************************************************************************************************************************************************************************************
@app.route('/api/customers/search')
def customer_search():
    """
    Search customers by name (case-insensitive) and return matching customer details.
    """
    query = request.args.get('q', '').strip()
    if query:
        # Using ilike for case-insensitive search
        customers = Customer.query.filter(Customer.name.ilike(f'%{query}%')).all()
        # Return each customer as a dictionary using the model's to_dict() method
        return jsonify([customer.to_dict() for customer in customers])
    return jsonify([])


# ***********************************************************************************************************************************************************************************************************************************
# COUNTERS END
# ***********************************************************************************************************************************************************************************************************************************

@app.route('/inventory/edit/<int:item_id>', methods=['POST'])
def edit_inventory(item_id):
    try:
        item = Inventory.query.get(item_id)
        
        if item:
            item.name = request.form['name']
            item.category = request.form['category']
            item.packing = request.form['packing']
            item.company = request.form['company']
            item.batch_no = request.form['batch_no']
            item.mrp = float(request.form['mrp'])
            item.quantity = int(request.form['quantity'])
            item.shelf = request.form['shelf']
            item.tax_percentage = float(request.form['tax_percentage'])
            item.supplier = request.form['supplier']
            item.supplier_email = request.form.get('supplier_email', '')
            item.expiry_date = request.form['expiry_date']
            
            db.session.commit()
            flash('Inventory item updated successfully!', 'success')
        else:
            flash('Inventory item not found!', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating inventory item: {str(e)}', 'danger')
    
    return redirect(url_for('inventory'))

@app.route('/inventory/delete/<int:item_id>', methods=['POST'])
def delete_inventory(item_id):
    try:
        item = Inventory.query.get(item_id)
        
        if item:
            db.session.delete(item)
            db.session.commit()
            flash('Inventory item deleted successfully!', 'success')
        else:
            flash('Inventory item not found!', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting inventory item: {str(e)}', 'danger')
    
    return redirect(url_for('inventory'))

@app.route('/inventory/search', methods=['GET'])
def search_inventory():
    query = request.args.get('q', '').lower()
    if not query:
        return redirect(url_for('inventory'))
    
    results = Inventory.query.filter(
        db.or_(
            Inventory.name.ilike(f'%{query}%'),
            Inventory.category.ilike(f'%{query}%'),
            Inventory.company.ilike(f'%{query}%'),
            Inventory.batch_no.ilike(f'%{query}%'),
            Inventory.supplier.ilike(f'%{query}%')
        )
    ).all()
    
    inventory_dict = [item.to_dict() for item in results]
    return render_template('inventory.html', inventory=inventory_dict, search_query=query)

@app.route('/inventory/import', methods=['POST'])
def import_inventory():
    if 'csv_file' not in request.files:
        flash('No file part', 'danger')
        return redirect(url_for('inventory'))
    
    file = request.files['csv_file']
    if file.filename == '':
        flash('No selected file', 'danger')
        return redirect(url_for('inventory'))
    
    if file:
        try:
            csv_data = file.read().decode('utf-8')
            df = pd.read_csv(StringIO(csv_data))
            
            # Convert column names to lowercase for case-insensitive matching
            df.columns = [col.lower() for col in df.columns]
            
            # Validate required columns (case-insensitive)
            required_columns = ['name', 'category', 'packing', 'company', 'batch_no', 'mrp', 
                              'quantity', 'shelf', 'tax_percentage', 'supplier', 'expiry_date']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                flash(f'Missing required columns: {", ".join(missing_columns)}', 'danger')
                return redirect(url_for('inventory'))
            
            # Process the data
            success_count = 0
            for _, row in df.iterrows():
                try:
                    item = Inventory(
                        name=row['name'],
                        category=row['category'],
                        packing=row['packing'],
                        company=row['company'],
                        batch_no=row['batch_no'],
                        mrp=float(row['mrp']),
                        quantity=int(row['quantity']),
                        shelf=row['shelf'],
                        tax_percentage=float(row['tax_percentage']),
                        supplier=row['supplier'],
                        supplier_email=row.get('supplier_email', ''),
                        expiry_date=row['expiry_date']
                    )
                    db.session.add(item)
                    success_count += 1
                except Exception as e:
                    logging.error(f"Error processing row: {str(e)}")
            
            db.session.commit()
            flash(f'Successfully imported {success_count} inventory items', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error importing inventory: {str(e)}', 'danger')
    
    return redirect(url_for('inventory'))

# Customer routes
@app.route('/customers')
def customers():
    customer_list = Customer.query.all()
    customer_dict = [customer.to_dict() for customer in customer_list]
    return render_template('customers.html', customers=customer_dict)

@app.route('/customers/add', methods=['POST'])
def add_customer():
    try:
        new_customer = Customer(
            name=request.form['name'],
            phone=request.form['phone'],
            email=request.form['email'],
            address=request.form['address'],
            medicine_preferences=request.form.get('medicine_preferences', '')
        )
        
        db.session.add(new_customer)
        db.session.commit()
        
        flash('Customer added successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding customer: {str(e)}', 'danger')
    
    return redirect(url_for('customers'))

@app.route('/customers/edit/<int:customer_id>', methods=['POST'])
def edit_customer(customer_id):
    try:
        customer = Customer.query.get(customer_id)
        
        if customer:
            customer.name = request.form['name']
            customer.phone = request.form['phone']
            customer.email = request.form['email']
            customer.address = request.form['address']
            customer.medicine_preferences = request.form.get('medicine_preferences', '')
            
            db.session.commit()
            flash('Customer updated successfully!', 'success')
        else:
            flash('Customer not found!', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating customer: {str(e)}', 'danger')
    
    return redirect(url_for('customers'))

@app.route('/customers/delete/<int:customer_id>', methods=['POST'])
def delete_customer(customer_id):
    try:
        customer = Customer.query.get(customer_id)
        
        if customer:
            db.session.delete(customer)
            db.session.commit()
            flash('Customer deleted successfully!', 'success')
        else:
            flash('Customer not found!', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting customer: {str(e)}', 'danger')
    
    return redirect(url_for('customers'))

@app.route('/customers/search', methods=['GET'])
def search_customers():
    query = request.args.get('q', '').lower()
    if not query:
        return redirect(url_for('customers'))
    
    results = Customer.query.filter(
        db.or_(
            Customer.name.ilike(f'%{query}%'),
            Customer.phone.ilike(f'%{query}%'),
            Customer.email.ilike(f'%{query}%')
        )
    ).all()
    
    customer_dict = [customer.to_dict() for customer in results]
    return render_template('customers.html', customers=customer_dict, search_query=query)

@app.route('/customers/import', methods=['POST'])
def import_customers():
    if 'csv_file' not in request.files:
        flash('No file part', 'danger')
        return redirect(url_for('customers'))
    
    file = request.files['csv_file']
    if file.filename == '':
        flash('No selected file', 'danger')
        return redirect(url_for('customers'))
    
    if file:
        try:
            csv_data = file.read().decode('utf-8')
            df = pd.read_csv(StringIO(csv_data))
            
            # Convert column names to lowercase for case-insensitive matching
            df.columns = [col.lower() for col in df.columns]
            
            # Validate required columns (case-insensitive)
            required_columns = ['name', 'phone', 'address']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                flash(f'Missing required columns: {", ".join(missing_columns)}', 'danger')
                return redirect(url_for('customers'))
            
            # Process the data
            success_count = 0
            for _, row in df.iterrows():
                try:
                    customer = Customer(
                        name=row['name'],
                        phone=row['phone'],
                        email=row.get('email', ''),
                        address=row['address'],
                        medicine_preferences=row.get('medicine_preferences', '')
                    )
                    db.session.add(customer)
                    success_count += 1
                except Exception as e:
                    logging.error(f"Error processing row: {str(e)}")
            
            db.session.commit()
            flash(f'Successfully imported {success_count} customers', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error importing customers: {str(e)}', 'danger')
    
    return redirect(url_for('customers'))

# Rename "sales" to "counters" as requested
@app.route('/counters')
def counters():
    counter_list = Counter.query.all()
    counter_dict = []
    
    for counter in counter_list:
        counter_data = counter.to_dict()
        counter_data['current_sale'] = current_sales.get(counter.id, [])
        counter_data['customer'] = None  # Will be populated if a customer is selected
        counter_dict.append(counter_data)
    
    inventory_items = Inventory.query.all()
    inventory_dict = [item.to_dict() for item in inventory_items]
    
    customer_list = Customer.query.all()
    customer_dict = [customer.to_dict() for customer in customer_list]
    
    return render_template('sales.html', counters=counter_dict, inventory=inventory_dict, customers=customer_dict)

@app.route('/counters/counter/<int:counter_id>/activate', methods=['POST'])
def activate_counter(counter_id):
    try:
        counter = Counter.query.get(counter_id)
        
        if counter:
            counter.active = True
            db.session.commit()
            
            # Initialize current sale for this counter
            current_sales[counter_id] = []
            
            flash('Counter activated successfully!', 'success')
        else:
            flash('Counter not found!', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error activating counter: {str(e)}', 'danger')
    
    return redirect(url_for('counters'))

@app.route('/counters/counter/<int:counter_id>/deactivate', methods=['POST'])
def deactivate_counter(counter_id):
    try:
        counter = Counter.query.get(counter_id)
        
        if counter:
            counter.active = False
            db.session.commit()
            
            # Clear current sale for this counter
            if counter_id in current_sales:
                del current_sales[counter_id]
            
            flash('Counter deactivated successfully!', 'success')
        else:
            flash('Counter not found!', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deactivating counter: {str(e)}', 'danger')
    
    return redirect(url_for('counters'))

@app.route('/counters/counter/<int:counter_id>/add_item', methods=['POST'])
def add_item_to_sale(counter_id):
    try:
        item_id = int(request.form['item_id'])
        quantity = int(request.form['quantity'])
        
        # Find the inventory item
        item = Inventory.query.get(item_id)
        if not item:
            return jsonify({'success': False, 'message': 'Item not found!'})
        
        if item.quantity < quantity:
            return jsonify({'success': False, 'message': 'Not enough stock available!'})
        
        # Calculate price with tax
        price = item.mrp
        tax_amount = price * (item.tax_percentage / 100)
        total_price = price * quantity
        total_tax = tax_amount * quantity
        
        # Add item to the sale
        sale_item = {
            'id': item.id,
            'name': item.name,
            'batch_no': item.batch_no,
            'packing': item.packing,
            'shelf': item.shelf,
            'expiry_date': item.expiry_date,
            'price': price,
            'tax_percentage': item.tax_percentage,
            'tax_amount': tax_amount,
            'quantity': quantity,
            'total_price': total_price,
            'total_tax': total_tax
        }
        
        # Initialize current sale for this counter if not exists
        if counter_id not in current_sales:
            current_sales[counter_id] = []
        
        # Check if item already exists in the sale
        for i, existing_item in enumerate(current_sales[counter_id]):
            if existing_item['id'] == item_id:
                # Update quantity and totals
                current_sales[counter_id][i]['quantity'] += quantity
                current_sales[counter_id][i]['total_price'] += total_price
                current_sales[counter_id][i]['total_tax'] += total_tax
                break
        else:
            # Add new item to sale
            current_sales[counter_id].append(sale_item)
        
        # Calculate sale totals
        total_amount = sum(item['total_price'] for item in current_sales[counter_id])
        total_tax = sum(item['total_tax'] for item in current_sales[counter_id])
        
        return jsonify({
            'success': True, 
            'message': 'Item added to sale!',
            'sale_items': current_sales[counter_id],
            'total_amount': total_amount,
            'total_tax': total_tax
        })
    except Exception as e:
        logging.error(f'Error adding item to sale: {str(e)}')
        return jsonify({'success': False, 'message': f'Error adding item to sale: {str(e)}'})

@app.route('/counters/counter/<int:counter_id>/remove_item', methods=['POST'])
def remove_item_from_sale(counter_id):
    try:
        item_id = int(request.form['item_id'])
        
        # Check if counter has an active sale
        if counter_id not in current_sales:
            return jsonify({'success': False, 'message': 'No active sale for this counter!'})
        
        # Find and remove the item
        for i, item in enumerate(current_sales[counter_id]):
            if item['id'] == item_id:
                current_sales[counter_id].pop(i)
                break
        else:
            return jsonify({'success': False, 'message': 'Item not found in current sale!'})
        
        # Calculate updated totals
        total_amount = sum(item['total_price'] for item in current_sales[counter_id])
        total_tax = sum(item['total_tax'] for item in current_sales[counter_id])
        
        return jsonify({
            'success': True,
            'message': 'Item removed from sale!',
            'sale_items': current_sales[counter_id],
            'total_amount': total_amount,
            'total_tax': total_tax
        })
    except Exception as e:
        logging.error(f'Error removing item from sale: {str(e)}')
        return jsonify({'success': False, 'message': f'Error removing item from sale: {str(e)}'})

# ******************************************************************************************************************************************************************************************************************************************************
# @app.route('/counters/counter/<int:counter_id>/set_customer', methods=['POST'])
# def set_customer_for_sale(counter_id):
#     try:
#         customer_id = int(request.form['customer_id'])
        
#         # Find the customer
#         customer = Customer.query.get(customer_id)
#         if not customer:
#             return jsonify({'success': False, 'message': 'Customer not found!'})
        
#         # Set customer for the sale
#         session[f'counter_{counter_id}_customer'] = customer.to_dict()
        
#         return jsonify({
#             'success': True,
#             'message': 'Customer set for sale!',
#             'customer': customer.to_dict()
#         })
#     except Exception as e:
#         logging.error(f'Error setting customer for sale: {str(e)}')
#         return jsonify({'success': False, 'message': f'Error setting customer for sale: {str(e)}'})

@app.route('/counters/counter/<int:counter_id>/set_customer', methods=['POST'])
def set_customer_for_sale(counter_id):
    try:
        # Convert the customer_id from the form to integer
        customer_id = int(request.form['customer_id'])
        
        # Fetch the customer record from the database
        customer = Customer.query.get(customer_id)
        if not customer:
            return jsonify({'success': False, 'message': 'Customer not found!'})
        
        # Store the customer's details in the session for the specified counter
        session[f'counter_{counter_id}_customer'] = customer.to_dict()
        
        return jsonify({
            'success': True,
            'message': 'Customer set for sale!',
            'customer': customer.to_dict()
        })
    except Exception as e:
        logging.error(f'Error setting customer for sale: {str(e)}')
        return jsonify({
            'success': False, 
            'message': f'Error setting customer for sale: {str(e)}'
        })

# ******************************************************************************************************************************************************************************************************************************************************

@app.route('/counters/counter/<int:counter_id>/complete_sale', methods=['POST'])
def complete_sale(counter_id):
    try:
        # Read JSON data from the request body
        data = request.get_json()
        if not data or 'items' not in data or not data['items']:
            return jsonify({'success': False, 'message': 'No items in the current sale!'})
        
        items = data['items']
        
        # Get customer from session if set
        customer_id = None
        if f'counter_{counter_id}_customer' in session:
            customer_data = session[f'counter_{counter_id}_customer']
            customer_id = customer_data.get('id')
        
        # Calculate totals from the items
        total_amount = 0
        total_tax = 0
        for item in items:
            price = float(item.get('price', 0))
            quantity = int(item.get('quantity', 1))
            tax_amount = float(item.get('tax_amount', 0))
            total_amount += price * quantity
            total_tax += tax_amount * quantity
        
        # Create a new sale record
        new_sale = Sale(
            counter_id=counter_id,
            customer_id=customer_id,
            total_amount=total_amount,
            total_tax=total_tax
        )
        db.session.add(new_sale)
        db.session.flush()  # Generate new_sale.id
        
        # Create sale items and update inventory
        for item_data in items:
            sale_item = SaleItem(
                sale_id=new_sale.id,
                inventory_id=item_data['id'],
                name=item_data['name'],
                batch_no=item_data['batch_no'],
                packing=item_data['packing'],
                expiry_date=item_data['expiry_date'],
                price=item_data['price'],
                tax_percentage=item_data['tax_percentage'],
                tax_amount=item_data['tax_amount'],
                quantity=item_data['quantity'],
                total_price=item_data['total_price']
            )
            db.session.add(sale_item)
            
            # Update inventory quantity
            inventory_item = Inventory.query.get(item_data['id'])
            if inventory_item:
                inventory_item.quantity -= int(item_data['quantity'])
        
        db.session.commit()
        
        # Clear customer information from session
        if f'counter_{counter_id}_customer' in session:
            del session[f'counter_{counter_id}_customer']
        
        sale_with_items = Sale.query.get(new_sale.id)
        return jsonify({
            'success': True,
            'message': 'Sale completed successfully!',
            'sale': sale_with_items.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        logging.error(f'Error completing sale: {str(e)}')
        return jsonify({'success': False, 'message': f'Error completing sale: {str(e)}'})

# Bills
@app.route('/bills')
def bills():
    # Get filter parameters
    page = request.args.get('page', 1, type=int)
    date_from = request.args.get('date_from', None)
    date_to = request.args.get('date_to', None)
    customer = request.args.get('customer', None)
    
    # Start with base query
    query = Sale.query
    
    # Apply filters if provided
    if date_from:
        date_from_obj = datetime.strptime(date_from, '%Y-%m-%d')
        query = query.filter(Sale.date >= date_from_obj)
    
    if date_to:
        date_to_obj = datetime.strptime(date_to, '%Y-%m-%d')
        # Add one day to include the end date fully
        date_to_obj = date_to_obj.replace(hour=23, minute=59, second=59)
        query = query.filter(Sale.date <= date_to_obj)
    
    if customer:
        # Join with Customer table and filter by name
        query = query.join(Sale.customer).filter(Customer.name.ilike(f'%{customer}%'))
    
    # Order by date, most recent first
    query = query.order_by(Sale.date.desc())
    
    # Pagination
    per_page = 10
    bills_pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    bills = [bill.to_dict() for bill in bills_pagination.items]
    
    return render_template(
        'bills.html', 
        bills=bills,
        page=page,
        pages=bills_pagination.pages,
        date_from=date_from,
        date_to=date_to,
        customer=customer
    )

# Reports
@app.route('/reports')
def reports():
    return render_template('reports.html')

# **********************************************************************************************************************************************************************************************************************************

@app.route('/generate_bill/<int:sale_id>')
def generate_bill(sale_id):
    try:
        sale = Sale.query.get(sale_id)
        if not sale:
            flash('Sale not found!', 'danger')
            return redirect(url_for('reports'))
        
        # Render the bill template as HTML
        rendered = render_template('bill_template.html', sale=sale.to_dict())
        # Return the rendered HTML directly instead of converting to PDF
        return rendered
    except Exception as e:
        flash(f'Error generating bill: {str(e)}', 'danger')
        return redirect(url_for('reports'))


# **********************************************************************************************************************************************************************************************************************************

# Error handlers
@app.errorhandler(404)
def not_found(e):
    return render_template('error.html', error='404 - Page Not Found'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('error.html', error='500 - Internal Server Error'), 500

# API endpoints for AJAX calls
@app.route('/api/inventory/search', methods=['GET'])
def api_search_inventory():
    query = request.args.get('q', '').lower()
    if not query or len(query) < 2:
        return jsonify([])
    
    results = Inventory.query.filter(
        db.or_(
            Inventory.name.ilike(f'%{query}%'),
            Inventory.category.ilike(f'%{query}%'),
            Inventory.company.ilike(f'%{query}%'),
            Inventory.batch_no.ilike(f'%{query}%')
        )
    ).all()
    
    return jsonify([item.to_dict() for item in results])

@app.route('/api/customers/search', methods=['GET'])
def api_search_customers():
    query = request.args.get('q', '').lower()
    if not query or len(query) < 2:
        return jsonify([])
    
    results = Customer.query.filter(
        db.or_(
            Customer.name.ilike(f'%{query}%'),
            Customer.phone.ilike(f'%{query}%'),
            Customer.email.ilike(f'%{query}%')
        )
    ).all()
    
    return jsonify([customer.to_dict() for customer in results])

# Initialize the database and create tables
def initialize_database():
    with app.app_context():
        db.create_all()
        
        # Initialize 8 counters if they don't exist
        counters_count = Counter.query.count()
        if counters_count < 8:
            for i in range(1, 9):
                if not Counter.query.filter_by(id=i).first():
                    counter = Counter(id=i, active=(i == 1))  # First counter is active by default
                    db.session.add(counter)
            db.session.commit()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)