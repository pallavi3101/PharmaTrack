import os
import logging
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
import pandas as pd
from io import StringIO

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Database setup
class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "pharmatrack_secret_key")

# Configure database
db_uri = os.environ.get("DATABASE_URL")
if not db_uri:
    # Use SQLite as a fallback
    db_uri = "sqlite:///pharmatrack.db"

app.config["SQLALCHEMY_DATABASE_URI"] = db_uri
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize app with SQLAlchemy
db.init_app(app)

# Define models
class Inventory(db.Model):
    __tablename__ = "inventory"
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    packing = db.Column(db.String(50), nullable=False)
    company = db.Column(db.String(100), nullable=False)
    batch_no = db.Column(db.String(50), nullable=False)
    mrp = db.Column(db.Float, nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    shelf = db.Column(db.String(50), nullable=False)
    tax_percentage = db.Column(db.Float, nullable=False)
    supplier = db.Column(db.String(100), nullable=False)
    supplier_email = db.Column(db.String(100), nullable=True)
    expiry_date = db.Column(db.String(10), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    # Relationship with SaleItem
    sale_items = db.relationship("SaleItem", back_populates="inventory_item")
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "category": self.category,
            "packing": self.packing,
            "company": self.company,
            "batch_no": self.batch_no,
            "mrp": self.mrp,
            "quantity": self.quantity,
            "shelf": self.shelf,
            "tax_percentage": self.tax_percentage,
            "supplier": self.supplier,
            "supplier_email": self.supplier_email,
            "expiry_date": self.expiry_date,
            "created_at": self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None
        }


class Customer(db.Model):
    __tablename__ = "customers"
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(100), nullable=True)
    address = db.Column(db.Text, nullable=False)
    medicine_preferences = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    # Relationship with Sale
    sales = db.relationship("Sale", back_populates="customer")
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "phone": self.phone,
            "email": self.email,
            "address": self.address,
            "medicine_preferences": self.medicine_preferences,
            "created_at": self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None
        }


class Counter(db.Model):
    __tablename__ = "counters"
    
    id = db.Column(db.Integer, primary_key=True)
    active = db.Column(db.Boolean, default=False)
    
    # Relationship with Sale
    sales = db.relationship("Sale", back_populates="counter")
    
    def to_dict(self):
        return {
            "id": self.id,
            "active": self.active
        }


class Sale(db.Model):
    __tablename__ = "sales"
    
    id = db.Column(db.Integer, primary_key=True)
    counter_id = db.Column(db.Integer, db.ForeignKey("counters.id"), nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey("customers.id"), nullable=True)
    date = db.Column(db.DateTime, default=datetime.now)
    total_amount = db.Column(db.Float, default=0)
    total_tax = db.Column(db.Float, default=0)
    
    # Relationships
    counter = db.relationship("Counter", back_populates="sales")
    customer = db.relationship("Customer", back_populates="sales")
    items = db.relationship("SaleItem", back_populates="sale", cascade="all, delete-orphan")
    
    def to_dict(self):
        return {
            "id": self.id,
            "counter_id": self.counter_id,
            "customer_id": self.customer_id,
            "customer": self.customer.to_dict() if self.customer else None,
            "date": self.date.strftime('%Y-%m-%d %H:%M:%S') if self.date else None,
            "total_amount": self.total_amount,
            "total_tax": self.total_tax,
            "items": [item.to_dict() for item in self.items]
        }


class SaleItem(db.Model):
    __tablename__ = "sale_items"
    
    id = db.Column(db.Integer, primary_key=True)
    sale_id = db.Column(db.Integer, db.ForeignKey("sales.id"), nullable=False)
    inventory_id = db.Column(db.Integer, db.ForeignKey("inventory.id"), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    batch_no = db.Column(db.String(50), nullable=False)
    packing = db.Column(db.String(50), nullable=False)
    expiry_date = db.Column(db.String(10), nullable=False)
    price = db.Column(db.Float, nullable=False)
    tax_percentage = db.Column(db.Float, nullable=False)
    tax_amount = db.Column(db.Float, nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    
    # Relationships
    sale = db.relationship("Sale", back_populates="items")
    inventory_item = db.relationship("Inventory", back_populates="sale_items")
    
    def to_dict(self):
        return {
            "id": self.id,
            "sale_id": self.sale_id,
            "inventory_id": self.inventory_id,
            "name": self.name,
            "batch_no": self.batch_no,
            "packing": self.packing,
            "expiry_date": self.expiry_date,
            "price": self.price,
            "tax_percentage": self.tax_percentage,
            "tax_amount": self.tax_amount,
            "quantity": self.quantity,
            "total_price": self.total_price
        }


# Store current sales in memory (will be replaced with database storage in the future)
current_sales = {}  # counter_id -> CurrentSale

# Routes
@app.route('/')
def index():
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    with app.app_context():
        # Count low stock items (less than 10 units)
        low_stock_count = Inventory.query.filter(Inventory.quantity < 10).count()
        
        # Count expiring items (within 30 days)
        today = datetime.now()
        thirty_days_later = today.strftime('%Y-%m-%d')
        expiring_soon = Inventory.query.filter(Inventory.expiry_date <= thirty_days_later).count()
        
        # Count total customers
        total_customers = Customer.query.count()
        
        # Calculate total sales
        total_sales = db.session.query(db.func.sum(Sale.total_amount)).scalar() or 0
        
        # Get recent sales
        recent_sales = Sale.query.order_by(Sale.date.desc()).limit(5).all()
        recent_sales_dict = [sale.to_dict() for sale in recent_sales]
        
        return render_template(
            'dashboard.html', 
            low_stock_count=low_stock_count,
            expiring_soon=expiring_soon,
            total_customers=total_customers,
            total_sales=total_sales,
            recent_sales=recent_sales_dict
        )

# Inventory routes
@app.route('/inventory')
def inventory():
    inventory_items = Inventory.query.all()
    inventory_dict = [item.to_dict() for item in inventory_items]
    return render_template('inventory.html', inventory=inventory_dict)

@app.route('/inventory/add', methods=['POST'])
def add_inventory():
    try:
        # Create new inventory item
        new_item = Inventory(
            name=request.form['name'],
            category=request.form['category'],
            packing=request.form['packing'],
            company=request.form['company'],
            batch_no=request.form['batch_no'],
            mrp=float(request.form['mrp']),
            quantity=int(request.form['quantity']),
            shelf=request.form['shelf'],
            tax_percentage=float(request.form['tax_percentage']),
            supplier=request.form['supplier'],
            supplier_email=request.form.get('supplier_email', ''),
            expiry_date=request.form['expiry_date']
        )
        
        db.session.add(new_item)
        db.session.commit()
        
        flash('Inventory item added successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding inventory item: {str(e)}', 'danger')
    
    return redirect(url_for('inventory'))

@app.route('/inventory/edit/<int:item_id>', methods=['POST'])
def edit_inventory(item_id):
    try:
        item = Inventory.query.get(item_id)
        
        if item:
            item.name = request.form['name']
            item.category = request.form['category']
            item.packing = request.form['packing']
            item.company = request.form['company']
            item.batch_no = request.form['batch_no']
            item.mrp = float(request.form['mrp'])
            item.quantity = int(request.form['quantity'])
            item.shelf = request.form['shelf']
            item.tax_percentage = float(request.form['tax_percentage'])
            item.supplier = request.form['supplier']
            item.supplier_email = request.form.get('supplier_email', '')
            item.expiry_date = request.form['expiry_date']
            
            db.session.commit()
            flash('Inventory item updated successfully!', 'success')
        else:
            flash('Inventory item not found!', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating inventory item: {str(e)}', 'danger')
    
    return redirect(url_for('inventory'))

@app.route('/inventory/delete/<int:item_id>', methods=['POST'])
def delete_inventory(item_id):
    try:
        item = Inventory.query.get(item_id)
        
        if item:
            db.session.delete(item)
            db.session.commit()
            flash('Inventory item deleted successfully!', 'success')
        else:
            flash('Inventory item not found!', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting inventory item: {str(e)}', 'danger')
    
    return redirect(url_for('inventory'))

@app.route('/inventory/search', methods=['GET'])
def search_inventory():
    query = request.args.get('q', '').lower()
    if not query:
        return redirect(url_for('inventory'))
    
    results = Inventory.query.filter(
        db.or_(
            Inventory.name.ilike(f'%{query}%'),
            Inventory.category.ilike(f'%{query}%'),
            Inventory.company.ilike(f'%{query}%'),
            Inventory.batch_no.ilike(f'%{query}%'),
            Inventory.supplier.ilike(f'%{query}%')
        )
    ).all()
    
    inventory_dict = [item.to_dict() for item in results]
    return render_template('inventory.html', inventory=inventory_dict, search_query=query)

@app.route('/inventory/import', methods=['POST'])
def import_inventory():
    if 'csv_file' not in request.files:
        flash('No file part', 'danger')
        return redirect(url_for('inventory'))
    
    file = request.files['csv_file']
    if file.filename == '':
        flash('No selected file', 'danger')
        return redirect(url_for('inventory'))
    
    if file:
        try:
            csv_data = file.read().decode('utf-8')
            df = pd.read_csv(StringIO(csv_data))
            
            # Convert column names to lowercase for case-insensitive matching
            df.columns = [col.lower() for col in df.columns]
            
            # Validate required columns (case-insensitive)
            required_columns = ['name', 'category', 'packing', 'company', 'batch_no', 'mrp', 
                              'quantity', 'shelf', 'tax_percentage', 'supplier', 'expiry_date']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                flash(f'Missing required columns: {", ".join(missing_columns)}', 'danger')
                return redirect(url_for('inventory'))
            
            # Process the data
            success_count = 0
            for _, row in df.iterrows():
                try:
                    item = Inventory(
                        name=row['name'],
                        category=row['category'],
                        packing=row['packing'],
                        company=row['company'],
                        batch_no=row['batch_no'],
                        mrp=float(row['mrp']),
                        quantity=int(row['quantity']),
                        shelf=row['shelf'],
                        tax_percentage=float(row['tax_percentage']),
                        supplier=row['supplier'],
                        supplier_email=row.get('supplier_email', ''),
                        expiry_date=row['expiry_date']
                    )
                    db.session.add(item)
                    success_count += 1
                except Exception as e:
                    logging.error(f"Error processing row: {str(e)}")
            
            db.session.commit()
            flash(f'Successfully imported {success_count} inventory items', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error importing inventory: {str(e)}', 'danger')
    
    return redirect(url_for('inventory'))

# Customer routes
@app.route('/customers')
def customers():
    customer_list = Customer.query.all()
    customer_dict = [customer.to_dict() for customer in customer_list]
    return render_template('customers.html', customers=customer_dict)

@app.route('/customers/add', methods=['POST'])
def add_customer():
    try:
        new_customer = Customer(
            name=request.form['name'],
            phone=request.form['phone'],
            email=request.form['email'],
            address=request.form['address'],
            medicine_preferences=request.form.get('medicine_preferences', '')
        )
        
        db.session.add(new_customer)
        db.session.commit()
        
        flash('Customer added successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding customer: {str(e)}', 'danger')
    
    return redirect(url_for('customers'))

@app.route('/customers/edit/<int:customer_id>', methods=['POST'])
def edit_customer(customer_id):
    try:
        customer = Customer.query.get(customer_id)
        
        if customer:
            customer.name = request.form['name']
            customer.phone = request.form['phone']
            customer.email = request.form['email']
            customer.address = request.form['address']
            customer.medicine_preferences = request.form.get('medicine_preferences', '')
            
            db.session.commit()
            flash('Customer updated successfully!', 'success')
        else:
            flash('Customer not found!', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating customer: {str(e)}', 'danger')
    
    return redirect(url_for('customers'))

@app.route('/customers/delete/<int:customer_id>', methods=['POST'])
def delete_customer(customer_id):
    try:
        customer = Customer.query.get(customer_id)
        
        if customer:
            db.session.delete(customer)
            db.session.commit()
            flash('Customer deleted successfully!', 'success')
        else:
            flash('Customer not found!', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting customer: {str(e)}', 'danger')
    
    return redirect(url_for('customers'))

@app.route('/customers/search', methods=['GET'])
def search_customers():
    query = request.args.get('q', '').lower()
    if not query:
        return redirect(url_for('customers'))
    
    results = Customer.query.filter(
        db.or_(
            Customer.name.ilike(f'%{query}%'),
            Customer.phone.ilike(f'%{query}%'),
            Customer.email.ilike(f'%{query}%')
        )
    ).all()
    
    customer_dict = [customer.to_dict() for customer in results]
    return render_template('customers.html', customers=customer_dict, search_query=query)

@app.route('/customers/import', methods=['POST'])
def import_customers():
    if 'csv_file' not in request.files:
        flash('No file part', 'danger')
        return redirect(url_for('customers'))
    
    file = request.files['csv_file']
    if file.filename == '':
        flash('No selected file', 'danger')
        return redirect(url_for('customers'))
    
    if file:
        try:
            csv_data = file.read().decode('utf-8')
            df = pd.read_csv(StringIO(csv_data))
            
            # Convert column names to lowercase for case-insensitive matching
            df.columns = [col.lower() for col in df.columns]
            
            # Validate required columns (case-insensitive)
            required_columns = ['name', 'phone', 'address']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                flash(f'Missing required columns: {", ".join(missing_columns)}', 'danger')
                return redirect(url_for('customers'))
            
            # Process the data
            success_count = 0
            for _, row in df.iterrows():
                try:
                    customer = Customer(
                        name=row['name'],
                        phone=row['phone'],
                        email=row.get('email', ''),
                        address=row['address'],
                        medicine_preferences=row.get('medicine_preferences', '')
                    )
                    db.session.add(customer)
                    success_count += 1
                except Exception as e:
                    logging.error(f"Error processing row: {str(e)}")
            
            db.session.commit()
            flash(f'Successfully imported {success_count} customers', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error importing customers: {str(e)}', 'danger')
    
    return redirect(url_for('customers'))

# Rename "sales" to "counters" as requested
@app.route('/counters')
def counters():
    counter_list = Counter.query.all()
    counter_dict = []
    
    for counter in counter_list:
        counter_data = counter.to_dict()
        counter_data['current_sale'] = current_sales.get(counter.id, [])
        counter_data['customer'] = None  # Will be populated if a customer is selected
        counter_dict.append(counter_data)
    
    inventory_items = Inventory.query.all()
    inventory_dict = [item.to_dict() for item in inventory_items]
    
    customer_list = Customer.query.all()
    customer_dict = [customer.to_dict() for customer in customer_list]
    
    return render_template('sales.html', counters=counter_dict, inventory=inventory_dict, customers=customer_dict)

# Error handlers
@app.errorhandler(404)
def not_found(e):
    return render_template('error.html', error='404 - Page Not Found'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('error.html', error='500 - Internal Server Error'), 500

# API endpoints for AJAX calls
@app.route('/api/inventory/search', methods=['GET'])
def api_search_inventory():
    query = request.args.get('q', '').lower()
    if not query or len(query) < 2:
        return jsonify([])
    
    results = Inventory.query.filter(
        db.or_(
            Inventory.name.ilike(f'%{query}%'),
            Inventory.category.ilike(f'%{query}%'),
            Inventory.company.ilike(f'%{query}%'),
            Inventory.batch_no.ilike(f'%{query}%')
        )
    ).all()
    
    return jsonify([item.to_dict() for item in results])

@app.route('/api/customers/search', methods=['GET'])
def api_search_customers():
    query = request.args.get('q', '').lower()
    if not query or len(query) < 2:
        return jsonify([])
    
    results = Customer.query.filter(
        db.or_(
            Customer.name.ilike(f'%{query}%'),
            Customer.phone.ilike(f'%{query}%'),
            Customer.email.ilike(f'%{query}%')
        )
    ).all()
    
    return jsonify([customer.to_dict() for customer in results])

# Initialize the database and create tables
@app.before_first_request
def initialize_database():
    db.create_all()
    
    # Initialize 8 counters if they don't exist
    counters_count = Counter.query.count()
    if counters_count < 8:
        for i in range(1, 9):
            if not Counter.query.filter_by(id=i).first():
                counter = Counter(id=i, active=(i == 1))  # First counter is active by default
                db.session.add(counter)
        db.session.commit()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)