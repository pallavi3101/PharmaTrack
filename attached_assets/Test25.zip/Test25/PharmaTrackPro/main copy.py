from app import app, db, initialize_database

if __name__ == "__main__":
    # Initialize the database and tables
    initialize_database()

    # Run the application
    app.run(host="0.0.0.0", port=5000, debug=True)