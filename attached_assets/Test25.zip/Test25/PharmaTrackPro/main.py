from app import app, db

if __name__ == "__main__":
    with app.app_context():
        # Uncomment the following line if you need to drop existing tables (development only)
        # db.drop_all()
        db.create_all()  # Create tables with the updated schema from models.py
    app.run(host="0.0.0.0", port=9611, debug=True)