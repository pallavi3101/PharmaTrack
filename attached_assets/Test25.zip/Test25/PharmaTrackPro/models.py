from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Text, Boolean, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from db import db
from werkzeug.security import generate_password_hash, check_password_hash

class Inventory(db.Model):
    __tablename__ = "inventory"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)  # Link to the User
    name = Column(String(100), nullable=False)
    category = Column(String(50), nullable=False)
    packing = Column(String(50), nullable=False)
    company = Column(String(100), nullable=False)
    batch_no = Column(String(50), nullable=False)
    mrp = Column(Float, nullable=False)
    quantity = Column(Integer, nullable=False)
    shelf = Column(String(50), nullable=False)
    tax_percentage = Column(Float, nullable=False)
    supplier = Column(String(100), nullable=False)
    supplier_email = Column(String(100), nullable=True)
    expiry_date = Column(String(10), nullable=False)
    created_at = Column(DateTime, default=datetime.now)
    
    # Relationship with SaleItem
    sale_items = relationship("SaleItem", back_populates="inventory_item")
    # Relationship back to User (owner)
    user = relationship("User", back_populates="inventory_items")
    
    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "name": self.name,
            "category": self.category,
            "packing": self.packing,
            "company": self.company,
            "batch_no": self.batch_no,
            "mrp": self.mrp,
            "quantity": self.quantity,
            "shelf": self.shelf,
            "tax_percentage": self.tax_percentage,
            "supplier": self.supplier,
            "supplier_email": self.supplier_email,
            "expiry_date": self.expiry_date,
            "created_at": self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None
        }

class Customer(db.Model):
    __tablename__ = "customers"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)  # Link to the User
    name = Column(String(100), nullable=False)
    phone = Column(String(20), nullable=False)
    email = Column(String(100), nullable=True)
    address = Column(Text, nullable=False)
    medicine_preferences = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    
    # Relationship with Sale
    sales = relationship("Sale", back_populates="customer")
    # Relationship back to User
    user = relationship("User", back_populates="customers")
    
    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "name": self.name,
            "phone": self.phone,
            "email": self.email,
            "address": self.address,
            "medicine_preferences": self.medicine_preferences,
            "created_at": self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None
        }

class Counter(db.Model):
    __tablename__ = "counters"
    
    id = Column(Integer, primary_key=True)
    active = Column(Boolean, default=False)
    
    # Relationship with Sale
    sales = relationship("Sale", back_populates="counter")
    
    def to_dict(self):
        return {
            "id": self.id,
            "active": self.active
        }

class Sale(db.Model):
    __tablename__ = "sales"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)  # Link to the User
    counter_id = Column(Integer, ForeignKey("counters.id"), nullable=False)
    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=True)
    date = Column(DateTime, default=datetime.now)
    total_amount = Column(Float, default=0)
    total_tax = Column(Float, default=0)
    
    # Relationships
    counter = relationship("Counter", back_populates="sales")
    customer = relationship("Customer", back_populates="sales")
    items = relationship("SaleItem", back_populates="sale", cascade="all, delete-orphan")
    # Relationship back to User
    user = relationship("User", back_populates="sales")
    
    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "counter_id": self.counter_id,
            "customer_id": self.customer_id,
            "customer": self.customer.to_dict() if self.customer else None,
            "date": self.date.strftime('%Y-%m-%d %H:%M:%S') if self.date else None,
            "total_amount": self.total_amount,
            "total_tax": self.total_tax,
            "items": [item.to_dict() for item in self.items]
        }

class SaleItem(db.Model):
    __tablename__ = "sale_items"
    
    id = Column(Integer, primary_key=True)
    sale_id = Column(Integer, ForeignKey("sales.id"), nullable=False)
    inventory_id = Column(Integer, ForeignKey("inventory.id"), nullable=False)
    name = Column(String(100), nullable=False)
    batch_no = Column(String(50), nullable=False)
    packing = Column(String(50), nullable=False)
    expiry_date = Column(String(10), nullable=False)
    price = Column(Float, nullable=False)
    tax_percentage = Column(Float, nullable=False)
    tax_amount = Column(Float, nullable=False)
    quantity = Column(Integer, nullable=False)
    total_price = Column(Float, nullable=False)
    
    # Relationships
    sale = relationship("Sale", back_populates="items")
    inventory_item = relationship("Inventory", back_populates="sale_items")
    
    def to_dict(self):
        return {
            "id": self.id,
            "sale_id": self.sale_id,
            "inventory_id": self.inventory_id,
            "name": self.name,
            "batch_no": self.batch_no,
            "packing": self.packing,
            "expiry_date": self.expiry_date,
            "price": self.price,
            "tax_percentage": self.tax_percentage,
            "tax_amount": self.tax_amount,
            "quantity": self.quantity,
            "total_price": self.total_price,
            "shelf": self.inventory_item.shelf if self.inventory_item else ""
        }

    @staticmethod
    def get_most_least_sold():
        from sqlalchemy.sql import func
        # Aggregate total quantities sold per product
        sales_count = db.session.query(
            Inventory.name,
            func.sum(SaleItem.quantity).label("total_sold")
        ).join(Inventory).group_by(Inventory.name).order_by(func.sum(SaleItem.quantity).desc()).all()

        if not sales_count:
            return None, None

        most_sold = sales_count[0]
        # If only one product exists, both most and least are the same
        least_sold = sales_count[-1] if len(sales_count) > 1 else most_sold

        return most_sold, least_sold

class User(db.Model):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    username = Column(String(80), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    phone = Column(String(20), nullable=False)  # New field for phone number
    shop_name = Column(String(150), nullable=False)      # Shop Name
    shop_address = Column(Text, nullable=False)          # Shop Address
    password_hash = Column(String(128), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships: User can have many inventory items, customers, and sales.
    inventory_items = relationship("Inventory", back_populates="user", cascade="all, delete-orphan")
    customers = relationship("Customer", back_populates="user", cascade="all, delete-orphan")
    sales = relationship("Sale", back_populates="user", cascade="all, delete-orphan")
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def to_dict(self):
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "phone": self.phone,
            "shop_name": self.shop_name,
            "shop_address": self.shop_address,
            "created_at": self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None
        }

class CurrentSale:
    """Helper class to manage current sale state for each counter."""
    def __init__(self, counter_id):
        self.counter_id = counter_id
        self.customer_id = None
        self.items = []
        self.total_amount = 0
        self.total_tax = 0
