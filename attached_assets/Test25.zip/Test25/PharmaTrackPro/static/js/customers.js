/**
 * PharmaTrack - Customer Management JavaScript
 * Contains functionality specific to customer management
 */

document.addEventListener('DOMContentLoaded', function () {
    // Initialize add customer form
    initializeCustomerForm();

    // Initialize customer table handlers
    initializeCustomerTable();

    // Setup search functionality
    setupCustomerSearch();

    // Setup CSV import
    setupCSVImport();
    
    // Setup DELETE button with AJAX using fetch
    setupDeleteCustomerButtons();
});

// Initialize customer form
function initializeCustomerForm() {
    const addCustomerBtn = document.getElementById('addCustomerBtn');
    const customerForm = document.getElementById('customerForm');
    const cancelCustomerBtn = document.getElementById('cancelCustomerBtn');

    if (!addCustomerBtn || !customerForm || !cancelCustomerBtn) return;

    // Show form when add button is clicked
    addCustomerBtn.addEventListener('click', function () {
        customerForm.reset();
        // Clear hidden id field
        const idField = document.getElementById('customerId');
        if (idField) idField.value = '';
        // Change form title to add
        const formTitle = document.getElementById('customerFormTitle');
        if (formTitle) formTitle.textContent = 'Add New Customer';
        // Set form action to add customer route
        customerForm.action = '/customer/add';
        // Show form and hide customer list
        document.getElementById('customerFormContainer').style.display = 'block';
        document.getElementById('customerListContainer').style.display = 'none';
    });

    // Hide form when cancel button is clicked
    cancelCustomerBtn.addEventListener('click', function () {
        document.getElementById('customerFormContainer').style.display = 'none';
        document.getElementById('customerListContainer').style.display = 'block';
    });

    // Validate form before submit
    customerForm.addEventListener('submit', function (e) {
        if (!validateForm('customerForm')) {
            e.preventDefault();
        }
    });
}

// Initialize customer table handlers
function initializeCustomerTable() {
    const customerTable = document.getElementById('customerTable');
    if (!customerTable) return;

    // Setup edit buttons
    const editButtons = document.querySelectorAll('.edit-customer-btn');
    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            const customerId = this.getAttribute('data-id');
            editCustomer(customerId);
        });
    });

    // Setup view buttons
    const viewButtons = document.querySelectorAll('.view-customer-btn');
    viewButtons.forEach(button => {
        button.addEventListener('click', function () {
            const customerId = this.getAttribute('data-id');
            viewCustomer(customerId);
        });
    });
}

// Setup DELETE buttons using AJAX
function setupDeleteCustomerButtons() {
    const deleteButtons = document.querySelectorAll('.delete-customer-btn');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function () {
            const customerId = this.getAttribute('data-id');
            const customerName = this.getAttribute('data-name');
            if (confirm(`Are you sure you want to delete ${customerName}?`)) {
                fetch(`/delete_customer/${customerId}`, {
                    method: 'DELETE',
                    headers: {
                        "Content-Type": "application/json",
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload(); // Refresh the page to update the list
                    } else {
                        alert("Error: " + data.message);
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    alert("An error occurred. Please try again.");
                });
            }
        });
    });
}

// Edit customer: Prefill the form using data attributes from the edit button
function editCustomer(customerId) {
    showLoading();

    const button = document.querySelector(`.edit-customer-btn[data-id="${customerId}"]`);
    if (!button) {
        hideLoading();
        return;
    }

    const name = button.getAttribute('data-name');
    const phone = button.getAttribute('data-phone');
    const email = button.getAttribute('data-email');
    const address = button.getAttribute('data-address');
    const preferences = button.getAttribute('data-preferences');

    document.getElementById('customerId').value = customerId;
    document.getElementById('name').value = name || '';
    document.getElementById('phone').value = phone || '';
    document.getElementById('email').value = email || '';
    document.getElementById('address').value = address || '';
    document.getElementById('medicine_preferences').value = preferences || '';

    document.getElementById('customerFormTitle').textContent = 'Edit Customer';

    const form = document.getElementById('customerForm');
    if (form) {
        form.action = `/customer/edit/${customerId}`;
    }

    document.getElementById('customerFormContainer').style.display = 'block';
    document.getElementById('customerListContainer').style.display = 'none';

    hideLoading();
}

// View customer details
function viewCustomer(customerId) {
    showLoading();

    const button = document.querySelector(`.view-customer-btn[data-id="${customerId}"]`);
    if (!button) {
        hideLoading();
        return;
    }

    const row = button.closest('tr');
    const name = row.querySelector('td:nth-child(1)').textContent;
    const phone = row.querySelector('td:nth-child(2)').textContent;
    const email = row.querySelector('td:nth-child(3)').textContent;

    const address = button.getAttribute('data-address');
    const preferences = button.getAttribute('data-preferences');

    document.getElementById('detailCustomerName').textContent = name;
    document.getElementById('detailPhone').textContent = phone;
    document.getElementById('detailEmail').textContent = email;
    document.getElementById('detailAddress').textContent = address;

    const prefElem = document.getElementById('detailPreferences');
    if (preferences && preferences.trim() !== '') {
        prefElem.textContent = preferences;
        prefElem.closest('.medicine-preference').style.display = 'block';
    } else {
        prefElem.closest('.medicine-preference').style.display = 'none';
    }

    const modal = new bootstrap.Modal(document.getElementById('customerDetailModal'));
    modal.show();

    hideLoading();
}

// Setup customer search
function setupCustomerSearch() {
    const searchInput = document.getElementById('customerSearch');
    const searchForm = document.getElementById('customerSearchForm');

    if (!searchInput || !searchForm) return;

    searchForm.addEventListener('submit', function (e) {
        if (!searchInput.value.trim()) {
            e.preventDefault();
        }
    });
}

// Setup CSV import
function setupCSVImport() {
    const importForm = document.getElementById('importCustomerForm');
    const importFileInput = document.getElementById('csvFile');
    const importBtn = document.getElementById('importCustomerBtn');

    if (!importForm || !importFileInput || !importBtn) return;

    importFileInput.addEventListener('change', function () {
        const fileName = this.files[0] ? this.files[0].name : 'Choose file';
        // Update adjacent element text if needed (e.g., a span element)
        this.nextElementSibling.textContent = fileName;
    });

    importForm.addEventListener('submit', function (e) {
        if (!importFileInput.files[0]) {
            e.preventDefault();
            alert('Please select a CSV file to import');
        }
    });
}

// Export customers to CSV
function exportCustomersToCSV() {
    showLoading();

    const table = document.getElementById('customerTable');
    if (!table) {
        hideLoading();
        return;
    }

    const headers = ['Name', 'Phone', 'Email', 'Address', 'Medicine Preferences'];
    const rows = table.querySelectorAll('tbody tr');
    const data = [];

    rows.forEach(row => {
        const viewButton = row.querySelector('.view-customer-btn');
        if (!viewButton) return;

        const rowData = {
            'Name': row.querySelector('td:nth-child(1)').textContent,
            'Phone': row.querySelector('td:nth-child(2)').textContent,
            'Email': row.querySelector('td:nth-child(3)').textContent,
            'Address': viewButton.getAttribute('data-address'),
            'Medicine Preferences': viewButton.getAttribute('data-preferences')
        };

        data.push(rowData);
    });

    if (data.length === 0) {
        hideLoading();
        alert('No data to export');
        return;
    }

    exportToCSV(data, 'customers_export.csv');
    hideLoading();
}

// Placeholder functions (implement as needed)
function showLoading() {
    // Implement your loading indicator logic here
}

function hideLoading() {
    // Implement your logic to hide the loading indicator
}

function validateForm(formId) {
    // Implement form validation logic; return true if valid
    return true;
}
