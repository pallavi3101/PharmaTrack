/**
 * PharmaTrack - Inventory Management JavaScript
 * Contains functionality specific to inventory management
 */

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', function () {
    initializeInventoryTable();
    initializeFormHandlers();
    setupInventorySearch();
    setupCSVImport();
    setupFilters();
});

// Initialize inventory table handlers
function initializeInventoryTable() {
    const inventoryTable = document.getElementById('inventoryTable');
    if (!inventoryTable) return;

    // Setup edit buttons
    const editButtons = document.querySelectorAll('.edit-inventory-btn');
    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            const itemId = this.getAttribute('data-id');
            editInventoryItem(itemId);
        });
    });

    // Setup delete buttons
    const deleteButtons = document.querySelectorAll('.delete-inventory-btn');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function () {
            const itemId = this.getAttribute('data-id');
            const itemName = this.getAttribute('data-name');
            deleteInventoryItem(itemId, itemName);
        });
    });

    // Setup view buttons
    const viewButtons = document.querySelectorAll('.view-inventory-btn');
    viewButtons.forEach(button => {
        button.addEventListener('click', function () {
            const itemId = this.getAttribute('data-id');
            viewInventoryItem(itemId);
        });
    });
}

// Initialize form handlers
function initializeFormHandlers() {
    const addInventoryBtn = document.getElementById('addInventoryBtn');
    if (addInventoryBtn) {
        addInventoryBtn.addEventListener('click', showAddInventoryForm);
    }

    const cancelInventoryBtn = document.getElementById('cancelInventoryBtn');
    if (cancelInventoryBtn) {
        cancelInventoryBtn.addEventListener('click', hideInventoryForm);
    }
    const inventoryForm = document.getElementById('inventoryForm');
    if (inventoryForm) {
        inventoryForm.addEventListener('submit', function (e) {
            if (!validateForm('inventoryForm')) {
                e.preventDefault();
            }
        });
    }
}

// Show add inventory form (for new items or editing)
function showAddInventoryForm() {
    const listContainer = document.getElementById('inventoryListContainer');
    const formContainer = document.getElementById('inventoryFormContainer');

    if (listContainer && formContainer) {
        listContainer.style.display = 'none';
        formContainer.style.display = 'block';

        // If adding new item (hidden id field is empty), reset the form
        const form = document.getElementById('inventoryForm');
        if (form) {
            const idField = document.getElementById('inventoryId');
            if (!idField.value) {
                form.reset();
            }
            // Default action for adding a new item
            form.action = '/inventory/add';
            const formTitle = document.getElementById('inventoryFormTitle');
            if (formTitle) formTitle.textContent = idField.value ? 'Edit Inventory Item' : 'Add New Inventory Item';
        }
    }
}

// Hide inventory form and show list
function hideInventoryForm() {
    const listContainer = document.getElementById('inventoryListContainer');
    const formContainer = document.getElementById('inventoryFormContainer');

    if (listContainer && formContainer) {
        listContainer.style.display = 'block';
        formContainer.style.display = 'none';
    }
}

// Delete inventory item
function deleteInventoryItem(itemId, itemName) {
    if (confirm(`Are you sure you want to delete ${itemName}?`)) {
        const form = document.getElementById('deleteInventoryForm');
        form.action = `/inventory/delete/${itemId}`;
        form.submit();
    }
}

// View inventory item details in modal
function viewInventoryItem(itemId) {
    const row = document.querySelector(`[data-id="${itemId}"]`).closest('tr');
    const modal = document.getElementById('inventoryDetailModal');

    if (row && modal) {
        document.getElementById('detailItemName').textContent = row.cells[0].textContent;
        document.getElementById('detailCategory').textContent = row.cells[1].textContent;
        document.getElementById('detailCompany').textContent = row.cells[2].textContent;
        document.getElementById('detailBatchNo').textContent = row.cells[3].textContent;
        document.getElementById('detailQuantity').textContent = row.cells[4].textContent;
        document.getElementById('detailMRP').textContent = row.cells[5].textContent;
        const modalInstance = new bootstrap.Modal(modal);
        modalInstance.show();
    }
}

// Edit inventory item: Pre-fill the form with existing data
function editInventoryItem(itemId) {
    const btn = document.querySelector(`.edit-inventory-btn[data-id="${itemId}"]`);
    const form = document.getElementById('inventoryForm');

    if (btn && form) {
        // Set form action to the update route
        form.action = `/inventory/edit/${itemId}`;
        // Set hidden ID field
        form.querySelector('#inventoryId').value = itemId;
        // Pre-fill form fields from data attributes on the button
        form.querySelector('#name').value = btn.getAttribute('data-name');
        form.querySelector('#category').value = btn.getAttribute('data-category');
        form.querySelector('#packing').value = btn.getAttribute('data-packing');
        form.querySelector('#company').value = btn.getAttribute('data-company');
        form.querySelector('#batch_no').value = btn.getAttribute('data-batch');
        form.querySelector('#expiry_date').value = btn.getAttribute('data-expiry');
        form.querySelector('#mrp').value = btn.getAttribute('data-mrp');
        form.querySelector('#quantity').value = btn.getAttribute('data-quantity');
        form.querySelector('#tax_percentage').value = btn.getAttribute('data-tax');
        form.querySelector('#shelf').value = btn.getAttribute('data-shelf');
        form.querySelector('#supplier').value = btn.getAttribute('data-supplier');

        // Update form title to indicate editing
        const formTitle = document.getElementById('inventoryFormTitle');
        if (formTitle) formTitle.textContent = 'Edit Inventory Item';

        // Show the form
        showAddInventoryForm();
    }
}

// Setup inventory search functionality
function setupInventorySearch() {
    const searchInput = document.getElementById('inventorySearch');
    const searchForm = document.getElementById('inventorySearchForm');

    if (!searchInput || !searchForm) return;

    searchForm.addEventListener('submit', function (e) {
        if (!searchInput.value.trim()) {
            e.preventDefault();
        }
    });
}

// Setup CSV import functionality
function setupCSVImport() {
    const importForm = document.getElementById('importInventoryForm');
    const importFileInput = document.getElementById('csvFile');

    if (!importForm || !importFileInput) return;

    // Optional: Update a dedicated span to show selected file name.
    // Make sure to add a <span id="csvFileName"></span> next to your file input in HTML.
    const fileNameSpan = document.getElementById('csvFileName');

    importFileInput.addEventListener('change', function () {
        const fileName = this.files[0] ? this.files[0].name : 'Choose file';
        if (fileNameSpan) {
            fileNameSpan.textContent = fileName;
        }
    });

    importForm.addEventListener('submit', function (e) {
        if (!importFileInput.files[0]) {
            e.preventDefault();
            alert('Please select a CSV file to import');
        }
    });
}

// Setup category and supplier filters
function setupFilters() {
    const categoryFilters = document.querySelectorAll('.category-filter');
    const supplierFilters = document.querySelectorAll('.supplier-filter');

    // Category filters
    categoryFilters.forEach(filter => {
        filter.addEventListener('click', function () {
            const category = this.getAttribute('data-category');

            // Toggle active class
            categoryFilters.forEach(f => f.classList.remove('active'));
            this.classList.add('active');

            // Filter table
            filterInventoryTable('category', category);
        });
    });

    // Supplier filters
    supplierFilters.forEach(filter => {
        filter.addEventListener('click', function () {
            const supplier = this.getAttribute('data-supplier');

            // Toggle active class
            supplierFilters.forEach(f => f.classList.remove('active'));
            this.classList.add('active');

            // Filter table
            filterInventoryTable('supplier', supplier);
        });
    });
}

// Filter inventory table rows based on filter type and value
function filterInventoryTable(filterType, filterValue) {
    const table = document.getElementById('inventoryTable');
    if (!table) return;

    const rows = table.querySelectorAll('tbody tr');

    rows.forEach(row => {
        let cellValue = '';

        if (filterType === 'category') {
            cellValue = row.querySelector('td:nth-child(2)').textContent;
        } else if (filterType === 'supplier') {
            const button = row.querySelector('.view-inventory-btn');
            if (button) {
                cellValue = button.getAttribute('data-supplier');
            }
        }

        if (filterValue === 'all' || cellValue === filterValue) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Export inventory table to CSV
function exportInventoryToCSV() {
    showLoading();

    const table = document.getElementById('inventoryTable');
    if (!table) {
        hideLoading();
        return;
    }

    let csv = [];
    const rows = table.querySelectorAll('tr');

    rows.forEach(row => {
        const cols = row.querySelectorAll('td, th');
        const rowData = Array.from(cols)
            .map(col => col.textContent.trim())
            .filter(text => text !== 'Actions')
            .join(',');
        csv.push(rowData);
    });

    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'inventory.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    hideLoading();
}

// Placeholder functions (implement as needed)
function showLoading() {
    // Show a loading indicator if needed
}

function hideLoading() {
    // Hide the loading indicator
}

function validateForm(formId) {
    // Implement form validation; return true if valid
    return true;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString();
}