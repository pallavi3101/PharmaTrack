document.addEventListener("DOMContentLoaded", function () {
    console.log("Login page JS loaded.");
    // Add any login-specific JavaScript functionality here.
});
