/**
 * PharmaTrack - Main JavaScript
 * Contains common functionality used across the application
 */

// Global loading spinner
function showLoading() {
    const spinner = document.createElement('div');
    spinner.className = 'spinner-overlay';
    spinner.innerHTML = `
        <div class="spinner-container">
            <div class="spinner-border" role="status"></div>
            <p class="mt-2">Loading...</p>
        </div>
    `;
    document.body.appendChild(spinner);
}

function hideLoading() {
    const spinner = document.querySelector('.spinner-overlay');
    if (spinner) {
        spinner.remove();
    }
}

// Flash message handler
function showFlashMessage(message, type = 'success') {
    const alertContainer = document.getElementById('alert-container');
    if (!alertContainer) return;

    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.role = 'alert';
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    alertContainer.appendChild(alert);
    
    // Auto-close after 5 seconds
    setTimeout(() => {
        if (alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }
    }, 5000);
}

// Form validation
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return true;
    
    let isValid = true;
    
    // Validate required fields
    const requiredFields = form.querySelectorAll('[required]');
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            isValid = false;
            field.classList.add('is-invalid');
            
            // Add validation message if it doesn't exist
            let feedbackEl = field.nextElementSibling;
            if (!feedbackEl || !feedbackEl.classList.contains('invalid-feedback')) {
                feedbackEl = document.createElement('div');
                feedbackEl.className = 'invalid-feedback';
                feedbackEl.textContent = 'This field is required';
                field.parentNode.insertBefore(feedbackEl, field.nextSibling);
            }
        } else {
            field.classList.remove('is-invalid');
        }
    });
    
    // Validate email fields
    const emailFields = form.querySelectorAll('input[type="email"]');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    emailFields.forEach(field => {
        if (field.value.trim() && !emailRegex.test(field.value.trim())) {
            isValid = false;
            field.classList.add('is-invalid');
            
            // Add validation message if it doesn't exist
            let feedbackEl = field.nextElementSibling;
            if (!feedbackEl || !feedbackEl.classList.contains('invalid-feedback')) {
                feedbackEl = document.createElement('div');
                feedbackEl.className = 'invalid-feedback';
                feedbackEl.textContent = 'Please enter a valid email address';
                field.parentNode.insertBefore(feedbackEl, field.nextSibling);
            }
        }
    });
    
    // Validate number fields
    const numberFields = form.querySelectorAll('input[type="number"]');
    
    numberFields.forEach(field => {
        if (field.value.trim()) {
            const min = field.getAttribute('min');
            const max = field.getAttribute('max');
            const value = parseFloat(field.value);
            
            if ((min && value < parseFloat(min)) || (max && value > parseFloat(max))) {
                isValid = false;
                field.classList.add('is-invalid');
                
                // Add validation message if it doesn't exist
                let feedbackEl = field.nextElementSibling;
                if (!feedbackEl || !feedbackEl.classList.contains('invalid-feedback')) {
                    feedbackEl = document.createElement('div');
                    feedbackEl.className = 'invalid-feedback';
                    
                    if (min && value < parseFloat(min)) {
                        feedbackEl.textContent = `Value must be at least ${min}`;
                    } else if (max && value > parseFloat(max)) {
                        feedbackEl.textContent = `Value must be at most ${max}`;
                    }
                    
                    field.parentNode.insertBefore(feedbackEl, field.nextSibling);
                }
            }
        }
    });
    
    return isValid;
}

// Clear form fields
function clearForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return;
    
    form.reset();
    
    // Clear validation states
    const invalidFields = form.querySelectorAll('.is-invalid');
    invalidFields.forEach(field => {
        field.classList.remove('is-invalid');
    });
}

// Format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 2
    }).format(amount);
}

// Format date
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-IN', options);
}

// Search functionality
function setupSearch(inputId, url, resultCallback) {
    const searchInput = document.getElementById(inputId);
    if (!searchInput) return;
    
    let searchTimeout;
    
    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        const query = this.value.trim();
        
        if (query.length < 2) {
            return;
        }
        
        searchTimeout = setTimeout(() => {
            showLoading();
            
            fetch(`${url}?q=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    resultCallback(data);
                    hideLoading();
                })
                .catch(error => {
                    console.error('Search error:', error);
                    hideLoading();
                    showFlashMessage('Search failed. Please try again.', 'danger');
                });
        }, 300);
    });
}

// Export to CSV
function exportToCSV(data, filename) {
    if (!data || !data.length) {
        showFlashMessage('No data to export', 'warning');
        return;
    }
    
    // Get headers from the first item
    const headers = Object.keys(data[0]);
    
    // Create CSV content
    let csvContent = headers.join(',') + '\n';
    
    data.forEach(item => {
        const row = headers.map(header => {
            // Handle commas in the content by wrapping in quotes
            let cell = item[header] === null ? '' : item[header].toString();
            
            // Escape double quotes
            cell = cell.replace(/"/g, '""');
            
            // Wrap in quotes if contains comma, newline or double quote
            if (cell.includes(',') || cell.includes('\n') || cell.includes('"')) {
                cell = `"${cell}"`;
            }
            
            return cell;
        });
        
        csvContent += row.join(',') + '\n';
    });
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    // Set link properties
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    
    // Add to document, trigger click and remove
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Initialize tooltips and popovers
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize all popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
});
