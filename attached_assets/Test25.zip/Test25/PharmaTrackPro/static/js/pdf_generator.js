/**
 * PharmaTrack - PDF Generator JavaScript
 * Handles client-side PDF generation for reports and bills
 */

// Generate PDF from HTML content
function generatePDF(elementId, filename) {
    // Show loading spinner
    showLoading();
    
    // Get the HTML element that needs to be converted to PDF
    const element = document.getElementById(elementId);
    if (!element) {
        hideLoading();
        showFlashMessage('Element not found for PDF generation', 'danger');
        return;
    }
    
    // Define PDF options
    const options = {
        margin: 10,
        filename: filename,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };
    
    // Use html2pdf library (loaded from CDN in the HTML)
    try {
        // Check if html2pdf is available
        if (typeof html2pdf === 'undefined') {
            throw new Error('html2pdf library not loaded');
        }
        
        // Generate PDF
        html2pdf()
            .set(options)
            .from(element)
            .save()
            .then(() => {
                hideLoading();
                showFlashMessage('PDF generated successfully!', 'success');
            });
    } catch (error) {
        hideLoading();
        console.error('PDF generation error:', error);
        
        // If html2pdf is not available, fall back to window.print()
        showFlashMessage('Using browser print function instead of PDF generation', 'warning');
        setTimeout(() => {
            window.print();
        }, 500);
    }
}

// Generate bill PDF
function generateBillPDF(saleId) {
    // Redirect to the bill template page in a new window
    const billWindow = window.open(`/reports/generate_bill/${saleId}`, '_blank');
    
    // Add event listener to print when the page loads
    billWindow.addEventListener('load', function() {
        setTimeout(() => {
            billWindow.print();
        }, 500);
    });
}

// Generate sales report PDF
function generateSalesReportPDF(dateFrom, dateTo, filterType) {
    // This would normally generate a report via AJAX and then convert to PDF
    // For demo purposes, we'll just show a message
    showFlashMessage('PDF generation will be available in the full version', 'info');
}

// Generate inventory report PDF
function generateInventoryReportPDF(filterType) {
    // This would normally generate a report via AJAX and then convert to PDF
    // For demo purposes, we'll just show a message
    showFlashMessage('PDF generation will be available in the full version', 'info');
}

// Generate expiry report PDF
function generateExpiryReportPDF(daysFilter) {
    // This would normally generate a report via AJAX and then convert to PDF
    // For demo purposes, we'll just show a message
    showFlashMessage('PDF generation will be available in the full version', 'info');
}

// Generate customer report PDF
function generateCustomerReportPDF(customerId) {
    // This would normally generate a report via AJAX and then convert to PDF
    // For demo purposes, we'll just show a message
    showFlashMessage('PDF generation will be available in the full version', 'info');
}

// Load HTML2PDF library dynamically if needed for PDF generation
function loadHTML2PDFLibrary() {
    // Check if the library is already loaded
    if (typeof html2pdf !== 'undefined') {
        return Promise.resolve();
    }
    
    return new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js';
        script.onload = resolve;
        script.onerror = reject;
        document.head.appendChild(script);
    });
}

// Initialize PDF functionality when needed
document.addEventListener('DOMContentLoaded', function() {
    // Preload the HTML2PDF library if on reports page
    if (window.location.pathname.includes('/reports')) {
        loadHTML2PDFLibrary()
            .then(() => console.log('HTML2PDF library loaded'))
            .catch(error => console.error('Failed to load HTML2PDF library:', error));
    }
});
