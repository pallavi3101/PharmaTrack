document.addEventListener("DOMContentLoaded", function () {
    console.log("Register page JS loaded.");

    const form = document.querySelector("form");
    form.addEventListener("submit", function (event) {
        const password = document.getElementById("password").value;
        const confirmPassword = document.getElementById("confirm_password").value;
        if (password !== confirmPassword) {
            event.preventDefault();
            alert("Passwords do not match. Please re-enter your password.");
        }
    });
});
