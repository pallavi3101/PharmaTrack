// reports.js

let salesReportChartRef = null;
let inventoryReportChartRef = null;
let expiryReportChartRef = null;
let customerReportChartRef = null;

document.addEventListener('DOMContentLoaded', function () {
    // Initialize default date filters for reports (current month)
    const today = new Date();
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
    const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    document.getElementById('dateFrom').valueAsDate = firstDay;
    document.getElementById('dateTo').valueAsDate = lastDay;
});

// Helper function to fetch JSON with error checking
function fetchJSON(url) {
    return fetch(url).then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    });
}

// ------------------ Report Building Helpers ------------------

// Generic function to build a chart using Chart.js
function buildReportChart(data, canvasId, labelText) {
    const labels = data.map(item => item.label);
    const values = data.map(item => item.value); // Data format: { label: '2023-09-01', value: 12345 }
    const ctx = document.getElementById(canvasId).getContext('2d');

    // Determine current chart reference and destroy if exists
    let chartRef;
    if (canvasId === 'salesReportChart') {
        chartRef = salesReportChartRef;
    } else if (canvasId === 'inventoryReportChart') {
        chartRef = inventoryReportChartRef;
    } else if (canvasId === 'expiryReportChart') {
        chartRef = expiryReportChartRef;
    } else if (canvasId === 'customerReportChart') {
        chartRef = customerReportChartRef;
    }
    if (chartRef) {
        chartRef.destroy();
    }

    const newChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: labelText,
                data: values,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function (value) {
                            return '₹' + value.toLocaleString('en-IN');
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function (context) {
                            return '₹' + context.parsed.y.toLocaleString('en-IN');
                        }
                    }
                },
                legend: {
                    display: true
                }
            }
        }
    });

    // Save chart reference
    if (canvasId === 'salesReportChart') {
        salesReportChartRef = newChart;
    } else if (canvasId === 'inventoryReportChart') {
        inventoryReportChartRef = newChart;
    } else if (canvasId === 'expiryReportChart') {
        expiryReportChartRef = newChart;
    } else if (canvasId === 'customerReportChart') {
        customerReportChartRef = newChart;
    }
}

// Generic function to build a summary table
function buildReportTable(data, containerId) {
    const container = document.getElementById(containerId);
    let html = `<table class="table table-sm table-bordered">
                    <thead>
                        <tr>
                            <th>Date/Label</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody>`;
    data.forEach(item => {
        html += `<tr>
                    <td>${item.label}</td>
                    <td>₹${item.value.toLocaleString('en-IN')}</td>
                 </tr>`;
    });
    html += `</tbody></table>`;
    container.innerHTML = html;
}

// ------------------ Report Functions ------------------

// Sales Report
function showSalesReport() {
    const dateFrom = document.getElementById('dateFrom').value;
    const dateTo = document.getElementById('dateTo').value;
    const params = new URLSearchParams({ date_from: dateFrom, date_to: dateTo });

    fetchJSON(`/reports/sales_report_data?${params.toString()}`)
        .then(data => {
            if (!Array.isArray(data)) {
                throw new Error("Invalid data format for Sales Report");
            }
            buildReportChart(data, 'salesReportChart', 'Total Sales');
            buildReportTable(data, 'salesReportTableContainer');
            new bootstrap.Modal(document.getElementById('salesReportModal')).show();
        })
        .catch(error => {
            console.error('Error generating sales report:', error);
            showFlashMessage('Failed to generate sales report.', 'danger');
        });
}

// Inventory Report
function showInventoryReport() {
    const params = new URLSearchParams(); // Add filters if needed
    fetchJSON(`/reports/inventory_report_data?${params.toString()}`)
        .then(data => {
            if (!Array.isArray(data)) {
                throw new Error("Invalid data format for Inventory Report");
            }
            buildReportChart(data, 'inventoryReportChart', 'Inventory Value');
            buildReportTable(data, 'inventoryReportTableContainer');
            new bootstrap.Modal(document.getElementById('inventoryReportModal')).show();
        })
        .catch(error => {
            console.error('Error generating inventory report:', error);
            showFlashMessage('Failed to generate inventory report.', 'danger');
        });
}

// Expiry Report
function showExpiryReport() {
    const params = new URLSearchParams(); // Add filters if needed
    fetchJSON(`/reports/expiry_report_data?${params.toString()}`)
        .then(data => {
            if (!Array.isArray(data)) {
                throw new Error("Invalid data format for Expiry Report");
            }
            buildReportChart(data, 'expiryReportChart', 'Expiry Report');
            buildReportTable(data, 'expiryReportTableContainer');
            new bootstrap.Modal(document.getElementById('expiryReportModal')).show();
        })
        .catch(error => {
            console.error('Error generating expiry report:', error);
            showFlashMessage('Failed to generate expiry report.', 'danger');
        });
}

// Customer Report
function showCustomerReport() {
    const params = new URLSearchParams(); // Add filters if needed
    fetchJSON(`/reports/customer_report_data?${params.toString()}`)
        .then(data => {
            if (!Array.isArray(data)) {
                throw new Error("Invalid data format for Customer Report");
            }
            buildReportChart(data, 'customerReportChart', 'Customer Sales');
            buildReportTable(data, 'customerReportTableContainer');
            new bootstrap.Modal(document.getElementById('customerReportModal')).show();
        })
        .catch(error => {
            console.error('Error generating customer report:', error);
            showFlashMessage('Failed to generate customer report.', 'danger');
        });
}

// Print the modal content
function printReport(modalId) {
    const modalElem = document.getElementById(modalId);
    if (!modalElem) return;
    showFlashMessage('Printing report...', 'info');
    window.print();
}

// Existing functions for filters and export (if needed)
function applyFilters() {
    showFlashMessage('Filters applied', 'success');
    // Optionally, refresh sales history table via AJAX
}

function exportSalesHistory() {
    showFlashMessage('Export feature will be implemented in the full version', 'info');
}

// Simple flash message helper (for demo purposes)
function showFlashMessage(message, type) {
    alert(message);
}
