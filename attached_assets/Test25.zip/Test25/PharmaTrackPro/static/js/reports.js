// ------------------ Chart References ------------------

let salesReportChartRef = null;
let inventoryReportChartRef = null;
let profitsReportChartRef = null;
let customerReportChartRef = null;

// ------------------ Initialization ------------------

document.addEventListener('DOMContentLoaded', function () {
    // Initialize default date filters for reports (current month)
    const today = new Date();
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
    const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    document.getElementById('dateFrom').valueAsDate = firstDay;
    document.getElementById('dateTo').valueAsDate = lastDay;
});

// ------------------ Helper Functions ------------------

// Helper function to fetch JSON with error checking
function fetchJSON(url) {
    return fetch(url).then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    });
}

// ------------------ Report Building Helpers ------------------

// Generic function to build a chart using Chart.js
function buildReportChart(data, canvasId, labelText) {
    const labels = data.map(item => item.label);
    const values = data.map(item => item.value);
    const ctx = document.getElementById(canvasId).getContext('2d');

    // Determine current chart reference and destroy if exists
    let chartRef;
    if (canvasId === 'salesReportChart') {
        chartRef = salesReportChartRef;
    } else if (canvasId === 'inventoryReportChart') {
        chartRef = inventoryReportChartRef;
    } else if (canvasId === 'profitsReportChart') {
        chartRef = profitsReportChartRef;
    } else if (canvasId === 'customerReportChart') {
        chartRef = customerReportChartRef;
    }
    if (chartRef) {
        chartRef.destroy();
    }

    const newChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: labelText,
                data: values,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function (value) {
                            return '₹' + value.toLocaleString('en-IN');
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function (context) {
                            return '₹' + context.parsed.y.toLocaleString('en-IN');
                        }
                    }
                },
                legend: {
                    display: true
                }
            }
        }
    });

    // Save chart reference
    if (canvasId === 'salesReportChart') {
        salesReportChartRef = newChart;
    } else if (canvasId === 'inventoryReportChart') {
        inventoryReportChartRef = newChart;
    } else if (canvasId === 'profitsReportChart') {
        profitsReportChartRef = newChart;
    } else if (canvasId === 'customerReportChart') {
        customerReportChartRef = newChart;
    }
}

// Generic function to build a summary table
function buildReportTable(data, containerId) {
    const container = document.getElementById(containerId);
    let html = `<table class="table table-sm table-bordered">
                    <thead>
                        <tr>
                            <th>Date/Label</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody>`;
    data.forEach(item => {
        html += `<tr>
                    <td>${item.label}</td>
                    <td>₹${item.value.toLocaleString('en-IN')}</td>
                 </tr>`;
    });
    html += `</tbody></table>`;
    container.innerHTML = html;
}

// ------------------ Report Functions ------------------

// Sales Report
function showSalesReport() {
    const dateFrom = document.getElementById('dateFrom').value;
    const dateTo = document.getElementById('dateTo').value;
    // The endpoints expect "date_from" and "date_to" as query parameters
    const params = new URLSearchParams({ date_from: dateFrom, date_to: dateTo });

    fetchJSON(`/reports/sales_report_data?${params.toString()}`)
        .then(data => {
            if (!Array.isArray(data)) {
                throw new Error("Invalid data format for Sales Report");
            }
            buildReportChart(data, 'salesReportChart', 'Total Sales');
            buildReportTable(data, 'salesReportTableContainer');
            new bootstrap.Modal(document.getElementById('salesReportModal')).show();
        })
        .catch(error => {
            console.error('Error generating sales report:', error);
            showFlashMessage('Failed to generate sales report.', 'danger');
        });
}

// Inventory Report
function showInventoryReport() {
    // No filters currently for inventory report; extend as needed.
    fetchJSON(`/reports/inventory_report_data`)
        .then(data => {
            if (!Array.isArray(data)) {
                throw new Error("Invalid data format for Inventory Report");
            }
            buildReportChart(data, 'inventoryReportChart', 'Inventory Report');
            buildReportTable(data, 'inventoryReportTableContainer');
            new bootstrap.Modal(document.getElementById('inventoryReportModal')).show();
        })
        .catch(error => {
            console.error('Error generating inventory report:', error);
            showFlashMessage('Failed to generate inventory report.', 'danger');
        });
}

// Profits Report
function showProfitsReport() {
    fetchJSON(`/reports/profits_report_data`)
        .then(data => {
            if (!Array.isArray(data)) {
                throw new Error("Invalid data format for Profits Report");
            }
            buildReportChart(data, 'profitsReportChart', 'Profits Report');
            buildReportTable(data, 'profitsReportTableContainer');
            new bootstrap.Modal(document.getElementById('profitsReportModal')).show();
        })
        .catch(error => {
            console.error('Error generating profits report:', error);
            showFlashMessage('Failed to generate profits report.', 'danger');
        });
}

// Customer Report
function showCustomerReport() {
    fetchJSON(`/reports/customer_report_data`)
        .then(data => {
            if (!Array.isArray(data)) {
                throw new Error("Invalid data format for Customer Report");
            }
            buildReportChart(data, 'customerReportChart', 'Customer Sales');
            buildReportTable(data, 'customerReportTableContainer');
            new bootstrap.Modal(document.getElementById('customerReportModal')).show();
        })
        .catch(error => {
            console.error('Error generating customer report:', error);
            showFlashMessage('Failed to generate customer report.', 'danger');
        });
}

// ------------------ Utility Functions ------------------

// Print the modal content
function printReport(modalId) {
    const modalElem = document.getElementById(modalId);
    if (!modalElem) return;
    showFlashMessage('Printing report...', 'info');
    window.print();
}

// Apply filters (for Sales History, if needed)
function applyFilters() {
    showFlashMessage('Filters applied', 'success');
    // Optionally, refresh sales history table via AJAX
}

// Export sales history (Placeholder)
function exportSalesHistory() {
    showFlashMessage('Export feature will be implemented in the full version', 'info');
}

// Simple flash message helper (for demo purposes)
function showFlashMessage(message, type) {
    alert(message);
}
