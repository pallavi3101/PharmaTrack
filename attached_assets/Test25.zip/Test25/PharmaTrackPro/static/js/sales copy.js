/**
 * PharmaTrack - Sales Management JavaScript
 * Contains functionality specific to sales management
 */

document.addEventListener('DOMContentLoaded', function () {
    // Initialize counter tabs
    initializeCounterTabs();

    // Setup product search (modified)
    setupProductSearch();

    // Setup customer search
    setupCustomerSearch();

    // Initialize quantity controls
    initializeQuantityControls();

    // Initialize action buttons
    initializeActionButtons();

    // Setup tab key navigation between counters
    setupTabKeyNavigation();

    // Counter selector functionality
    const counterSelector = document.getElementById('counterSelector');
    if (counterSelector) {
        counterSelector.addEventListener('change', function () {
            switchCounter(this.value);
        });
    }

    // Search functionality for each counter
    document.querySelectorAll('.product-search').forEach(input => {
        input.addEventListener('input', function () {
            const counterId = this.getAttribute('data-counter');
            const query = this.value.trim();
            const resultsDiv = document.getElementById(`searchResults-${counterId}`);

            if (query.length < 1) {
                resultsDiv.style.display = 'none';
                return;
            }

            fetch(`/api/inventory/search?q=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    resultsDiv.innerHTML = '';
                    if (data.length > 0) {
                        data.forEach(item => {
                            const div = document.createElement('div');
                            div.className = 'p-2 search-result-item';
                            div.innerHTML = `
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>${item.name}</strong><br>
                                        <small>Batch: ${item.batch_no} | Stock: ${item.quantity}</small>
                                    </div>
                                    <button class="btn btn-sm btn-primary add-to-sale" 
                                            data-item='${JSON.stringify(item)}' 
                                            data-counter="${counterId}">
                                        Add
                                    </button>
                                </div>
                            `;
                            resultsDiv.appendChild(div);
                        });
                        resultsDiv.style.display = 'block';
                    } else {
                        resultsDiv.innerHTML = '<div class="p-2">No products found</div>';
                        resultsDiv.style.display = 'block';
                    }
                });
        });
    });

    // Handle clicking outside search results
    document.addEventListener('click', function (e) {
        if (!e.target.closest('.product-search') && !e.target.closest('.search-results')) {
            document.querySelectorAll('.search-results').forEach(div => {
                div.style.display = 'none';
            });
        }
    });

    // Add to sale functionality
    document.addEventListener('click', function (e) {
        if (e.target.classList.contains('add-to-sale')) {
            const item = JSON.parse(e.target.getAttribute('data-item'));
            const counterId = e.target.getAttribute('data-counter');
            addItemToSale(counterId, item);
        }
    });
});

// Initialize counter tabs
function initializeCounterTabs() {
    const counterTabs = document.querySelectorAll('.counter-tab');

    counterTabs.forEach(tab => {
        tab.addEventListener('click', function (e) {
            e.preventDefault();

            // Only allow clicking on tabs that are not disabled
            if (this.classList.contains('disabled')) {
                return;
            }

            const counterId = this.getAttribute('data-counter-id');
            switchCounter(counterId);
        });
    });
}

// Switch to a specific counter (modified)
function switchCounter(counterId) {
    // Hide all counter contents
    document.querySelectorAll('.counter-section').forEach(content => {
        content.style.display = 'none';
    });

    // Remove active class from all tabs
    document.querySelectorAll('.counter-tab').forEach(tab => {
        tab.classList.remove('active');
    });

    // Show selected counter content and activate tab
    const selectedContent = document.getElementById(`counter-${counterId}`);
    const selectedTab = document.querySelector(`[data-counter-id="${counterId}"]`);

    if (selectedContent && selectedTab) {
        selectedContent.style.display = 'block';
        selectedTab.classList.add('active');

        // Focus the product search input
        const searchInput = selectedContent.querySelector('.product-search-input');
        if (searchInput) {
            searchInput.focus();
        }
    }
}


// Setup tab key navigation between counters
function setupTabKeyNavigation() {
    document.addEventListener('keydown', function (e) {
        // Only respond to Tab key presses
        if (e.key === 'Tab') {
            e.preventDefault(); // Prevent default tab behavior

            // Get all active counters
            const activeCounterTabs = Array.from(document.querySelectorAll('.counter-tab:not(.disabled)'));
            if (activeCounterTabs.length === 0) return;

            // Find the currently active counter
            const currentActiveTab = document.querySelector('.counter-tab.active');
            if (!currentActiveTab) {
                // If no counter is active, activate the first one
                const firstCounterId = activeCounterTabs[0].getAttribute('data-counter-id');
                switchCounter(firstCounterId);
                return;
            }

            // Get the current counter's index in the active counters array
            const currentIndex = activeCounterTabs.findIndex(tab =>
                tab.getAttribute('data-counter-id') === currentActiveTab.getAttribute('data-counter-id')
            );

            // Calculate the next counter index (with wrap-around)
            const nextIndex = e.shiftKey
                ? (currentIndex - 1 + activeCounterTabs.length) % activeCounterTabs.length // Shift+Tab goes backward
                : (currentIndex + 1) % activeCounterTabs.length; // Tab goes forward

            // Switch to the next counter
            const nextCounterId = activeCounterTabs[nextIndex].getAttribute('data-counter-id');
            switchCounter(nextCounterId);
        }
    });
}

// Function to activate a counter
function activateCounter(counterId) {
    showLoading();

    // Send AJAX request to activate counter
    const formData = new FormData();

    fetch(`/counters/counter/${counterId}/activate`, {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update UI
                const counterTab = document.querySelector(`.counter-tab[data-counter-id="${counterId}"]`);
                if (counterTab) {
                    counterTab.classList.remove('inactive');
                    counterTab.classList.add('active');
                    counterTab.innerHTML = `
                        <span class="counter-status active"></span>
                        Counter ${counterId}
                    `;
                }

                // Enable tab
                counterTab.classList.remove('disabled');

                // Switch to this counter
                switchCounter(counterId);

                // Clear the counter content
                resetCounterContent(counterId);
            } else {
                showFlashMessage(data.message, 'danger');
            }

            hideLoading();
        })
        .catch(error => {
            console.error('Error activating counter:', error);
            showFlashMessage('Failed to activate counter. Please try again.', 'danger');
            hideLoading();
        });
}

// Function to deactivate a counter
function deactivateCounter(counterId) {
    // Confirm if there are items in the sale
    const saleItemsTable = document.querySelector(`#counter-${counterId}-content .sale-items table tbody`);
    if (saleItemsTable && saleItemsTable.querySelectorAll('tr').length > 0) {
        if (!confirm('There are items in the current sale. Are you sure you want to deactivate this counter?')) {
            return;
        }
    }

    showLoading();

    // Send AJAX request to deactivate counter
    const formData = new FormData();

    fetch(`/counters/counter/${counterId}/deactivate`, {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update UI
                const counterTab = document.querySelector(`.counter-tab[data-counter-id="${counterId}"]`);
                if (counterTab) {
                    counterTab.classList.remove('active');
                    counterTab.classList.add('inactive');
                    counterTab.innerHTML = `
                        <span class="counter-status inactive"></span>
                        Counter ${counterId}
                    `;
                }

                // Disable tab
                counterTab.classList.add('disabled');

                // Switch to first active counter if available
                const firstActiveTab = document.querySelector('.counter-tab.active');
                if (firstActiveTab) {
                    const firstActiveCounterId = firstActiveTab.getAttribute('data-counter-id');
                    switchCounter(firstActiveCounterId);
                }
            } else {
                showFlashMessage(data.message, 'danger');
            }

            hideLoading();
        })
        .catch(error => {
            console.error('Error deactivating counter:', error);
            showFlashMessage('Failed to deactivate counter. Please try again.', 'danger');
            hideLoading();
        });
}

// Reset counter content
function resetCounterContent(counterId) {
    // Clear sale items
    const saleItemsTable = document.querySelector(`#counter-${counterId}-content .sale-items table tbody`);
    if (saleItemsTable) {
        saleItemsTable.innerHTML = '';
    }

    // Clear customer info
    const customerInfo = document.querySelector(`#counter-${counterId}-content .customer-info`);
    if (customerInfo) {
        customerInfo.innerHTML = '<p>No customer selected</p>';
    }

    // Reset totals
    updateTotals(counterId, 0, 0);

    // Reset search inputs
    const productSearch = document.querySelector(`#counter-${counterId}-content .product-search input`);
    if (productSearch) {
        productSearch.value = '';
    }

    const customerSearch = document.querySelector(`#counter-${counterId}-content .customer-search input`);
    if (customerSearch) {
        customerSearch.value = '';
    }
}

// Setup product search (modified)
function setupProductSearch() {
    const searchInputs = document.querySelectorAll('.product-search');

    searchInputs.forEach(input => {
        const counterId = input.getAttribute('data-counter');
        const resultsContainer = document.getElementById(`searchResults-${counterId}`);

        input.addEventListener('input', function () {
            const query = this.value.trim();

            if (query.length < 1) {
                resultsContainer.style.display = 'none';
                return;
            }

            fetch(`/api/inventory/search?q=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        resultsContainer.innerHTML = data.map(item => `
                            <div class="p-2 search-result-item" onclick="addItemToSale('${counterId}', ${JSON.stringify(item).replace(/"/g, '&quot;')})">
                                <strong>${item.name}</strong> - ${item.company}<br>
                                <small>Stock: ${item.quantity} | MRP: ₹${item.mrp}</small>
                            </div>
                        `).join('');
                        resultsContainer.style.display = 'block';
                    } else {
                        resultsContainer.innerHTML = '<div class="p-2">No items found</div>';
                        resultsContainer.style.display = 'block';
                    }
                })
                .catch(error => {
                    console.error('Error searching inventory:', error);
                    resultsContainer.innerHTML = '<div class="p-2 text-danger">Error searching inventory</div>';
                    resultsContainer.style.display = 'block';
                });
        });

        document.addEventListener('click', function (e) {
            if (!input.contains(e.target) && !resultsContainer.contains(e.target)) {
                resultsContainer.style.display = 'none';
            }
        });
    });
}


// Add item to sale (modified)
function addItemToSale(counterId, item) {
    const tbody = document.getElementById(`items-${counterId}`);
    const row = document.createElement('tr');
    row.innerHTML = `
        <td>${item.name}</td>
        <td>${item.tax_percentage}%</td>
        <td>${item.packing}</td>
        <td>${item.batch_no}</td>
        <td>${item.shelf}</td>
        <td>${item.expiry_date}</td>
        <td>₹${item.mrp}</td>
        <td>
            <input type="number" class="form-control form-control-sm quantity-input" 
                   value="1" min="1" max="${item.quantity}">
        </td>
        <td>
            <button class="btn btn-sm btn-danger remove-item">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    `;
    tbody.appendChild(row);
    updateTotal(counterId);
}

// Update total (added)
function updateTotal(counterId) {
    let total = 0;
    const tbody = document.getElementById(`items-${counterId}`);
    tbody.querySelectorAll('tr').forEach(row => {
        const price = parseFloat(row.cells[6].textContent.replace('₹', ''));
        const quantity = parseInt(row.querySelector('.quantity-input').value);
        total += price * quantity;
    });
    document.querySelector(`#counter-${counterId} .total-amount`).textContent = `₹${total.toFixed(2)}`;
}


// Update sale items table
function updateSaleItemsTable(counterId, items) {
    const saleItemsTable = document.querySelector(`#counter-${counterId}-content .sale-items table tbody`);
    if (!saleItemsTable) return;

    // Clear table
    saleItemsTable.innerHTML = '';

    // Add items
    items.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.name}</td>
            <td>${item.batch_no}</td>
            <td>${item.packing}</td>
            <td>${item.shelf || 'N/A'}</td>
            <td>${item.expiry_date}</td>
            <td class="text-end">₹${item.price.toFixed(2)}</td>
            <td class="text-center">${item.tax_percentage}%</td>
            <td class="quantity-cell">
                <div class="quantity-control">
                    <button type="button" class="btn btn-sm btn-secondary" onclick="decreaseQuantity(${counterId}, ${item.id})">-</button>
                    <input type="text" class="form-control" value="${item.quantity}" readonly>
                    <button type="button" class="btn btn-sm btn-secondary" onclick="increaseQuantity(${counterId}, ${item.id})">+</button>
                </div>
            </td>
            <td class="text-end">₹${item.total_price.toFixed(2)}</td>
            <td class="text-center">
                <button type="button" class="btn btn-sm btn-danger" onclick="removeItemFromSale(${counterId}, ${item.id})">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </td>
        `;

        saleItemsTable.appendChild(row);
    });
}

// Update totals
function updateTotals(counterId, totalAmount, totalTax) {
    const subtotalElement = document.querySelector(`#counter-${counterId}-content .subtotal-amount`);
    const taxElement = document.querySelector(`#counter-${counterId}-content .tax-amount`);
    const totalElement = document.querySelector(`#counter-${counterId}-content .total-amount`);

    if (subtotalElement && taxElement && totalElement) {
        const subtotal = totalAmount - totalTax;

        subtotalElement.textContent = `₹${subtotal.toFixed(2)}`;
        taxElement.textContent = `₹${totalTax.toFixed(2)}`;
        totalElement.textContent = `₹${totalAmount.toFixed(2)}`;
    }
}

// Increase item quantity
function increaseQuantity(counterId, itemId) {
    // Get current quantity
    const inputElement = document.querySelector(`#counter-${counterId}-content .sale-items tr td.quantity-cell input[readonly]`);
    if (!inputElement) return;

    const currentQuantity = parseInt(inputElement.value);
    const newQuantity = currentQuantity + 1;

    // Update quantity
    addItemToSale(itemId, 1, counterId);
}

// Decrease item quantity
function decreaseQuantity(counterId, itemId) {
    // Get current quantity
    const inputElement = document.querySelector(`#counter-${counterId}-content .sale-items tr td.quantity-cell input[readonly]`);
    if (!inputElement) return;

    const currentQuantity = parseInt(inputElement.value);

    if (currentQuantity <= 1) {
        // If quantity is 1 or less, remove item
        removeItemFromSale(counterId, itemId);
    } else {
        // Otherwise, decrease quantity
        const newQuantity = currentQuantity - 1;

        // This is a simplified approach - in a real app, we would have a dedicated endpoint
        // Update quantity by removing item and adding it again with new quantity
        removeItemFromSale(counterId, itemId, () => {
            addItemToSale(itemId, newQuantity, counterId);
        });
    }
}

// Remove item from sale
function removeItemFromSale(counterId, itemId, callback) {
    showLoading();

    // Send AJAX request to remove item from sale
    const formData = new FormData();
    formData.append('item_id', itemId);

    fetch(`/counters/counter/${counterId}/remove_item`, {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update sale items table
                updateSaleItemsTable(counterId, data.sale_items);

                // Update totals
                updateTotals(counterId, data.total_amount, data.total_tax);

                // Execute callback if provided
                if (callback) callback();
            } else {
                showFlashMessage(data.message, 'danger');
            }

            hideLoading();
        })
        .catch(error => {
            console.error('Error removing item from sale:', error);
            showFlashMessage('Failed to remove item from sale. Please try again.', 'danger');
            hideLoading();
        });
}

// ************************************************************************************************************************************************************************************************************************************************************************************************************************
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.customer-name').forEach(input => {
        const counterId = input.dataset.counter;
        const resultsContainer = document.getElementById(`customerSearchResults-${counterId}`);

        input.addEventListener('input', function () {
            const query = this.value.trim();
            if (query.length < 1) {
                resultsContainer.innerHTML = '';
                resultsContainer.classList.remove('show');
                return;
            }

            fetch(`/api/customers/search?q=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(customers => {
                    resultsContainer.innerHTML = customers.map(customer => `
                        <div class="list-group-item list-group-item-action customer-option" 
                             data-counter="${counterId}" 
                             data-customer-id="${customer.id}" 
                             data-customer-name="${customer.name}">
                            ${customer.name} - ${customer.phone}
                        </div>
                    `).join('') || '<div class="list-group-item">No customers found</div>';
                    resultsContainer.classList.add('show');
                })
                .catch(error => {
                    console.error('Error searching customers:', error);
                    resultsContainer.innerHTML = '<div class="list-group-item text-danger">Error searching customers</div>';
                    resultsContainer.classList.add('show');
                });
        });

        // Event delegation: Handle click event for dynamically added elements
        document.body.addEventListener('click', function (event) {
            const selectedCustomer = event.target.closest('.customer-option');
            if (selectedCustomer) {
                const counterId = selectedCustomer.dataset.counter;
                const customerId = selectedCustomer.dataset.customerId;
                const customerName = selectedCustomer.dataset.customerName;

                setCustomerForSale(counterId, customerId, customerName);
            }
        });

        // Hide results when clicking outside
        document.addEventListener('click', function (e) {
            if (!input.contains(e.target) && !resultsContainer.contains(e.target)) {
                resultsContainer.classList.remove('show');
            }
        });
    });
});

function setCustomerForSale(counterId, customerId, customerName) {
    showLoading();

    const formData = new FormData();
    formData.append('customer_id', customerId);

    fetch(`/counters/counter/${counterId}/set_customer`, {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // ✅ Update the selected customer name in the input field
                const customerInput = document.getElementById(`customer-search-${counterId}`);
                const resultsContainer = document.getElementById(`customerSearchResults-${counterId}`);

                if (customerInput) {
                    customerInput.value = customerName;
                }

                // ✅ Hide the search results after selection
                if (resultsContainer) {
                    resultsContainer.innerHTML = '';  // Clear the list
                    resultsContainer.classList.remove('show');  // Hide the dropdown
                    resultsContainer.style.display = 'none';  // Ensure it's hidden
                }

                // ✅ Update UI with customer details
                const customerInfo = document.querySelector(`#counter-${counterId}-content .customer-info`);
                if (customerInfo) {
                    customerInfo.innerHTML = `
                    <p><strong>Name:</strong> ${data.customer.name}</p>
                    <p><strong>Phone:</strong> ${data.customer.phone}</p>
                    <p><strong>Email:</strong> ${data.customer.email}</p>
                    <p><strong>Address:</strong> ${data.customer.address}</p>
                `;
                }
            } else {
                showFlashMessage(data.message, 'danger');
            }
            hideLoading();
        })
        .catch(error => {
            console.error('Error setting customer for sale:', error);
            showFlashMessage('Failed to set customer for sale. Please try again.', 'danger');
            hideLoading();
        });
}
// ************************************************************************************************************************************************************************************************************************************************************************************************************************

// Initialize quantity controls
function initializeQuantityControls() {
    // Event delegation is used instead - see increaseQuantity and decreaseQuantity functions
}

// ************************************************************************************************************************************************************************************************************************************************************************************************************************

function completeSale(counterId) {
    // ✅ Check if there are items in the sale
    const saleItemsTable = document.querySelector(`#items-${counterId}`);
    if (!saleItemsTable || saleItemsTable.children.length === 0) {
        showFlashMessage('No items in the sale', 'warning');
        return;
    }

    // ✅ Get customer name from input field (Allow empty name for walk-in customers)
    const customerInput = document.getElementById(`customer-search-${counterId}`);
    const customerName = customerInput ? customerInput.value.trim() : '';

    // ✅ Get total amount
    const totalAmountElement = document.getElementById(`total-amount-${counterId}`);
    const totalAmount = totalAmountElement ? totalAmountElement.textContent.replace('₹', '').trim() : "0.00";

    if (parseFloat(totalAmount) === 0) {
        showFlashMessage("Total amount cannot be ₹0.00", "warning");
        return;
    }

    // ✅ Set total amount in checkout modal
    document.getElementById("modal-total").textContent = totalAmount;

    // ✅ Show checkout modal
    const checkoutModal = new bootstrap.Modal(document.getElementById("checkoutModal"));
    checkoutModal.show();

    // ✅ Handle the checkout confirmation (inside modal)
    document.querySelector(".print-bill").onclick = function () {
        finalizeSale(counterId, customerName);
        checkoutModal.hide();
    };
}

// ✅ Finalize the Sale After Checkout Confirmation
function finalizeSale(counterId, customerName) {
    showLoading();

    fetch(`/counters/counter/${counterId}/complete_sale`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showFlashMessage('Sale completed successfully!', 'success');

                // ✅ Reset counter content
                resetCounterContent(counterId);

                // ✅ Generate and handle bill
                fetch(`/generate_bill/${data.sale.id}`)
                    .then(response => response.blob())
                    .then(blob => {
                        const url = window.URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `bill_${data.sale.id}.pdf`;
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        window.URL.revokeObjectURL(url);

                        // ✅ Print bill if requested
                        if (confirm('Would you like to print the bill?')) {
                            const printWindow = window.open(url);
                            printWindow.print();
                        }
                    });
            } else {
                showFlashMessage(data.message, 'danger');
            }
            hideLoading();
        })
        .catch(error => {
            console.error('Error completing sale:', error);
            showFlashMessage('Failed to complete sale. Please try again.', 'danger');
            hideLoading();
        });
}

// ************************************************************************************************************************************************************************************************************************************************************************************************************************

// Show print bill modal
function showPrintBillModal(sale) {
    // Create modal if it doesn't exist
    let modal = document.getElementById('printBillModal');

    if (!modal) {
        const modalHtml = `
            <div class="modal fade" id="printBillModal" tabindex="-1" aria-labelledby="printBillModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header bg-success text-white">
                            <h5 class="modal-title" id="printBillModalLabel">Sale Completed</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle me-2"></i>
                                Sale has been completed successfully!
                            </div>

                            <div class="card mt-3" id="billPreview">
                                <div class="card-header">
                                    <h5 class="mb-0">Bill Preview</h5>
                                </div>
                                <div class="card-body">
                                    <div class="text-center mb-3">
                                        <h4>PharmaTrack Pharmacy</h4>
                                        <p class="mb-0">123 Pharmacy Street, Medical City</p>
                                        <p>Phone: 123-456-7890</p>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <p><strong>Bill #:</strong> <span id="billNumber"></span></p>
                                            <p><strong>Date:</strong> <span id="billDate"></span></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p><strong>Counter:</strong> <span id="billCounter"></span></p>
                                            <p><strong>Customer:</strong> <span id="billCustomer"></span></p>
                                        </div>
                                    </div>

                                    <table class="table table-bordered table-sm">
                                        <thead>
                                            <tr>
                                                <th>Item</th>
                                                <th>Batch</th>
                                                <th>Shelf</th>
                                                <th>Qty</th>
                                                <th>Price</th>
                                                <th>Tax</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody id="billItems">
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th colspan="5" class="text-end">Subtotal:</th>
                                                <td colspan="2" class="text-end" id="billSubtotal"></td>
                                            </tr>
                                            <tr>
                                                <th colspan="5" class="text-end">Tax:</th>
                                                <td colspan="2" class="text-end" id="billTax"></td>
                                            </tr>
                                            <tr>
                                                <th colspan="5" class="text-end">Grand Total:</th>
                                                <td colspan="2" class="text-end" id="billTotal"></td>
                                            </tr>
                                        </tfoot>
                                    </table>

                                    <div class="text-center mt-3">
                                        <p>Thank you for shopping with PharmaTrack Pharmacy!</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary" onclick="printBill()">
                                <i class="fas fa-print me-2"></i> Print Bill
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHtml);
        modal = document.getElementById('printBillModal');
    }

    // Populate bill details
    document.getElementById('billNumber').textContent = sale.id;
    document.getElementById('billDate').textContent = new Date(sale.date).toLocaleString();
    document.getElementById('billCounter').textContent = sale.counter_id;
    document.getElementById('billCustomer').textContent = sale.customer ? sale.customer.name : 'Walk-in Customer';

    // Populate bill items
    const billItemsTable = document.getElementById('billItems');
    billItemsTable.innerHTML = '';

    let subtotal = 0;
    let totalTax = 0;

    sale.items.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.name}</td>
            <td>${item.batch_no}</td>
            <td>${item.shelf || 'N/A'}</td>
            <td class="text-center">${item.quantity}</td>
            <td class="text-end">₹${item.price.toFixed(2)}</td>
            <td class="text-end">₹${item.tax_amount.toFixed(2)}</td>
            <td class="text-end">₹${item.total_price.toFixed(2)}</td>
        `;

        billItemsTable.appendChild(row);

        subtotal += item.total_price - item.total_tax;
        totalTax += item.total_tax;
    });

    // Set totals
    document.getElementById('billSubtotal').textContent = `₹${subtotal.toFixed(2)}`;
    document.getElementById('billTax').textContent = `₹${totalTax.toFixed(2)}`;
    document.getElementById('billTotal').textContent = `₹${sale.total_amount.toFixed(2)}`;

    // Show modal
    const modalInstance = new bootstrap.Modal(modal);
    modalInstance.show();
}

// Print bill
function printBill() {
    const billPreview = document.getElementById('billPreview');

    if (!billPreview) return;

    const printWindow = window.open('', '_blank');
    printWindow.document.write('<html><head><title>PharmaTrack - Bill</title>');
    printWindow.document.write('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">');
    printWindow.document.write('<style>body { padding: 20px; } @media print { body { padding: 0; } }</style>');
    printWindow.document.write('</head><body>');
    printWindow.document.write(billPreview.innerHTML);
    printWindow.document.write('</body></html>');

    printWindow.document.close();
    printWindow.focus();

    // Print after a short delay to ensure styles are loaded
    setTimeout(() => {
        printWindow.print();
        printWindow.close();
    }, 500);
}

// Show loading indicator (placeholder)
function showLoading() {
    // Implement your loading indicator logic here
}

// Hide loading indicator (placeholder)
function hideLoading() {
    // Implement your loading indicator logic here
}

// Show flash message (placeholder)
function showFlashMessage(message, type) {
    // Implement your flash message logic here
}