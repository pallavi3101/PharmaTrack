document.addEventListener('DOMContentLoaded', function () {
    initializeCounterTabs();
    setupProductSearch();
    setupCustomerSearch();
    // initializeQuantityControls(); // Removed because it is not defined
    initializeActionButtons();
    setupTabKeyNavigation();

    // Counter selector functionality (if present)
    const counterSelector = document.getElementById('counterSelector');
    if (counterSelector) {
        counterSelector.addEventListener('change', function () {
            switchCounter(this.value);
        });
    }
});

// ------------------ Counter Tabs and Navigation ------------------
function initializeCounterTabs() {
    const counterTabs = document.querySelectorAll('.counter-tab');
    counterTabs.forEach(tab => {
        tab.addEventListener('click', function (e) {
            e.preventDefault();
            if (this.classList.contains('disabled')) return;
            const counterId = this.getAttribute('data-counter-id');
            switchCounter(counterId);
        });
    });
}

function switchCounter(counterId) {
    document.querySelectorAll('.counter-section').forEach(content => {
        content.style.display = 'none';
    });
    const selectedContent = document.getElementById(`counter-${counterId}`);
    if (selectedContent) {
        selectedContent.style.display = 'block';
        // Focus on the medicine search input
        const searchInput = selectedContent.querySelector('.product-search');
        if (searchInput) searchInput.focus();
    }
}

function setupTabKeyNavigation() {
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Tab') {
            e.preventDefault();
            const activeCounterTabs = Array.from(document.querySelectorAll('.counter-tab:not(.disabled)'));
            if (!activeCounterTabs.length) return;
            const currentActiveTab = document.querySelector('.counter-tab.active');
            let currentIndex = activeCounterTabs.findIndex(tab => tab === currentActiveTab);
            currentIndex = currentIndex === -1 ? 0 : currentIndex;
            const nextIndex = e.shiftKey
                ? (currentIndex - 1 + activeCounterTabs.length) % activeCounterTabs.length
                : (currentIndex + 1) % activeCounterTabs.length;
            const nextCounterId = activeCounterTabs[nextIndex].getAttribute('data-counter-id');
            switchCounter(nextCounterId);
        }
    });
}

// ------------------ Product Search ------------------
function setupProductSearch() {
    const searchInputs = document.querySelectorAll('.product-search');
    searchInputs.forEach(input => {
        const counterId = input.getAttribute('data-counter');
        const resultsContainer = document.getElementById(`searchResults-${counterId}`);

        input.addEventListener('input', function () {
            const query = this.value.trim();
            if (query.length < 1) {
                resultsContainer.style.display = 'none';
                return;
            }
            fetch(`/api/inventory/search?q=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        resultsContainer.innerHTML = data.map(item => `
                            <div class="p-2 search-result-item" 
                                 onclick="addProductAndHide('${counterId}', ${JSON.stringify(item).replace(/"/g, '&quot;')})">
                                <strong>${item.name}</strong> - ${item.company}<br>
                                <small>Stock: ${item.quantity} | MRP: ₹${item.mrp}</small>
                            </div>
                        `).join('');
                        resultsContainer.style.display = 'block';
                    } else {
                        resultsContainer.innerHTML = '<div class="p-2">No items found</div>';
                        resultsContainer.style.display = 'block';
                    }
                })
                .catch(error => {
                    console.error('Error searching inventory:', error);
                    resultsContainer.innerHTML = '<div class="p-2 text-danger">Error searching inventory</div>';
                    resultsContainer.style.display = 'block';
                });
        });

        document.addEventListener('click', function (e) {
            if (!input.contains(e.target) && !resultsContainer.contains(e.target)) {
                resultsContainer.style.display = 'none';
            }
        });
    });
}

function addProductAndHide(counterId, item) {
    addItemToSale(counterId, item);
    const resultsContainer = document.getElementById(`searchResults-${counterId}`);
    if (resultsContainer) {
        resultsContainer.innerHTML = '';
        resultsContainer.style.display = 'none';
    }
}

// ------------------ Customer Search ------------------
function setupCustomerSearch() {
    document.querySelectorAll('.customer-name').forEach(input => {
        const counterId = input.dataset.counter;
        const resultsContainer = document.getElementById(`customerSearchResults-${counterId}`);

        input.addEventListener('input', function () {
            const query = this.value.trim();
            if (query.length < 1) {
                resultsContainer.innerHTML = '';
                resultsContainer.classList.remove('show');
                return;
            }
            console.log('Searching customers with query:', query);
            fetch(`/api/customers/search?q=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(customers => {
                    console.log('Customer search results:', customers);
                    if (customers.length > 0) {
                        resultsContainer.innerHTML = customers.map(customer => `
                            <div class="list-group-item list-group-item-action customer-option" 
                                 data-counter="${counterId}" 
                                 data-customer-id="${customer.id}" 
                                 data-customer-name="${customer.name}"
                                 data-customer-phone="${customer.phone}"
                                 data-customer-email="${customer.email}"
                                 data-customer-address="${customer.address}">
                                ${customer.name} - ${customer.phone}
                            </div>
                        `).join('');
                    } else {
                        resultsContainer.innerHTML = '<div class="list-group-item">No customers found</div>';
                    }
                    resultsContainer.classList.add('show');
                })
                .catch(error => {
                    console.error('Error searching customers:', error);
                    resultsContainer.innerHTML = '<div class="list-group-item text-danger">Error searching customers</div>';
                    resultsContainer.classList.add('show');
                });
        });

        // Event delegation for customer options
        document.body.addEventListener('click', function (event) {
            const selectedCustomer = event.target.closest('.customer-option');
            if (selectedCustomer) {
                const counterId = selectedCustomer.dataset.counter;
                const customerId = selectedCustomer.dataset.customerId;
                const customerName = selectedCustomer.dataset.customerName;
                const customerPhone = selectedCustomer.dataset.customerPhone;
                const customerEmail = selectedCustomer.dataset.customerEmail;
                const customerAddress = selectedCustomer.dataset.customerAddress;
                setCustomerForSale(counterId, customerId, customerName, customerPhone, customerEmail, customerAddress);
            }
        });

        // Hide customer search results when clicking outside
        document.addEventListener('click', function (e) {
            if (!input.contains(e.target) && !resultsContainer.contains(e.target)) {
                resultsContainer.classList.remove('show');
            }
        });
    });
}

function setCustomerForSale(counterId, customerId, customerName, customerPhone, customerEmail, customerAddress) {
    showLoading();
    const formData = new FormData();
    formData.append('customer_id', customerId);

    fetch(`/counters/counter/${counterId}/set_customer`, {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Set customer name in the search input
                const customerNameInput = document.getElementById(`customer-search-${counterId}`);
                if (customerNameInput) customerNameInput.value = customerName;
                // Set additional fields: phone, email, address
                const customerPhoneInput = document.getElementById(`customer-phone-${counterId}`);
                if (customerPhoneInput) customerPhoneInput.value = customerPhone;
                const customerEmailInput = document.getElementById(`customer-email-${counterId}`);
                if (customerEmailInput) customerEmailInput.value = customerEmail;
                const customerAddressInput = document.getElementById(`customer-address-${counterId}`);
                if (customerAddressInput) customerAddressInput.value = customerAddress;

                const resultsContainer = document.getElementById(`customerSearchResults-${counterId}`);
                if (resultsContainer) {
                    resultsContainer.innerHTML = '';
                    resultsContainer.classList.remove('show');
                    resultsContainer.style.display = 'none';
                }
            } else {
                showFlashMessage(data.message, 'danger');
            }
            hideLoading();
        })
        .catch(error => {
            console.error('Error setting customer for sale:', error);
            showFlashMessage('Failed to set customer for sale. Please try again.', 'danger');
            hideLoading();
        });
}

// ------------------ Sale Items Handling ------------------
function addItemToSale(counterId, item) {
    const tbody = document.getElementById(`items-${counterId}`);
    const row = document.createElement('tr');
    // Save the inventory id as a data attribute on the row.
    row.setAttribute('data-id', item.id);
    row.innerHTML = `
        <td>${item.name}</td>
        <td>${item.tax_percentage}%</td>
        <td>${item.packing}</td>
        <td>${item.batch_no}</td>
        <td>${item.shelf}</td>
        <td>${item.expiry_date}</td>
        <td>₹${item.mrp}</td>
        <td>
            <input type="number" class="form-control form-control-sm quantity-input" value="1" min="1" max="${item.quantity}">
        </td>
        <td>
            <button class="btn btn-sm btn-danger remove-item">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    `;
    tbody.appendChild(row);
    updateTotal(counterId);
}

function updateTotal(counterId) {
    let total = 0;
    const tbody = document.getElementById(`items-${counterId}`);
    tbody.querySelectorAll('tr').forEach(row => {
        const price = parseFloat(row.cells[6].textContent.replace('₹', ''));
        const quantity = parseInt(row.querySelector('.quantity-input').value);
        // Get the tax percentage from cell 1 (remove the '%' sign)
        const tax_percentage = parseFloat(row.cells[1].textContent.replace('%', ''));
        // Calculate tax amount per unit
        const tax_amount = price * (tax_percentage / 100);
        // Total for row = (price + tax_amount) * quantity
        total += (price + tax_amount) * quantity;
    });
    const totalElem = document.getElementById(`total-amount-${counterId}`);
    if (totalElem) totalElem.textContent = `₹${total.toFixed(2)}`;
}

// ------------------ Remove Item & Quantity Update ------------------
document.addEventListener('click', function (e) {
    if (e.target.closest('.remove-item')) {
        const row = e.target.closest('tr');
        if (row) {
            const counterId = row.closest('tbody').id.replace('items-', '');
            row.remove();
            updateTotal(counterId);
        }
    }
});

document.addEventListener('input', function (e) {
    if (e.target.classList.contains('quantity-input')) {
        const row = e.target.closest('tr');
        if (row) {
            const counterId = row.closest('tbody').id.replace('items-', '');
            updateTotal(counterId);
        }
    }
});

// ------------------ Action Buttons: Clear and Checkout ------------------
function initializeActionButtons() {
    // Clear Button
    document.querySelectorAll('.clear-counter').forEach(button => {
        button.addEventListener('click', function () {
            const counterId = this.getAttribute('data-counter');
            if (confirm('Are you sure you want to clear this sale?')) {
                resetCounterContent(counterId);
            }
        });
    });

    // Checkout Button
    document.querySelectorAll('.checkout-counter').forEach(button => {
        button.addEventListener('click', function () {
            const counterId = this.getAttribute('data-counter');
            completeSale(counterId);
        });
    });
}

function resetCounterContent(counterId) {
    // Clear sale items table (tbody)
    const saleItemsTable = document.getElementById(`items-${counterId}`);
    if (saleItemsTable) saleItemsTable.innerHTML = '';
    // Reset total amount
    const totalElem = document.getElementById(`total-amount-${counterId}`);
    if (totalElem) totalElem.textContent = "₹0.00";
    // Clear customer search fields (name, phone, email, address)
    const customerNameInput = document.getElementById(`customer-search-${counterId}`);
    if (customerNameInput) customerNameInput.value = '';
    const customerPhoneInput = document.getElementById(`customer-phone-${counterId}`);
    if (customerPhoneInput) customerPhoneInput.value = '';
    const customerEmailInput = document.getElementById(`customer-email-${counterId}`);
    if (customerEmailInput) customerEmailInput.value = '';
    const customerAddressInput = document.getElementById(`customer-address-${counterId}`);
    if (customerAddressInput) customerAddressInput.value = '';
}

// ------------------ Checkout and Finalize Sale ------------------
function completeSale(counterId) {
    const saleItemsTable = document.getElementById(`items-${counterId}`);
    if (!saleItemsTable || saleItemsTable.children.length === 0) {
        showFlashMessage('No items in the sale', 'warning');
        return;
    }
    const totalElem = document.getElementById(`total-amount-${counterId}`);
    const totalAmount = totalElem ? totalElem.textContent.replace('₹', '').trim() : "0.00";
    if (parseFloat(totalAmount) === 0) {
        showFlashMessage("Total amount cannot be ₹0.00", "warning");
        return;
    }
    // Set the total in the checkout modal
    document.getElementById("modal-total").textContent = totalAmount;
    const checkoutModalElem = document.getElementById("checkoutModal");
    const checkoutModal = new bootstrap.Modal(checkoutModalElem);
    checkoutModal.show();

    // Use a one-time click listener for the Print Bill button
    const printBillButton = checkoutModalElem.querySelector(".print-bill");
    printBillButton.onclick = function () {
        finalizeSale(counterId);
        checkoutModal.hide();
    };
}

function finalizeSale(counterId) {
    showLoading();

    const saleItems = [];
    document.querySelectorAll(`#items-${counterId} tr`).forEach(row => {
        // Retrieve stored inventory id
        const id = row.getAttribute('data-id');
        const name = row.cells[0].textContent;
        // Extract tax_percentage from cell 1 (remove the '%' sign)
        const tax_percentage = parseFloat(row.cells[1].textContent.replace('%', ''));
        const packing = row.cells[2].textContent;
        const batch_no = row.cells[3].textContent;
        const expiry_date = row.cells[5].textContent;
        const price = parseFloat(row.cells[6].textContent.replace('₹', ''));
        const quantity = row.querySelector('.quantity-input') ? parseInt(row.querySelector('.quantity-input').value) : 1;
        // Calculate tax amount per unit
        const tax_amount = price * (tax_percentage / 100);
        // Total price for this item includes tax
        const total_price = (price + tax_amount) * quantity;
        saleItems.push({ id, name, batch_no, packing, expiry_date, tax_percentage, tax_amount, quantity, total_price, price });
    });

    // Gather customer info from the counter inputs
    const customerName = document.getElementById(`customer-search-${counterId}`).value;
    const customerPhone = document.getElementById(`customer-phone-${counterId}`).value;
    const customerEmail = document.getElementById(`customer-email-${counterId}`).value;
    const customerAddress = document.getElementById(`customer-address-${counterId}`).value;

    const payload = {
        items: saleItems,
        customer: {
            name: customerName,
            phone: customerPhone,
            email: customerEmail,
            address: customerAddress
        }
    };

    console.log('Finalizing sale with payload:', payload);

    fetch(`/counters/counter/${counterId}/complete_sale`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showFlashMessage('Sale completed successfully!', 'success');
                resetCounterContent(counterId);
                // Redirect to the bill page for printing
                window.location.href = `/generate_bill/${data.sale.id}`;
            } else {
                showFlashMessage(data.message, 'danger');
            }
            hideLoading();
        })
        .catch(error => {
            console.error('Error completing sale:', error);
            showFlashMessage('Failed to complete sale. Please try again.', 'danger');
            hideLoading();
        });
}

// ------------------ Helper Functions ------------------
function showLoading() {
    // Implement your loading indicator here.
    console.log('Loading...');
}

function hideLoading() {
    // Implement your logic to hide the loading indicator.
    console.log('Loading complete.');
}

function showFlashMessage(message, type) {
    alert(message); // Replace with your preferred flash message method.
}