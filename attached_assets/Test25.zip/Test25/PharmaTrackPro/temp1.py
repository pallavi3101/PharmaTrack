from datetime import datetime
import random
from app import app, db, initialize_database
from models import Inventory, Customer, Counter, Sale, SaleItem

def add_sample_data():
    # --- Create 10 Inventory Items ---
    inventory_items = []
    for i in range(1, 11):
        inv = Inventory(
            name=f"Medicine {i}",
            category="Medicine",
            packing="Box" if i % 2 == 0 else "Bottle",
            company=f"Pharma Company {i}",
            batch_no=f"B{100 + i}",
            mrp=10.0 * i,
            quantity=100 + i * 10,
            shelf=f"A{i}",
            tax_percentage=5.0,
            supplier=f"Supplier {i}",
            supplier_email=f"supplier{i}@example.com",
            expiry_date="2025-12-31" if i % 2 == 0 else "2024-06-30"
        )
        inventory_items.append(inv)

    # --- Create 10 Customers ---
    customers = []
    for i in range(1, 11):
        cust = Customer(
            name=f"Customer {i}",
            phone=f"12345678{i:02d}",
            email=f"customer{i}@example.com",
            address=f"{i} Main Street, City",
            medicine_preferences="Pain relief, Fever" if i % 2 == 0 else "Cough, Cold"
        )
        customers.append(cust)
    
    # --- Create 10 Counters ---
    counters = []
    for i in range(1, 11):
        cnt = Counter(
            active=True if i == 1 else False  # Mark only the first counter as active, for example
        )
        counters.append(cnt)
    
    # Add all the above to the session and commit to generate their IDs
    db.session.add_all(inventory_items + customers + counters)
    db.session.commit()
    
    # --- Create 10 Sales with Sale Items ---
    sales = []
    for i in range(1, 11):
        # Randomly choose a customer and a counter for each sale
        customer = random.choice(customers)
        counter = random.choice(counters)
        
        sale = Sale(
            counter_id=counter.id,
            customer_id=customer.id,
            date=datetime.now(),
            total_amount=0,  # We'll update this after adding items
            total_tax=0
        )
        db.session.add(sale)
        db.session.commit()  # To get sale.id
        
        # For each sale, add 2 sale items chosen randomly from inventory
        sale_items = []
        for _ in range(2):
            inv_item = random.choice(inventory_items)
            price = inv_item.mrp
            tax_amount = price * inv_item.tax_percentage / 100
            sale_item = SaleItem(
                sale_id=sale.id,
                inventory_id=inv_item.id,
                name=inv_item.name,
                batch_no=inv_item.batch_no,
                packing=inv_item.packing,
                expiry_date=inv_item.expiry_date,
                price=price,
                tax_percentage=inv_item.tax_percentage,
                tax_amount=tax_amount,
                quantity=1,
                total_price=price + tax_amount
            )
            sale_items.append(sale_item)
        
        # Update sale totals
        sale.total_amount = sum(item.total_price for item in sale_items)
        sale.total_tax = sum(item.tax_amount for item in sale_items)
        
        db.session.add_all(sale_items)
        db.session.commit()
        sales.append(sale)
    
    print("Sample data added successfully.")


if __name__ == "__main__":
    # Create an application context so that Flask-SQLAlchemy can access the current app
    with app.app_context():
        # First, initialize the database and tables if needed
        initialize_database()
        # Then, add the sample data
        add_sample_data()