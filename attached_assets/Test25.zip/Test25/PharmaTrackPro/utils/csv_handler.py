"""
PharmaTrack - CSV Handler Utility

This module provides functions for importing and exporting CSV data
for inventory items, customers, and sales records.
"""

import csv
import logging
import pandas as pd
import io
from datetime import datetime

# Configure logging
logger = logging.getLogger(__name__)

def validate_inventory_csv(csv_data):
    """
    Validate CSV data for inventory import.
    
    Args:
        csv_data (str): CSV data as string
        
    Returns:
        tuple: (is_valid, errors, DataFrame)
    """
    try:
        # Convert CSV string to DataFrame
        df = pd.read_csv(io.StringIO(csv_data))
        
        # Make column names lowercase for case-insensitive comparison
        df.columns = [col.lower().strip() for col in df.columns]
        
        # Check required columns
        required_columns = [
            'name', 'category', 'packing', 'company', 'batch_no', 
            'mrp', 'quantity', 'shelf', 'tax_percentage', 
            'supplier', 'expiry_date'
        ]
        
        # Check for missing columns
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            return False, f"Missing required columns: {', '.join(missing_columns)}", None
        
        # Validate data types and values
        errors = []
        
        # Check for empty values in required fields
        for col in required_columns:
            if df[col].isna().any():
                errors.append(f"Column '{col}' has missing values")
        
        # Check numeric fields
        try:
            df['mrp'] = pd.to_numeric(df['mrp'])
            invalid_mrp = df[df['mrp'] < 0].index.tolist()
            if invalid_mrp:
                errors.append(f"Negative MRP values at rows: {invalid_mrp}")
        except:
            errors.append("MRP column contains non-numeric values")
        
        try:
            df['quantity'] = pd.to_numeric(df['quantity'])
            invalid_qty = df[df['quantity'] < 0].index.tolist()
            if invalid_qty:
                errors.append(f"Negative quantity values at rows: {invalid_qty}")
        except:
            errors.append("Quantity column contains non-numeric values")
        
        try:
            df['tax_percentage'] = pd.to_numeric(df['tax_percentage'])
            invalid_tax = df[(df['tax_percentage'] < 0) | (df['tax_percentage'] > 100)].index.tolist()
            if invalid_tax:
                errors.append(f"Invalid tax percentage values at rows: {invalid_tax}")
        except:
            errors.append("Tax percentage column contains non-numeric values")
        
        # Check date format for expiry_date
        try:
            # Try to convert dates, which will raise if format is incorrect
            df['expiry_date'] = pd.to_datetime(df['expiry_date']).dt.strftime('%Y-%m-%d')
            
            # Check for past expiry dates
            today = datetime.now().date()
            expired = df[pd.to_datetime(df['expiry_date']).dt.date < today].index.tolist()
            if expired:
                errors.append(f"Expired items at rows: {expired}")
        except:
            errors.append("Expiry date column contains invalid date formats (expected YYYY-MM-DD)")
        
        if errors:
            return False, "\n".join(errors), None
        
        return True, "", df
    
    except Exception as e:
        logger.error(f"Error validating inventory CSV: {str(e)}")
        return False, f"Error processing CSV: {str(e)}", None

def process_inventory_import(csv_data, current_inventory):
    """
    Process inventory import from CSV.
    
    Args:
        csv_data (str): CSV data as string
        current_inventory (list): Current inventory items
        
    Returns:
        tuple: (success, message, new_items)
    """
    try:
        valid, error_msg, df = validate_inventory_csv(csv_data)
        if not valid:
            return False, error_msg, []
        
        # Convert DataFrame to list of dictionaries
        new_items = []
        next_id = max([item['id'] for item in current_inventory]) + 1 if current_inventory else 1
        
        for _, row in df.iterrows():
            item = {
                'id': next_id,
                'name': row['name'],
                'category': row['category'],
                'packing': row['packing'],
                'company': row['company'],
                'batch_no': row['batch_no'],
                'mrp': float(row['mrp']),
                'quantity': int(row['quantity']),
                'shelf': row['shelf'],
                'tax_percentage': float(row['tax_percentage']),
                'supplier': row['supplier'],
                'expiry_date': row['expiry_date'],
                'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            new_items.append(item)
            next_id += 1
        
        return True, f"Successfully processed {len(new_items)} inventory items", new_items
    
    except Exception as e:
        logger.error(f"Error processing inventory import: {str(e)}")
        return False, f"Error processing inventory import: {str(e)}", []

def export_inventory_to_csv(inventory_data):
    """
    Export inventory data to CSV.
    
    Args:
        inventory_data (list): List of inventory items
        
    Returns:
        str: CSV data as string
    """
    try:
        if not inventory_data:
            return ""
        
        # Define CSV columns
        columns = [
            'id', 'name', 'category', 'packing', 'company', 
            'batch_no', 'mrp', 'quantity', 'shelf', 
            'tax_percentage', 'supplier', 'expiry_date', 'created_at'
        ]
        
        # Create CSV in memory
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=columns)
        
        # Write header
        writer.writeheader()
        
        # Write data
        for item in inventory_data:
            # Ensure all columns exist in the item
            row = {col: item.get(col, '') for col in columns}
            writer.writerow(row)
        
        return output.getvalue()
    
    except Exception as e:
        logger.error(f"Error exporting inventory to CSV: {str(e)}")
        return ""

def validate_customer_csv(csv_data):
    """
    Validate CSV data for customer import.
    
    Args:
        csv_data (str): CSV data as string
        
    Returns:
        tuple: (is_valid, errors, DataFrame)
    """
    try:
        # Convert CSV string to DataFrame
        df = pd.read_csv(io.StringIO(csv_data))
        
        # Make column names lowercase for case-insensitive comparison
        df.columns = [col.lower().strip() for col in df.columns]
        
        # Check required columns
        required_columns = ['name', 'phone', 'email', 'address']
        
        # Check for missing columns
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            return False, f"Missing required columns: {', '.join(missing_columns)}", None
        
        # Validate data types and values
        errors = []
        
        # Check for empty values in required fields
        for col in ['name', 'phone', 'address']:
            if df[col].isna().any():
                errors.append(f"Column '{col}' has missing values")
        
        # Validate email format if provided
        if 'email' in df.columns:
            # Basic email validation using pandas string methods
            if not df['email'].isna().all():
                invalid_emails = df[
                    ~df['email'].isna() & 
                    ~df['email'].str.contains(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
                ].index.tolist()
                
                if invalid_emails:
                    errors.append(f"Invalid email formats at rows: {invalid_emails}")
        
        if errors:
            return False, "\n".join(errors), None
        
        return True, "", df
    
    except Exception as e:
        logger.error(f"Error validating customer CSV: {str(e)}")
        return False, f"Error processing CSV: {str(e)}", None

def process_customer_import(csv_data, current_customers):
    """
    Process customer import from CSV.
    
    Args:
        csv_data (str): CSV data as string
        current_customers (list): Current customer records
        
    Returns:
        tuple: (success, message, new_customers)
    """
    try:
        valid, error_msg, df = validate_customer_csv(csv_data)
        if not valid:
            return False, error_msg, []
        
        # Convert DataFrame to list of dictionaries
        new_customers = []
        next_id = max([customer['id'] for customer in current_customers]) + 1 if current_customers else 1
        
        for _, row in df.iterrows():
            customer = {
                'id': next_id,
                'name': row['name'],
                'phone': row['phone'],
                'email': row['email'] if not pd.isna(row['email']) else '',
                'address': row['address'],
                'medicine_preferences': row['medicine_preferences'] if 'medicine_preferences' in row and not pd.isna(row['medicine_preferences']) else '',
                'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            new_customers.append(customer)
            next_id += 1
        
        return True, f"Successfully processed {len(new_customers)} customers", new_customers
    
    except Exception as e:
        logger.error(f"Error processing customer import: {str(e)}")
        return False, f"Error processing customer import: {str(e)}", []

def export_customers_to_csv(customer_data):
    """
    Export customer data to CSV.
    
    Args:
        customer_data (list): List of customer records
        
    Returns:
        str: CSV data as string
    """
    try:
        if not customer_data:
            return ""
        
        # Define CSV columns
        columns = [
            'id', 'name', 'phone', 'email', 'address', 
            'medicine_preferences', 'created_at'
        ]
        
        # Create CSV in memory
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=columns)
        
        # Write header
        writer.writeheader()
        
        # Write data
        for customer in customer_data:
            # Ensure all columns exist in the customer record
            row = {col: customer.get(col, '') for col in columns}
            writer.writerow(row)
        
        return output.getvalue()
    
    except Exception as e:
        logger.error(f"Error exporting customers to CSV: {str(e)}")
        return ""

def export_sales_to_csv(sales_data):
    """
    Export sales data to CSV.
    
    Args:
        sales_data (list): List of sale records
        
    Returns:
        str: CSV data as string
    """
    try:
        if not sales_data:
            return ""
        
        # Define CSV columns for sales summary
        columns = [
            'id', 'date', 'counter_id', 'customer_name', 'customer_phone',
            'total_items', 'total_amount', 'total_tax'
        ]
        
        # Create CSV in memory
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=columns)
        
        # Write header
        writer.writeheader()
        
        # Write data
        for sale in sales_data:
            # Extract customer info
            customer = sale.get('customer', {})
            customer_name = customer.get('name', 'Walk-in Customer') if customer else 'Walk-in Customer'
            customer_phone = customer.get('phone', '') if customer else ''
            
            # Create row
            row = {
                'id': sale.get('id', ''),
                'date': sale.get('date', ''),
                'counter_id': sale.get('counter_id', ''),
                'customer_name': customer_name,
                'customer_phone': customer_phone,
                'total_items': len(sale.get('items', [])),
                'total_amount': sale.get('total_amount', 0),
                'total_tax': sale.get('total_tax', 0)
            }
            writer.writerow(row)
        
        return output.getvalue()
    
    except Exception as e:
        logger.error(f"Error exporting sales to CSV: {str(e)}")
        return ""

def export_sales_details_to_csv(sales_data):
    """
    Export detailed sales data (including items) to CSV.
    
    Args:
        sales_data (list): List of sale records
        
    Returns:
        str: CSV data as string
    """
    try:
        if not sales_data:
            return ""
        
        # Define CSV columns for detailed sales
        columns = [
            'sale_id', 'date', 'counter_id', 'customer_name', 'customer_phone',
            'item_name', 'batch_no', 'packing', 'expiry_date', 
            'unit_price', 'quantity', 'tax_amount', 'total_price'
        ]
        
        # Create CSV in memory
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=columns)
        
        # Write header
        writer.writeheader()
        
        # Write data - one row per sale item
        for sale in sales_data:
            # Extract customer info
            customer = sale.get('customer', {})
            customer_name = customer.get('name', 'Walk-in Customer') if customer else 'Walk-in Customer'
            customer_phone = customer.get('phone', '') if customer else ''
            
            # Common sale info
            sale_info = {
                'sale_id': sale.get('id', ''),
                'date': sale.get('date', ''),
                'counter_id': sale.get('counter_id', ''),
                'customer_name': customer_name,
                'customer_phone': customer_phone
            }
            
            # Add each item as a row
            for item in sale.get('items', []):
                row = sale_info.copy()
                row.update({
                    'item_name': item.get('name', ''),
                    'batch_no': item.get('batch_no', ''),
                    'packing': item.get('packing', ''),
                    'expiry_date': item.get('expiry_date', ''),
                    'unit_price': item.get('price', 0),
                    'quantity': item.get('quantity', 0),
                    'tax_amount': item.get('tax_amount', 0) * item.get('quantity', 0),
                    'total_price': item.get('total_price', 0)
                })
                writer.writerow(row)
        
        return output.getvalue()
    
    except Exception as e:
        logger.error(f"Error exporting detailed sales to CSV: {str(e)}")
        return ""
