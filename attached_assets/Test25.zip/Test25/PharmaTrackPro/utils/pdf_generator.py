"""
PharmaTrack - PDF Generator Utility

This module provides functions for generating PDF documents 
such as bills, reports, and other pharmacy documents.
"""

import os
import logging
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.pdfgen import canvas
from io import BytesIO

# Configure logging
logger = logging.getLogger(__name__)

def generate_bill_pdf(sale_data, pharmacy_info):
    """
    Generate a PDF bill/invoice for a sale.
    
    Args:
        sale_data (dict): Sale information including items, customer, etc.
        pharmacy_info (dict): Pharmacy information like name, address, etc.
        
    Returns:
        BytesIO: PDF file content as a bytes buffer
    """
    try:
        buffer = BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=72
        )
        
        # Get styles
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(
            name='Center',
            parent=styles['Heading1'],
            alignment=1,  # 0=left, 1=center, 2=right
        ))
        
        # Create document elements
        elements = []
        
        # Header with pharmacy info
        elements.append(Paragraph(pharmacy_info.get('name', 'PharmaTrack Pharmacy'), styles['Center']))
        elements.append(Spacer(1, 5))
        elements.append(Paragraph(pharmacy_info.get('address', '123 Pharmacy Street'), styles['Center']))
        elements.append(Spacer(1, 5))
        elements.append(Paragraph(pharmacy_info.get('contact', 'Phone: 123-456-7890'), styles['Center']))
        elements.append(Spacer(1, 10))
        elements.append(Paragraph("TAX INVOICE", styles['Center']))
        elements.append(Spacer(1, 20))
        
        # Invoice details
        invoice_data = [
            ["Invoice #:", str(sale_data.get('id', ''))],
            ["Date:", sale_data.get('date', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))],
            ["Counter:", f"Counter {sale_data.get('counter_id', '')}"],
        ]
        
        # Customer details
        customer = sale_data.get('customer', {})
        if customer:
            invoice_data.extend([
                ["Customer:", customer.get('name', 'Walk-in Customer')],
                ["Phone:", customer.get('phone', '')],
                ["Address:", customer.get('address', '')]
            ])
        else:
            invoice_data.append(["Customer:", "Walk-in Customer"])
        
        # Create invoice details table
        invoice_table = Table(invoice_data, colWidths=[100, 350])
        invoice_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.grey),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]))
        elements.append(invoice_table)
        elements.append(Spacer(1, 20))
        
        # Items table header
        items = sale_data.get('items', [])
        items_data = [
            ["Item", "Batch", "Expiry", "Price", "Qty", "Tax", "Total"]
        ]
        
        # Add item rows
        subtotal = 0
        total_tax = 0
        
        for item in items:
            price = item.get('price', 0)
            quantity = item.get('quantity', 0)
            tax = item.get('tax_amount', 0) * quantity
            total = item.get('total_price', 0)
            
            items_data.append([
                f"{item.get('name', '')} ({item.get('packing', '')})",
                item.get('batch_no', ''),
                item.get('expiry_date', ''),
                f"₹{price:.2f}",
                str(quantity),
                f"₹{tax:.2f}",
                f"₹{total:.2f}"
            ])
            
            subtotal += total - tax
            total_tax += tax
        
        # Create items table
        col_widths = [150, 50, 60, 60, 40, 60, 70]
        items_table = Table(items_data, colWidths=col_widths)
        items_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
            ('ALIGN', (3, 0), (-1, -1), 'RIGHT'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        elements.append(items_table)
        elements.append(Spacer(1, 20))
        
        # Summary table
        total_amount = sale_data.get('total_amount', 0)
        summary_data = [
            ["Subtotal:", f"₹{subtotal:.2f}"],
            ["Tax:", f"₹{total_tax:.2f}"],
            ["Grand Total:", f"₹{total_amount:.2f}"]
        ]
        
        summary_table = Table(summary_data, colWidths=[100, 100])
        summary_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('FONTNAME', (0, 2), (1, 2), 'Helvetica-Bold'),
            ('LINEABOVE', (0, 2), (1, 2), 1, colors.black),
            ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ]))
        
        # Wrap summary table in a larger table to align it to the right
        wrapper = Table([[None, summary_table]], colWidths=[300, 200])
        elements.append(wrapper)
        elements.append(Spacer(1, 30))
        
        # Footer
        elements.append(Paragraph("Thank you for shopping with us!", styles['Center']))
        elements.append(Spacer(1, 5))
        elements.append(Paragraph("For any queries related to this invoice, please contact us.", styles['Center']))
        
        # Build the PDF
        doc.build(elements)
        buffer.seek(0)
        return buffer
    
    except Exception as e:
        logger.error(f"Error generating PDF bill: {str(e)}")
        raise

def generate_sales_report_pdf(sales_data, date_range, filter_type=None):
    """
    Generate a PDF sales report.
    
    Args:
        sales_data (list): List of sales records
        date_range (tuple): Start and end dates for the report
        filter_type (str, optional): Type of filtering applied
        
    Returns:
        BytesIO: PDF file content as a bytes buffer
    """
    try:
        buffer = BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=72
        )
        
        # Get styles
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(
            name='Center',
            parent=styles['Heading1'],
            alignment=1,
        ))
        
        # Create document elements
        elements = []
        
        # Header
        elements.append(Paragraph("Sales Report", styles['Center']))
        elements.append(Spacer(1, 10))
        
        start_date, end_date = date_range
        date_str = f"Period: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}"
        elements.append(Paragraph(date_str, styles['Normal']))
        
        if filter_type:
            elements.append(Paragraph(f"Filter: {filter_type}", styles['Normal']))
        
        elements.append(Spacer(1, 20))
        
        # Sales summary
        total_sales = len(sales_data)
        total_amount = sum(sale.get('total_amount', 0) for sale in sales_data)
        total_items = sum(len(sale.get('items', [])) for sale in sales_data)
        
        summary_data = [
            ["Total Sales:", str(total_sales)],
            ["Total Items Sold:", str(total_items)],
            ["Total Amount:", f"₹{total_amount:.2f}"]
        ]
        
        summary_table = Table(summary_data, colWidths=[150, 350])
        summary_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.grey),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]))
        elements.append(summary_table)
        elements.append(Spacer(1, 20))
        
        # Sales list
        if sales_data:
            sales_header = ["Bill #", "Date", "Counter", "Customer", "Items", "Amount"]
            sales_list = [sales_header]
            
            for sale in sales_data:
                customer_name = sale.get('customer', {}).get('name', 'Walk-in Customer') if sale.get('customer') else 'Walk-in Customer'
                sales_list.append([
                    str(sale.get('id', '')),
                    sale.get('date', ''),
                    f"Counter {sale.get('counter_id', '')}",
                    customer_name,
                    str(len(sale.get('items', []))),
                    f"₹{sale.get('total_amount', 0):.2f}"
                ])
            
            col_widths = [50, 120, 70, 120, 50, 80]
            sales_table = Table(sales_list, colWidths=col_widths)
            sales_table.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                ('ALIGN', (4, 0), (5, -1), 'RIGHT'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ]))
            elements.append(sales_table)
        else:
            elements.append(Paragraph("No sales data found for the selected period.", styles['Normal']))
        
        # Build the PDF
        doc.build(elements)
        buffer.seek(0)
        return buffer
    
    except Exception as e:
        logger.error(f"Error generating sales report PDF: {str(e)}")
        raise

def generate_inventory_report_pdf(inventory_data, report_type="current"):
    """
    Generate a PDF inventory report.
    
    Args:
        inventory_data (list): List of inventory items
        report_type (str): Type of inventory report (current, low_stock, expiring)
        
    Returns:
        BytesIO: PDF file content as a bytes buffer
    """
    try:
        buffer = BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=72
        )
        
        # Get styles
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(
            name='Center',
            parent=styles['Heading1'],
            alignment=1,
        ))
        
        # Create document elements
        elements = []
        
        # Header
        title = "Current Inventory Report"
        if report_type == "low_stock":
            title = "Low Stock Report"
        elif report_type == "expiring":
            title = "Expiring Medicines Report"
        
        elements.append(Paragraph(title, styles['Center']))
        elements.append(Spacer(1, 10))
        
        # Date of report
        date_str = f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        elements.append(Paragraph(date_str, styles['Normal']))
        elements.append(Spacer(1, 20))
        
        # Inventory summary
        total_items = len(inventory_data)
        total_quantity = sum(item.get('quantity', 0) for item in inventory_data)
        total_value = sum(item.get('mrp', 0) * item.get('quantity', 0) for item in inventory_data)
        
        low_stock_count = len([item for item in inventory_data if item.get('quantity', 0) < 10])
        
        # Calculate expiring items (within 30 days)
        today = datetime.now()
        expiring_count = len([
            item for item in inventory_data 
            if (datetime.strptime(item.get('expiry_date', '2099-12-31'), '%Y-%m-%d') - today).days < 30
        ])
        
        summary_data = [
            ["Total Items:", str(total_items)],
            ["Total Quantity:", str(total_quantity)],
            ["Total Value:", f"₹{total_value:.2f}"],
            ["Low Stock Items:", str(low_stock_count)],
            ["Expiring Soon:", str(expiring_count)]
        ]
        
        summary_table = Table(summary_data, colWidths=[150, 350])
        summary_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.grey),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]))
        elements.append(summary_table)
        elements.append(Spacer(1, 20))
        
        # Inventory list
        if inventory_data:
            inventory_header = ["Name", "Category", "Batch", "Expiry", "Quantity", "MRP", "Value"]
            inventory_list = [inventory_header]
            
            for item in inventory_data:
                quantity = item.get('quantity', 0)
                mrp = item.get('mrp', 0)
                value = quantity * mrp
                
                inventory_list.append([
                    item.get('name', ''),
                    item.get('category', ''),
                    item.get('batch_no', ''),
                    item.get('expiry_date', ''),
                    str(quantity),
                    f"₹{mrp:.2f}",
                    f"₹{value:.2f}"
                ])
            
            col_widths = [120, 70, 60, 60, 50, 60, 70]
            inventory_table = Table(inventory_list, colWidths=col_widths)
            inventory_table.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                ('ALIGN', (4, 0), (6, -1), 'RIGHT'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ]))
            elements.append(inventory_table)
        else:
            elements.append(Paragraph("No inventory data found.", styles['Normal']))
        
        # Build the PDF
        doc.build(elements)
        buffer.seek(0)
        return buffer
    
    except Exception as e:
        logger.error(f"Error generating inventory report PDF: {str(e)}")
        raise

def generate_customer_report_pdf(customer_data, sales_data=None):
    """
    Generate a PDF customer report.
    
    Args:
        customer_data (dict): Customer information
        sales_data (list, optional): List of sales for this customer
        
    Returns:
        BytesIO: PDF file content as a bytes buffer
    """
    try:
        buffer = BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=72
        )
        
        # Get styles
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(
            name='Center',
            parent=styles['Heading1'],
            alignment=1,
        ))
        
        # Create document elements
        elements = []
        
        # Header
        elements.append(Paragraph("Customer Report", styles['Center']))
        elements.append(Spacer(1, 10))
        
        # Date of report
        date_str = f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        elements.append(Paragraph(date_str, styles['Normal']))
        elements.append(Spacer(1, 20))
        
        # Customer details
        customer_name = customer_data.get('name', 'Unknown')
        elements.append(Paragraph(f"Customer: {customer_name}", styles['Heading2']))
        elements.append(Spacer(1, 10))
        
        customer_details = [
            ["ID:", str(customer_data.get('id', ''))],
            ["Phone:", customer_data.get('phone', '')],
            ["Email:", customer_data.get('email', '')],
            ["Address:", customer_data.get('address', '')]
        ]
        
        customer_table = Table(customer_details, colWidths=[100, 400])
        customer_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.grey),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]))
        elements.append(customer_table)
        elements.append(Spacer(1, 10))
        
        # Medicine preferences
        preferences = customer_data.get('medicine_preferences', '')
        if preferences:
            elements.append(Paragraph("Medicine Preferences:", styles['Heading3']))
            elements.append(Paragraph(preferences, styles['Normal']))
            elements.append(Spacer(1, 10))
        
        # Sales history
        elements.append(Paragraph("Purchase History:", styles['Heading3']))
        elements.append(Spacer(1, 5))
        
        if sales_data:
            # Sales summary
            total_sales = len(sales_data)
            total_amount = sum(sale.get('total_amount', 0) for sale in sales_data)
            total_items = sum(len(sale.get('items', [])) for sale in sales_data)
            
            summary_data = [
                ["Total Purchases:", str(total_sales)],
                ["Total Items:", str(total_items)],
                ["Total Spent:", f"₹{total_amount:.2f}"]
            ]
            
            summary_table = Table(summary_data, colWidths=[150, 350])
            summary_table.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('TEXTCOLOR', (0, 0), (0, -1), colors.grey),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ]))
            elements.append(summary_table)
            elements.append(Spacer(1, 10))
            
            # Sales list
            sales_header = ["Bill #", "Date", "Items", "Amount"]
            sales_list = [sales_header]
            
            for sale in sales_data:
                sales_list.append([
                    str(sale.get('id', '')),
                    sale.get('date', ''),
                    str(len(sale.get('items', []))),
                    f"₹{sale.get('total_amount', 0):.2f}"
                ])
            
            col_widths = [100, 200, 100, 100]
            sales_table = Table(sales_list, colWidths=col_widths)
            sales_table.setStyle(TableStyle([
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                ('ALIGN', (2, 0), (3, -1), 'RIGHT'),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ]))
            elements.append(sales_table)
        else:
            elements.append(Paragraph("No purchase history found for this customer.", styles['Normal']))
        
        # Build the PDF
        doc.build(elements)
        buffer.seek(0)
        return buffer
    
    except Exception as e:
        logger.error(f"Error generating customer report PDF: {str(e)}")
        raise
